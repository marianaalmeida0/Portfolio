# -*- coding:utf-8 -*-

import math as mt

class RastrosEngine:
    
    def __init__(self):
        self.tab_jogo = [] #matriz que representa o tabuleiro de jogo original
        self.tab_estado = [] #matriz que representa o tabuleiro com o estado do jogo
        self.jogador= "1"
        #Lista de jogadas do jogo
        self.jogadas= [] 
        #Guardar a posição atual da peça branca (representada por "*")
        self.posicao_coluna = None
        self.posicao_linha = None
        
        #Peça branca inicial que servirá de valor de referência para jogadas seguintes
        #Usado na validação da jogada
        self.peca_br=[3,4]
        
    '''
       Método para ler o tabuleiro de ficheiro
    '''        
    def ler_tabuleiro_ficheiro(self, filename):
        '''
        Cria nova instancia do jogo numa matriz
        :param filename: nome do ficheiro a ler
        como o formato é fixo sabe-se o que contem cada linha
        '''
        
        temp_linha = []
        try:
            ficheiro = open(filename, "r")
            lines = ficheiro.readlines() #ler as linhas do ficheiro para a lista lines
            
            self.tab_jogo=[]
            for i in range(0,8): #as linhas 0 a 7 contêm o tabuleiro de jogo            
                self.tab_jogo.append(lines[i].split())
                
            self.tab_estado=[]
            for j in range(0,8): #as linhas 0 a 7 contêm o tabuleiro de jogo
                self.tab_estado.append(lines[j].split())
        
            estado=True
             
            #Encontrar a localização da peça branca (principalmente aplicável para casos de leitura de ficheiros anteriormente gravados)
            for i in range (0, (len(self.tab_estado))-1):
                for a in range (0,8):
                    if self.tab_estado[i][0][a]=='*':
                        self.set_peca_br([i,a])
                  
        except:
            print("Erro: na leitura do tabuleiro")
            estado=False
        else:
            ficheiro.close()
        return estado

    '''
       Método para imprime na shell o estado do tabuleiro
    '''        
    def print_tab_estado(self):
        numeros=['8','7','6','5','4','3','2','1'] 
        i=0
        for linha in self.tab_estado:
            print(numeros[i],end=" ")
            i+=1
            for simbolo in linha:               
                print(simbolo,end=" ")
            print()
        print("  abcdefgh")
        print("[Próximo a jogar: jogador %s]"%(self.jogador))
   
    '''
       Método para atribuir o numero do jogador 
    '''            
    def setjogador(self,jog):
        self.jogador=jog
    '''
       Método para obter o atual numero do jogador
    '''        
    def getjogador(self):
        return self.jogador
    
    '''
       Método para devolver o estado do tabuleiro de jogo
    '''            
    def gettab_estado(self):
        return self.tab_estado

    '''
       Método para atribuir o novo estado do tabuleiro de jogo
    '''        
    def settab_estado(self, t):
        self.tab_estado = t
        
    '''
       Método para guardar a poscicao da coluna na matriz
    '''       
    def setposicao_coluna(self,pos):
        self.posicao_coluna=pos

    '''
       Método para guardar a poscicao da coluna na matriz
    '''           
    def getposicao_coluna(self):
        return self.posicao_coluna

    '''
       Método para guardar a poscicao da linha na matriz
    '''           
    def setposicao_linha(self,pos):
        self.posicao_linha=pos
    
    '''
       Método para obter a atual poscicao da coluna na matriz
    '''           
    def getposicao_linha(self):
        return self.posicao_linha

    '''
       Método para obter as jogadas de um dado jogador
    '''               
    def getjogadas_jogador(self,jogador):
        if (jogador=="1"):
            return self.jogadas[0]
        else:
            return self.jogadas[1]
        
    '''
       Método para obter o estdo do tabuleiro
    '''               
    def gettab_estado(self):
        return self.tab_estado   

    '''
       Método para atribuir o estdo do tabuleiro
    '''               
    def settab_estado(self, t):
        self.tab_estado = t

    '''
       Método para obter ao conjunto de valores correspondentes à peça branca
    '''               
        
    def get_peca_br(self):  
        return self.peca_br

    '''
       Método para atribuir um conjunto de valores à peça branca, sendo l uma lista
    '''                   
    def set_peca_br(self,l):  
        self.peca_br = l
    
        
    '''
     Método que devolve os movimentos das jogadas no formato 01: d4 e4
                                                             02: e3     
    '''     
    def getmovimentos(self):
      if len(self.jogadas)!=0: 
        lista_jogadas_jogador_1 = self.getjogadas_jogador("1")
        lista_jogadas_jogador_2 = self.getjogadas_jogador("2")       
        lista_jogadas=[]
        tam_lista_1=len(lista_jogadas_jogador_1)-1
        tam_lista_2=len(lista_jogadas_jogador_2)-1
        if (lista_jogadas_jogador_1!=[]):
            #a lista de jogadas dos jogadores são iguais      
            if (tam_lista_1==tam_lista_2):           
              for i in range(0,len(lista_jogadas_jogador_1)):  
                 if i<10:
                   jogada="0"+str(i+1)        
                 else:
                   jogada=str(i+1)     
                 tmp= jogada + ": " +lista_jogadas_jogador_1[i] + " " + lista_jogadas_jogador_2[i]              
                 lista_jogadas.append(tmp)
            else:
                #A lista de jogadas do jogador um é maior do que do jogador dois
                if(tam_lista_1>tam_lista_2):                  
                   for i in range(0,len(lista_jogadas_jogador_1)):  
                      if i<10:
                        jogada="0"+str(i+1)        
                      else:
                        jogada=str(i+1)     
                      if (i>tam_lista_2):
                         tmp= jogada + ": " +lista_jogadas_jogador_1[i]  
                      else:
                          tmp= jogada + ": " +lista_jogadas_jogador_1[i] + " " + lista_jogadas_jogador_2[i]  
                      lista_jogadas.append(tmp)                     
                else:
                    #A lista de jogadas do jogador dois é maior do que do jogador 1  
                    for i in range(0,len(lista_jogadas_jogador_2)):  
                       if i<10:
                         jogada="0"+str(i+1)        
                       else:
                         jogada=str(i+1)     
                       if (i>tam_lista_1):
                          tmp= jogada + ": " +lista_jogadas_jogador_2[i]  
                       else:
                           tmp= jogada + ": " +lista_jogadas_jogador_1[i] + " " + lista_jogadas_jogador_2[i]  
                       lista_jogadas.append(tmp)   
        else:
              print("Erro: Não existem jogadas")              
        if lista_jogadas!=[]:
           return lista_jogadas   
        else:     
           return []    
      else:
          return []    

    '''
     Método que devolve o número total de jogadas
    ''' 
    def getnumero_total_movimentos(self):
        jogadas_jogador_1= len(self.jogadas[0])
        jogadas_jogador_2= len(self.jogadas[1])
        if jogadas_jogador_1>jogadas_jogador_2:
            return jogadas_jogador_1
        else:
            return jogadas_jogador_2
    '''
       Método para devolver as jogadas efetuadas (guardadas numa lista)
    '''                       
    def getjogadas(self):
        return self.jogadas;
    '''
     Método que dada uma posição, devolve a jogada
    '''    
    def getjogada(self, pos):
      if len(self.jogadas)!=0: 
        lista_jogadas_jogador_1 = self.getjogadas_jogador("1")
        lista_jogadas_jogador_2 = self.getjogadas_jogador("2")       
        lista_jogada=[]
        tam_lista_1=len(lista_jogadas_jogador_1)-1
        tam_lista_2=len(lista_jogadas_jogador_2)-1
        if (lista_jogadas_jogador_1!=[]):
            #A lista de jogadas dos jogadores são iguais      
            if (tam_lista_1==tam_lista_2):           
              for i in range(0,len(lista_jogadas_jogador_1)):  
                 if i<10:
                   jogada="0"+str(i+1)        
                 else:
                   jogada=str(i+1)     
                 tmp= jogada + ": " +lista_jogadas_jogador_1[i] + " " + lista_jogadas_jogador_2[i]              
                 posicao=int(pos-1)
                 if(i==posicao):
                   lista_jogada.append(tmp)
            else:
                #A lista de jogadas do jogador um é maior do que do jogador dois
                if(tam_lista_1>tam_lista_2):                  
                   for i in range(0,len(lista_jogadas_jogador_1)):  
                      if i<10:
                        jogada="0"+str(i+1)        
                      else:
                        jogada=str(i+1)     
                      if (i>tam_lista_2):
                         tmp= jogada + ": " +lista_jogadas_jogador_1[i]  
                      else:
                         tmp= jogada + ": " +lista_jogadas_jogador_1[i] + " " + lista_jogadas_jogador_2[i]  
                      posicao=int(pos-1)
                      if(i==posicao):
                        lista_jogada.append(tmp)
                      
                else:                    
                    #A lista de jogadas do jogador dois é maior do que do jogador 1  
                    for i in range(0,len(lista_jogadas_jogador_2)):  
                       if i<10:
                         jogada="0"+str(i+1)        
                       else:
                         jogada=str(i+1)     
                       if (i>tam_lista_1):
                          tmp= jogada + ": " +lista_jogadas_jogador_2[i]  
                       else:
                           tmp= jogada + ": " +lista_jogadas_jogador_1[i] + " " + lista_jogadas_jogador_2[i]  
                       posicao=int(pos-1)
                       if(i==posicao):
                         lista_jogada.append(tmp)   
        else:
              print("Erro: Não existem jogadas")              
        return lista_jogada    
      else:
       return []
    '''
     Método que devolve a posição atual da linha da peça branca no tabuleiro 
    '''       
    def getposicao_linha_peca_branca(self):
        posicao=0
        try:
            for i in range(0,8):
                for j in range(0,8):
                    if(self.tab_estado[i][0][j]=="*"):
                        posicao= 8-int(i)                        
        except:
            print("Erro: na pesquisa do valor da coluna da peça branca")            
    
        return posicao
    '''
     Método que devolve a posição atual da coluna da peça branca no tabuleiro 
    '''   
    def getposicao_coluna_peca_branca(self):
        posicao=0
        try:
            for i in range(0,8):
                for j in range(0,8):
                    if(self.tab_estado[i][0][j]=="*"):
                       posicao=j+1                  
        except:
            print("Erro: na pesquisa do valor da coluna da peça branca")            
    
        return posicao
    
    '''
     Método que efetua a jogada para uma posição do tabuleiro
     colocando na linha e coluna o simbolo
    ''' 
    def setColocaNaCasa(self,linha, coluna, simbolo):
        #Atualizar a matriz    
        if (self.tab_estado != []):
            linha= 8-int(linha)
  
            self.setposicao_linha(linha)
            tmp=self.tab_estado[int(linha)][0]
            coluna= int(coluna)-1  
            self.setposicao_coluna(coluna)
            
            tmp2 = tmp[0:coluna] + simbolo + tmp[coluna+1:]
            self.tab_estado[int(linha)][0]=tmp2
       
        else:
             print('ERRO: Não foi carregado o tabuleiro.')
       
    '''
     Método que efetua a jogada para uma posição do tabuleiro
     entra como parametro a linha e a coluna e a descrição da jodaga ex: 3, 4, d3
    '''
    def setjogada(self,linha, coluna, jogada):  
        
       #Verificar se a jogada é válida; 
       print("A VALIDAR A JOGADA:",jogada)
       jogada_valida=self.validar_comando(jogada)
       if(jogada_valida):
          #Atualizar o simbolo da casa onde estava a peça branca
          #Obter as coordenadas da peca branca                                
          # Para visualizar - saber a posição inicial da peça branca:
          pos_linha= self.getposicao_linha_peca_branca()
          pos_coluna= self.getposicao_coluna_peca_branca()
          #Atualizar a posição anterior onde estava a peça branca
          self.setColocaNaCasa(pos_linha,pos_coluna,"#")
          if (self.tab_estado != []):
              linha= 8-int(linha)              
              self.setposicao_linha(linha)
              tmp=self.tab_estado[int(linha)][0]
              coluna= int(coluna)-1  
              self.setposicao_coluna(coluna)
              tmp2 = tmp[0:coluna] + "*" + tmp[coluna+1:]
              self.tab_estado[int(linha)][0]=tmp2     
              if self.getjogadas()==[]:
                 #Guardar na lista jogadas duas lista com as jogadas do jogador 1 e 2
                 #Como não há jogadas, inicializar a lista
                 self.jogadas.append([])
                 self.jogadas.append([])
                 #Registar a jogada
                 self.jogadas[0].append(jogada)
                 self.setjogador("2")
              else:
                  if (self.getjogador()=="1"):
                     #Registar a jogada
                     self.jogadas[0].append(jogada)
                     #Passa a jogada para o jogador 2
                     self.setjogador("2")
                  else:
                      #Registar a jogada
                      self.jogadas[1].append(jogada)
                      self.setjogador("1")           
              self.print_tab_estado()
          else:
              print('ERRO: Não foi carregado o tabuleiro.')
       else:
           self.print_tab_estado()
   
    '''
     Método que procede à validação do comando da jogada
    '''
    def validar_comando(self,arg):
        L=list(arg)
        Arg_val=False
        
        #transformar as colunas em números para referência
        let={'a':0,'b':1,'c':2,'d':3,'e':4,'f':5,'g':6,'h':7}
        
        #se a letra inserida estiver entre a e h, o valor inserido é válido
        for b in let:
            if L[0]==b:
                Arg_val=True
        
        #se o número inserido estiver entre 1 e 8, o valor é válido
        for x in range (1,9):
            if int(L[1])==x:
                Arg_val=True
        
        #caso alguma das condições acima referidas não se verifique, a jogada não poderá ser efetuada
        if Arg_val==False:
           print("Jogada inválida!")
        
        #caso a jogada seja válida para estes parâmetros, serão confirmadas condições seguintes
        else:            
            return self.Estado_casa(L)

    '''
     Método que verifica o estado da casa de jogo no tabuleiro
    '''
    def Estado_casa(self,L):
        pos_peca_br=self.get_peca_br()
        
        #transformar as linhas e colunas em números para referência
        let={'a':0,'b':1,'c':2,'d':3,'e':4,'f':5,'g':6,'h':7}
        num={'8':0,'7':1,'6':2,'5':3,'4':4,'3':5,'2':6,'1':7}        
        
        #obter o valor associado à letra introduzida na coordenada
        for b in let:
            if L[0]==b:
                i=let.get(b)
        
        #obter o valor associado ao número introduzido na coordenada
        for c in num:
            if L[1]==c:
                j=num.get(c)
                
        valido=False
        
        #Visto que a diferença entre o número de linhas da jogada anterior e da seguinte é sempre 0 ou 1, e o mesmo se verifica para as colunas, podemos definir um conjunto de casas jogáveis que rodeiam o local da peça
        if (abs(pos_peca_br[0]-j)<2 and abs(pos_peca_br[1]-i)<2):
             valido=True
        
        #Se todas as condições anteriores se verificarem, então verifica-se a última, referente às casas brancas disponíveis para serem jogadas
        if valido==True:     
            if self.tab_estado[j][0][i]=='.':
                if self.tab_estado[pos_peca_br[0]][0][pos_peca_br[1]]=='*':
                    self.set_peca_br([j,i])  #Este passo será essencial para o começo de novas jogadas, servindo de valor de referência
                    self.settab_estado(self.tab_estado)
                    #self.settab_estado(estado)
                    print ("JOGADA EFETUADA COM SUCESSO!")
                    return True
                #Alterações de jogador após jogada
                if self.getjogador()=='1':
                    self.setjogador('2')
                
                else:
                    self.setjogador('1')
            
            elif self.tab_estado[j][0][i]=='1':
                self.set_peca_br([j,i])
                self.settab_estado(self.tab_estado)
                print ("VENCEDOR: JOGADOR 1. PARABÉNS!")
                return True
            
            elif self.tab_estado[j][0][i]=='2':
                self.set_peca_br([j,i])
                self.settab_estado(self.tab_estado)
                print ("VENCEDOR: JOGADOR 2. PARABÉNS!")
                return True
                
            else:
                print("Erro:JOGADA BLOQUEADA!")
                return False
                
        else:
            print("Erro: JOGADA INVALIDA!")
            return False
            
        #Imrimir o tabuleiro novo
        self.print_tab_estado()
     

   
        '''
         Método que verifica se as casas que rodeiam a casa onde se localiza a peça branca se encontram disponíveis para jogar
         Entra como parametro as coordenadas da localização atual da peça branca 
        '''
    def Estado_casas_volta(self):  
        
        pos_peca_br=self.get_peca_br()
        
        coord_p=[] #lista na qual serão inseridas as coordenadas de todas as jogadas possíveis
        
        
        #Verificar se existem casas no local seginte à localização da peça branca
        temp_idx=pos_peca_br[0]-1
        if  (temp_idx>=0 and temp_idx<8):    

            if self.tab_estado[pos_peca_br[0]-1][0][pos_peca_br[1]]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0]-1)
                cnj_crd.append(pos_peca_br[1])
                coord_p.append(cnj_crd)
        
        temp_idx2=pos_peca_br[1]-1
        if temp_idx2>=0 and temp_idx2<8:
            if self.tab_estado[pos_peca_br[0]][0][pos_peca_br[1]-1]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0])
                cnj_crd.append(pos_peca_br[1]-1)
                coord_p.append(cnj_crd)
        
        temp_idx=pos_peca_br[0]+1
        if  (temp_idx>=0 and temp_idx<8): 
            
            if self.tab_estado[pos_peca_br[0]+1][0][pos_peca_br[1]]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0]+1)
                cnj_crd.append(pos_peca_br[1])
                coord_p.append(cnj_crd)
                
        temp_idx2=pos_peca_br[1]+1
        if (temp_idx2>=0 and temp_idx2<8):
            
            if self.tab_estado[pos_peca_br[0]][0][pos_peca_br[1]+1]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0])
                cnj_crd.append(pos_peca_br[1]+1)
                coord_p.append(cnj_crd)
                
        temp_idx=pos_peca_br[0]-1
        temp_idx2=pos_peca_br[1]+1
        if  temp_idx>=0 and temp_idx<8 and temp_idx2>=0 and temp_idx2<8:
            
            if self.tab_estado[pos_peca_br[0]+1][0][pos_peca_br[1]+1]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0]+1)
                cnj_crd.append(pos_peca_br[1]+1)
                coord_p.append(cnj_crd)
        
        temp_idx=pos_peca_br[0]+1
        temp_idx2=pos_peca_br[1]-1
        if  temp_idx>=0 and temp_idx<8 and temp_idx2>=0 and temp_idx2<8:
        
            if self.tab_estado[pos_peca_br[0]+1][0][pos_peca_br[1]-1]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0]+1)
                cnj_crd.append(pos_peca_br[1]-1)
                coord_p.append(cnj_crd)
        
        temp_idx=pos_peca_br[0]-1
        temp_idx2=pos_peca_br[1]+1
        if  temp_idx>=0 and temp_idx<8 and temp_idx2>=0 and temp_idx2<8:
        
            if self.tab_estado[pos_peca_br[0]-1][0][pos_peca_br[1]+1]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0]-1)
                cnj_crd.append(pos_peca_br[1]+1)
                coord_p.append(cnj_crd)
        
        temp_idx=pos_peca_br[0]-1
        temp_idx2=pos_peca_br[1]-1
        if  temp_idx>=0 and temp_idx<8 and temp_idx2>=0 and temp_idx2<8:
        
            if self.tab_estado[pos_peca_br[0]-1][0][pos_peca_br[1]-1]=='.' :
                cnj_crd=[]
                cnj_crd.append(pos_peca_br[0]-1)
                cnj_crd.append(pos_peca_br[1]-1)
                coord_p.append(cnj_crd)
        
        if self.getjogador()=='1':
            distancia=[]  #lista na qual serão inseridas todas as distâncias entre a casa possível de ser jogada e a casa alvo do jogador 1
            for i in range (0, len(coord_p)-1):
                dist=mt.sqrt(((coord_p[i][0]-7)**2)+((coord_p[i][1])-0)**2)  #Fórmula matemática para a distância entre dois pontos: sqrt((x1-x2)**2+(y1-y2)**2)
                distancia.append(dist)
        
            #minIndx será o índice na lista distância onde se encontra a distância mínima
            #este processo é utilizado, uma vez que tanto a lista coord_p, como a lista distancia, estão ordenadas de forma a que os seus índices sejam correspondentes
            minIdx = distancia.index(min(distancia))
            
            
            let={ 0:'a', 1:'b', 2:'c',3:'d',4:'e',5:'f',6:'g',7:'h'}
            num={0:'8',1:'7',2:'6',3:'5',4:'4',5:'3',6:'2',7:'1'}    
            
            
            res=coord_p[minIdx] #res foi utilizado como forma a obter somente uma lista que contenha os valores da coordenada da melhor jogada, de modo a serem utilizados na conversão dos valores para leitura clara do gráfico
            
            l=let.get(res[1])
            
            v=num.get(res[0])
            
        
        else:
            distancia=[] 
            for i in range (0, len(coord_p)-1):
                 dist=mt.sqrt(((coord_p[i][0]-0)**2)+((coord_p[i][1])-7)**2)
                 distancia.append(dist)
         
             
            minIdx = distancia.index(min(distancia))
             
            let={0:'a', 1:'b', 2:'c',3:'d',4:'e',5:'f',6:'g',7:'h'}
            num={0:'8',1:'7',2:'6',3:'5',4:'4',5:'3',6:'2',7:'1'}    
            
            res=coord_p[minIdx]
            
            l=let.get(res[1])
            
            v=num.get(res[0])
            
        return (l+v) #coordenadas finais
    
    def Jogada_val(self,arg):
        '''
        Este método permite avaliar se a jogada inserida é valida, recebendo como 
        parâmetros as coordenadas da mesma

        '''
        jogada=arg
        numero_jogada_coluna=arg[0:1]
        numero_jogada_linha=arg[1:2]                    
        #identificação da coluna bem introduzida                                      
        if(numero_jogada_coluna=="a") or (numero_jogada_coluna=="b") or (numero_jogada_coluna=="c") or (numero_jogada_coluna=="d") or (numero_jogada_coluna=="e") or (numero_jogada_coluna=="f") or (numero_jogada_coluna=="g") or (numero_jogada_coluna=="h"):
          #identificação da linha bem introduzida
          if (numero_jogada_linha=="1") or (numero_jogada_linha=="2") or (numero_jogada_linha=="3") or (numero_jogada_linha=="4") or (numero_jogada_linha=="5") or (numero_jogada_linha=="6") or (numero_jogada_linha=="7") or (numero_jogada_linha=="8"):                                
              if(numero_jogada_coluna=="a"):
                 coluna_a_jogar=1
              if(numero_jogada_coluna=="b"):
                 coluna_a_jogar=2
              if(numero_jogada_coluna=="c"):
                 coluna_a_jogar=3
              if(numero_jogada_coluna=="d"):
                 coluna_a_jogar=4
              if(numero_jogada_coluna=="e"):
                coluna_a_jogar=5
              if(numero_jogada_coluna=="f"):
                coluna_a_jogar=6
              if(numero_jogada_coluna=="g"):
                coluna_a_jogar=7
              if(numero_jogada_coluna=="h"):
               coluna_a_jogar=8
                                    
              self.setjogada(numero_jogada_linha,coluna_a_jogar,jogada)
              
          else:
            print("ERRO: Não foi identificada correctamente a linha, que tem de ser 1,2,3,4,5,6,7,8")   
            
        else:
            print("ERRO: Não foi identificada correctamente a coluna, que tem de ser a,b,c,d,e,f,g,h")  
