# -*- coding:utf-8 -*-

from cmd import *
from RastrosWindow import RastrosWindow
from RastrosEngine import RastrosEngine

class RastrosShell(Cmd):
    intro = 'Interpretador de comandos para o Rastros. Escrever help ou ? para listar os comandos disponíveis.\n'
    prompt = 'Rastros> '
                               
    def do_jogar(self, arg):
        " -  comando jogar que leva como parâmetro o nome de um ficheiro e carrega o tabuleiro permitindo jogá-lo..: jogar <nome_ficheiro> \n" 
        try:
            print("a testar")
            lista_arg = arg.split()
            num_args = len(lista_arg)
            if num_args == 1:              
                eng.ler_tabuleiro_ficheiro(lista_arg[0])
                eng.print_tab_estado()
                if janela is not None:
                    janela.mostraJanela(eng.gettab_estado())
            else:
                print("Número de argumentos inválido!")
        except:
            print("Erro: ao mostrar o puzzle")
            
    def do_gravar(self, arg):
        " - comando gravar que leva como parâmetro o nome de um ficheiro e permite gravar o estado do jogo atual..: gravar <nome_ficheiro>  \n"
        temp_tabuleiro=[] 
        temp_jogadas=[] 
        lista_arg = arg.split()
        num_args = len(lista_arg)
        if num_args == 1:
           try:           
               temp_tabuleiro= eng.gettab_estado()
               fich=open(arg, "w")
               for i in range(0,8):                
                   fich.write(str(temp_tabuleiro[i][0]))
                   fich.write("\n")
                
               temp_jogadas=eng.getmovimentos();
               fich.write("\n")
               for i in range(0,len(temp_jogadas)):
                   fich.write(str(temp_jogadas[i]))
                   fich.write("\n")
               fich.close()        
           except:
               print("Erro ao gravar ficheiro")            
    
        pass
        
    
    def do_coord(self, arg):    
        " - comando coordenada que leva como parâmetros a coluna e a linha de uma casa onde se pretende jogar..: <c><l>  \n"
       
        #ler os argumentos/parametros da invocação da função do_jogada
        lista_arg = arg.split()
        num_args = len(lista_arg)
        if num_args == 1: 
             if len(arg)==2:
                eng.Jogada_val(arg)
             else:
               print("ERRO: Indicação incorrecta da jogada")          
        else:
            print("ERRO: Indicação incorrecta da jogada ")
              
    
    def do_jogada(self, arg):    
        " - comando jogada que escolhe a melhor jogada para o jogador atual..: jogada  \n"
        jgd = eng.Estado_casas_volta()
        
        print("A MELHOR JOGADA SERIA:",jgd)
        pass
    
    def do_pos(self, arg):    
        " - comando posição que leva como parâmetro o nº da jogada a visualizar..: pos <no.>  \n"
        #ler os argumentos/parametros da invocação da função do_jogada
        lista_arg = arg.split()
        num_args = len(lista_arg)
        if num_args == 1:             
           lista=eng.getjogada(int(arg)) 
           if lista!=[]:
             for i in range(0,len(lista)):
                print(lista[i])
           else:
             print ("[]") 
        else:            
            print("ERRO: Indicação incorrecta da jogada ")
        pass
    
    def do_movs(self,arg):    
        " - comando movimentos que imprime a lista dos movimentos efetuados no jogo atual..: movs  \n"
        lista_arg = arg.split()
        num_args = len(lista_arg)
        print("Lista de Jogadas:")
        lista=eng.getmovimentos()
        if lista!=[]:
          for i in range(0,len(lista)):
             print(lista[i])
        else:
           print ("[]") 
        pass
    
    def do_bot(self, arg):    
        " - comando bot que leva com parâmetros o nome do ficheiro inicial e o nome do ficheiro final com a melhor jogada já eftuada..: bot <nome_ficheiro> <nome_ficheiro>  \n"
        print("Execução do comando bot") 
        temp_tabuleiro=[] 
        temp_jogadas=[] 
        lista_arg = arg.split()
        num_args = len(lista_arg)
        if num_args == 2:
           try:
               #Carregar o tabuleiro de ficheiro
               print("Ficheiro de leitura:",lista_arg[0])
               print("Ficheiro de Escrita:",lista_arg[1])
               #Carregar o tabuleiro               
               eng.ler_tabuleiro_ficheiro(lista_arg[0])  
               
               #Verificar se as casas que rodeiam a peça branca se encontram diponíveis para jogar e calcula qual a melhor jogada consoante o jogador em questão
               jgd=eng.Estado_casas_volta()
               
               #Joga as coordenadas obtidas na linha 120
               eng.Jogada_val(jgd)
               
               temp_tabuleiro= eng.gettab_estado()
               fich=open(str(lista_arg[1]), "w")
               for i in range(0,8):                
                   fich.write(str(temp_tabuleiro[i][0]))
                   fich.write("\n")
                
               temp_jogadas=eng.getmovimentos();
               fich.write("\n")
               for i in range(0,len(temp_jogadas)):
                   fich.write(str(temp_jogadas[i]))
                   fich.write("\n")
               fich.close()        
           except:
               print("Erro ao gravar ficheiro")            
        else:
             print("Erro: deverá introduzir dois parametros referente ao noem dos ficheiros")
        pass

    def do_ver(self, arg):    
        " - Comando para visualizar o estado atual do tabuleiro em ambiente grafico caso seja válido: VER  \n"
        global janela  # pois pretendo atribuir um valor a um identificador global
        if janela is not None:
            del janela  # invoca o metodo destruidor de instancia __del__()
        janela = RastrosWindow(40) 
        janela.mostraJanela(eng.gettab_estado())        
        
    def do_sair(self, arg):
        "Sair do programa Rastros: sair"
        print('Obrigado por ter utilizado o Rastros. Espero que tenha sido divertido!')
        global janela  # pois pretendo atribuir um valor a um identificador global
        if janela is not None:
                    del janela  # invoca o metodo destruidor de instancia __del__()
        return True

if __name__ == '__main__':
    eng = RastrosEngine()
    janela = None
    sh = RastrosShell()
    sh.cmdloop()
 
           