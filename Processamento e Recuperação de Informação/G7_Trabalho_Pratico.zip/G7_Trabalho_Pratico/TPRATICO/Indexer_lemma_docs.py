import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import ujson

# Preprosessing data before indexing
with open('htmls.json', 'r') as doc:
    scraper_results = doc.read()

# Initialize empty lists to store publication name, URL, author, and date
docName = []
docHtml = []


# Load the scraped results using ujson
data_dict = ujson.loads(scraper_results)

# Get the length of the data_dict (number of publications)
array_length = len(data_dict)
print(array_length)

# Separate name, url, date, author in different file
for key, value in data_dict.items():
    docName.append(key)
    docHtml.append(value)
   

with open('doc_name.json', 'w') as f:
    ujson.dump(docName, f)

with open('doc_html.json', 'w') as f:
    ujson.dump(docHtml, f)


# Open a file with publication names in read mode
with open('doc_html.json', 'r') as f:
    publication = f.read()

# Load JSON File
pubName = ujson.loads(publication)

# Downloading libraries to use its methods
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

# Predefined stopwords in nltk are used
stop_words = stopwords.words('english')
lemmatizer = WordNetLemmatizer()
pub_list_first_lemma = []
pub_list = []
pub_list_wo_sc = []

for file in pubName:
    # Splitting strings to tokens(words)
    words = word_tokenize(file)
    lemma_word = ""
    for i in words:
        if i.lower() not in stop_words:
            lemma_word += lemmatizer.lemmatize(i) + " "
    pub_list_first_lemma.append(lemma_word)
    pub_list.append(file)

# Removing all below characters
special_characters = '''!()-—[]{};:'"\, <>./?@#$%^&*_~0123456789+=’‘'''
for file in pub_list:
    word_wo_sc = ""
    if len(file.split()) == 1:
        pub_list_wo_sc.append(file)
    else:
        for a in file:
            if a in special_characters:
                word_wo_sc += ' '
            else:
                word_wo_sc += a
        pub_list_wo_sc.append(word_wo_sc)

# Lemmatization Process
pub_list_lemma_wo_sw = []
for name in pub_list_wo_sc:
    words = word_tokenize(name)
    lemma_word = ""
    for a in words:
        if a.lower() not in stop_words:
            lemma_word += lemmatizer.lemmatize(a) + ' '
    pub_list_lemma_wo_sw.append(lemma_word.lower())

data_dict = {}  # Inverted Index holder

# Indexing process
for a in range(len(pub_list_lemma_wo_sw)):
    for b in pub_list_lemma_wo_sw[a].split():
        if b not in data_dict:
            data_dict[b] = [a]
        else:
            data_dict[b].append(a)

print(len(pub_list_wo_sc))
print(len(pub_list_lemma_wo_sw))
print(len(pub_list_first_lemma))
print(len(pub_list))

with open('doc_list_lemmatized.json', 'w') as f:
    ujson.dump(pub_list_first_lemma, f)

with open('doc_indexed_dictionary_lemmatized.json', 'w') as f:
    ujson.dump(data_dict, f)
