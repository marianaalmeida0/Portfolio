

import ModuloFuncoes as fun
import PySimpleGUI as sg
import os.path
from PIL import Image
import io



botoes = [
    [sg.Button("1-Carregar Cinemateca")],
    [sg.Text("Ficheiro:"), sg.Input(size=(25,1), key="-CARREGAR-")],
    [sg.Button('2-Inserir Filme')],
    [sg.Button('3-Alterar registo')],
    [sg.Text("Id a alterar:"), sg.Input(size=(10,1), key="-IDALT-")],
    [sg.Button('4-Consultar filme por id')], 
    [sg.Text("Id a consultar:"), sg.Input(size=(10,1), key="-ID-")],
    [sg.Button('5-Consultar filme por título')], 
    [sg.Text("Título:"), sg.Input(size=(25,1), key="-TITULO-")],
    [sg.Button('6-Listar todos os filmes por título')],
    [sg.Button('7-Listar filmes de um ator')],
    [sg.Text("Nome:"), sg.Input(size=(25,1), key="-ATOR-")],
    [sg.Button("8-Listar filmes por ator")],
    [sg.Button('9-Listar filmes de um género')],
    [sg.Text("Género:"), sg.Input(size=(25,1), key="-GENERO-")],
    [sg.Button('10-Distribuição por género')],
    [sg.Button('11-Listar filmes por género')],
    [sg.Button('12-Nº Total de Filmes'), sg.Button('13-TOP 10 Atores')],
    [sg.Button('14-Guardar Cinemateca')],
    [sg.Text("Novo ficheiro:"), sg.Input(size=(25,1), key="-GUARDAR-")],
    [sg.Button('Sair')]
    ]


lista=[]
coluna = [
         [sg.Listbox(values=lista, select_mode='extended', key='-LISTA-', size=(100,30)) ],
         [sg.Image(key="-IMAGEM-")]
         ]


layout = [[
        sg.Column(botoes, size=(300,600)),
        sg.VSeperator(),
        sg.Column(coluna),
        ]]


janela=sg.Window("Cinemateca", font="Helvetica 9", default_element_size=(20,1) , resizable=True).Layout(layout)
            

def funcaoErro(nome, mensagem, mensagem2):
    layout=[[sg.Text(mensagem, font="Arial 24")],
            [sg.Text(mensagem2, font="Arial 24")],
           [sg.Button("Ok")]]
    janelaErro= sg.Window(nome,font="Arial 30", 
                  default_element_size=(70,10)).Layout(layout)
    stop = False

    while not stop:
        event, values = janelaErro.read()
        if event == "Ok" or event == sg.WIN_CLOSED:
            stop = True
    janelaErro.close()



def funcaoInserir(bd):
    lista=["Comedy","Family","Drama","Science Fiction","Thriller","Documentary","Western","Crime","Action","Romance","Satire","Adventure","Biography","Horror","Musical","Historical","Animated","Fantasy","War","Mystery","Short","Superhero","Performance","Sports","Live Action","Disaster","Teen","Suspense","Noir", "Political","Silent","Spy","Dance", "Martial Arts","Supernatural","Legal","Independent", "Erotic","Slasher","Found Footage"]
            
    
    listaatores=[]
    botoes = [
                [sg.Text("Introduza o título:"), sg.Input(key="-TITULO-", size=(25,1)) ],
                [sg.Text("Introduza o ano:"), sg.Input(size=(5,1), key="-ANO-")],
                [sg.Text("Introduza atores:"),  sg.Input(size=(25,1), key="-ATORES-"), sg.Button("Adicionar"), sg.Button("Remover")],
                [sg.Listbox(values=listaatores,size=(60,5), select_mode='extended', key='-LISTAATORES-')],
                [sg.Text("Escolha os géneros:")], 
                [sg.Listbox(values=lista, select_mode='multiple', key='-LISTAGEN-', size=(60,10)) ],
                [sg.Button('Guardar')]]    
                
    janelaInserir=sg.Window("Inserir Filme", font="Helvetica 12", default_element_size=(20,1)).Layout(botoes)
        
        
    stop = False
    listageneros=[]
    listaatores=[]
    titulo=""
    ano=""   
        
    while not stop:
            event, values = janelaInserir.read()
            if event == "Okay" or event == sg.WIN_CLOSED:
                stop = True
            elif event=="Adicionar":
                if values['-ATORES-']!="":
                    ###PARA FAZER: VERIFICAR SE OS FORAM INTRODUZIDOS NOMES C VIRGULAS
                    listaatores.append(values['-ATORES-']) 
                    janelaInserir['-LISTAATORES-'].update(listaatores)
                    janelaInserir['-ATORES-'].update("")
                else:
                    funcaoErro("ERRO", "Escreva algum nome antes de adicionar", "")
            elif event=="Remover":
                if values['-LISTAATORES-']!=[]:
                    listaatores.remove(str(values['-LISTAATORES-'][0]))
                    janelaInserir['-LISTAATORES-'].update(listaatores)
                    janelaInserir['-ATORES-'].update("")
                        
            elif event=="Guardar":
                titulo=values['-TITULO-']
                ano=values['-ANO-']
                listageneros=values['-LISTAGEN-']
                
                if values['-TITULO-']=="":
                    funcaoErro("ERRO","Introduza um titulo antes de gravar.", "")
                elif values['-ANO-']=="":
                    funcaoErro("ERRO", "Introduza o ano antes de gravar.", "")
                elif listaatores==[]:
                    funcaoErro("ERRO", "Introduza os atores, nome a nome, antes de gravar.", "")
                elif listageneros==[]:
                    funcaoErro("ERRO", "Introduza os géneros antes de gravar.", "")
                else:
                    fun.inserirNovoFilme(bd, titulo, ano, listaatores, listageneros)
                    num=len(bd)
                    mensagem="O filme foi guardado com o Id" + str(num) +  " na base de dados" 
                    funcaoErro("AVISO", mensagem, "Para guardar as alterações no ficheiro, é necessário Guardar Cinemateca! ")
                    stop = True
                         
    janelaInserir.close()


def funcaoAlterar(bd, id, filme):    
    lista=["Comedy","Family","Drama","Science Fiction","Thriller","Documentary","Western","Crime","Action","Romance","Satire","Adventure","Biography","Horror","Musical","Historical","Animated","Fantasy","War","Mystery","Short","Superhero","Performance","Sports","Live Action","Disaster","Teen","Suspense","Noir", "Political","Silent","Spy","Dance", "Martial Arts","Supernatural","Legal","Independent", "Erotic","Slasher","Found Footage"]
    listageneros=filme['genres']
    for i in lista:
        if i in listageneros:
            lista.remove(i)
    listaatores=filme['cast']
    botoes = [  
                [sg.Text("Introduza o título:"), sg.Input(filme['title'], key="-TITULO-", size=(60,1)) ],
                [sg.Text("Introduza o ano:"), sg.Input(filme['year'], size=(5,1), key="-ANO-")],
                [sg.Text("Introduza atores:"),  sg.Input(size=(60,1), key="-ATORES-"), sg.Button("Adicionar Ator"), sg.Button("Remover Ator")],
                [sg.Listbox(values=filme['cast'],size=(95,5), select_mode='extended', key='-LISTAATORES-')],
                [sg.Text("Escolha os géneros:")], 
                [sg.Listbox(values=lista, select_mode='single', key='-LISTAGENTOTAL-', size=(30,10)), sg.Button("Adicionar Género"), sg.Button("Remover Género") ,sg.Listbox(values=listageneros, select_mode='single', key='-LISTAGEN-', size=(30,10)) ],
                
                [sg.Button('Guardar')]]    
                
    janelaAlterar=sg.Window("Alterar Registo", font="Helvetica 12", default_element_size=(20,1)).Layout(botoes)
       
    #print (listagen)
    stop = False
     
        
    while not stop:
            event, values = janelaAlterar.read()
            #values['-LISTAGEN-']=listagen
            #values['-LISTAGEN-'].select_set('Comedy')
            #janelaAlterar['-LISTAGEN-'].select_set('Comedy')
            
            if event == "Okay" or event == sg.WIN_CLOSED:
                stop = True
         
            elif event=="Adicionar Ator":
                if values['-ATORES-']!="":
                    
                    listaatores.append(values['-ATORES-']) 
                    janelaAlterar['-LISTAATORES-'].update(listaatores)
                    janelaAlterar['-ATORES-'].update("")
                else:
                    funcaoErro("ERRO", "Escreva algum nome antes de adicionar", "")
            elif event=="Remover Ator":
                
                if values['-LISTAATORES-']!=[]:
                    listaatores.remove(str(values['-LISTAATORES-'][0]))
                    
                    janelaAlterar['-LISTAATORES-'].update(filme['cast'])
                    janelaAlterar['-ATORES-'].update("")
                    
                else:
                    funcaoErro("ERRO", "Selecione algum nome antes de remover", "")
                    
            elif event=="Adicionar Género":
                if values['-LISTAGENTOTAL-']!=[]:
                    listageneros.append(str(values['-LISTAGENTOTAL-'][0]))
                    janelaAlterar['-LISTAGEN-'].update(listageneros)
                    lista.remove(str(values['-LISTAGENTOTAL-'][0]))
                    
                    janelaAlterar['-LISTAGENTOTAL-'].update(lista)
                    
                else:   
                    funcaoErro("ERRO", "Selecione algum género antes de adicionar", "")
                    
            elif event=="Remover Género":
                if values['-LISTAGEN-']!=[]:
                    lista.append(str(values['-LISTAGEN-'][0]))
                    janelaAlterar['-LISTAGENTOTAL-'].update(lista)
                    
                    listageneros.remove(str(values['-LISTAGEN-'][0]))
                    
                 
                    janelaAlterar['-LISTAGEN-'].update(listageneros) 
                else:
                    funcaoErro("ERRO", "Selecione algum género antes de remover", "")
                pass
            
            elif event=="Guardar":
                titulo=values['-TITULO-']
                ano=values['-ANO-']
                
                if values['-TITULO-']=="":
                    funcaoErro("ERRO","Introduza um titulo antes de gravar.", "")
                elif values['-ANO-']=="":
                    funcaoErro("ERRO", "Introduza o ano antes de gravar.", "")
                elif filme['cast']==[]:
                    funcaoErro("ERRO", "Introduza os atores, nome a nome, antes de gravar.", "")
                elif listageneros==[]:
                    funcaoErro("ERRO", "Introduza os géneros antes de gravar.", "")
                else:
                    fun.alterarRegisto(cinemateca, id, titulo, ano, filme['cast'], listageneros)
                    mensagem="O filme foi alterado na base de dados" 
                    funcaoErro("AVISO", mensagem, "Para guardar as alterações no ficheiro, é necessário Guardar Cinemateca! ")
                    
                    stop = True
                         
    janelaAlterar.close()
    

def funcaoImagem(distribgen):
    fun.plotDistribuicaoPorGenero(distribgen)
    image=Image.open('DISTRIBUICAO.PNG')
    bio=io.BytesIO()
    image.save(bio, format="PNG")
    layout = [[sg.Image('DISTRIBUICAO.png')],
          [sg.Button('OK')]]
    janelaImagem = sg.Window('Image', layout, default_element_size=(20,1), resizable=True)
    event = janelaImagem.read() 
    janelaImagem.close()  
        
            
            
    

cinemateca=[]
stop =False
while not stop:
    
    event, values=janela.read()
    
    if event== sg.WIN_CLOSED:
        stop=True
        
    elif event=="1-Carregar Cinemateca":
       
        janela["-IDALT-"].update("")
        janela["-ID-"].update("")
        janela["-ATOR-"].update("")
        janela["-GENERO-"].update("")
        janela["-GUARDAR-"].update("")
        janela["-TITULO-"].update("")
        
        if values['-CARREGAR-']=="":
            funcaoErro("ERRO","Escreva o nome do ficheiro antes de clicar no botão!", "")
        
        else:
            if values['-CARREGAR-'][-5:]!=".json":
                valorx=False
                fichexists = os.path.exists(str(str(values['-CARREGAR-'])+".json"))
                
            else:
               valorx=True
               fichexists = os.path.exists(str(values['-CARREGAR-']))
               
            if fichexists==False:
               funcaoErro("ERRO", "O ficheiro pretendido não existe na diretoria!","")
            else: 
                if valorx==False:
                    cinemateca=fun.carregarBD(str(str(values['-CARREGAR-'])+".json"))
                    if 'id' in fun.getList(cinemateca[0]):
                        lista=[]
                        janela["-LISTA-"].update(lista)
                        mens="Foram carregados " + str(len(cinemateca)) + " filmes"
                        lista.append(mens)
                        janela["-LISTA-"].update(lista)
                        
                        
                    else:
                        cinemateca=fun.lerDataset((str(values['-CARREGAR-'])+".json"))
                        lista=[]
                        janela["-LISTA-"].update(lista)
                        mens="Foram carregados " + str(len(cinemateca)) + " filmes"
                        lista.append(mens)
                        janela["-LISTA-"].update(lista)
                        
                
                else:  
                    cinemateca=fun.carregarBD(str(str(values['-CARREGAR-'])))
                    if 'id' in fun.getList(cinemateca[0]):
                        lista=[]
                        janela["-LISTA-"].update(lista)
                        mens="Foram carregados " + str(len(cinemateca)) + " filmes"
                        lista.append(mens)
                        janela["-LISTA-"].update(lista)
                        
                    else:
                        cinemateca=fun.lerDataset(str(values['-CARREGAR-']))
                        lista=[]
                        janela["-LISTA-"].update(lista)
                        mens="Foram carregados " + str(len(cinemateca)) + " filmes"
                        lista.append(mens)
                        janela["-LISTA-"].update(lista)
                        


    elif event=="2-Inserir Filme":
        janela["-ID-"].update("")
        janela["-IDALT-"].update("")
        janela["-TITULO-"].update("")
        janela["-ATOR-"].update("")
        janela["-GENERO-"].update("")
        janela["-GUARDAR-"].update("")
        if cinemateca==[]:
            funcaoErro("ERRO","Queira carregar uma base de dados antes de inserir filmes!", "")
            
        else:
            funcaoInserir(cinemateca)
            

    elif event=="3-Alterar registo":
        
        janela["-ID-"].update("")
        janela["-TITULO-"].update("")
        janela["-ATOR-"].update("")
        janela["-GENERO-"].update("")
        janela["-GUARDAR-"].update("")
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de alterar!", "")
            
        else:
            idd=str(values['-IDALT-'])
            valor2, id=fun.verificarId(idd)
            if valor2==False:
                funcaoErro("ERRO", "Utilize a estrutura idxx! Por exemplo: id03 ou id3", "")
            else:
                consulta=fun.consultarID(cinemateca, str(id))
                valor, filme = consulta
                
                if valor==False:
                    
                   funcaoErro("ERRO", "Nenhum filme com este id foi encontrado...", "")
                else: 
                    funcaoAlterar(cinemateca, id, filme)
                    
                                    
                    
            
    elif event=="4-Consultar filme por id":
        janela["-IDALT-"].update("")
        janela["-TITULO-"].update("")
        janela["-ATOR-"].update("")
        janela["-GENERO-"].update("")
        janela["-GUARDAR-"].update("")
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de procurar por id!", "")
            
        else:

            idd=str(values['-ID-'])
            valor2, id=fun.verificarId(idd)
            if valor2==False:
                funcaoErro("ERRO", "Para pesquisar por id utilize a estrutura idxx! Por exemplo: id03 ou id3", "")
            else:
                consulta=fun.consultarID(cinemateca, str(id))
                valor, filme = consulta
                
                if valor==False:
                    
                   funcaoErro("ERRO", "Nenhum filme com este id foi encontrado...", "")
                else:   
                    lista=[]
                    janela["-LISTA-"].update(lista)
                    
                    cabecalho=fun.espacosCabecalho()
                    lista.append(cabecalho)
                    
                    if (len(str(filme['id']))==3):
                        espacosextra=(14-2*len(str(filme['id']))) * " "
                    else:    
                        espacosextra=(13-2*len(str(filme['id']))) * " "

                    detalhesfilme="|"+str(filme['id'])+ espacosextra
                    
                    espacosextra=(47-2*len(str(filme['title']))) * " "
                    detalhesfilme=detalhesfilme+"|"+str(filme['title'])+ espacosextra
                    
                    espacosextra=(15-2*len(str(filme['year']))) * " "
                    detalhesfilme=detalhesfilme+"|"+str(filme['year'])+ espacosextra
                    
                    espacosextra=(80-2*len(str(filme['cast']))) * " "
                    detalhesfilme=detalhesfilme+"|"+ str(fun.lerLista(filme['cast'])) + espacosextra 
                    
                    
                    espacosextra=(40-2*len(str(filme['genres']))) * " "
                    detalhesfilme=detalhesfilme+"|"+str(fun.lerLista(filme['genres']))+ espacosextra
                    
                    
                    lista.append(detalhesfilme)
                    janela["-LISTA-"].update(lista)
                    
    elif event=='5-Consultar filme por título': 
        
        janela["-IDALT-"].update("")
        janela["-ID-"].update("")
        janela["-ATOR-"].update("")
        janela["-GENERO-"].update("")
        janela["-GUARDAR-"].update("")
        
        
        if cinemateca==[]:
            funcaoErro("ERRO","Queira carregar uma base de dados antes de listar os filmes!", "")
            
        else:
            if values["-TITULO-"]!="":
                
                lista=[]
                janela["-LISTA-"].update(lista)
                
                consulta=fun.consultarTitulo(cinemateca, values["-TITULO-"])
                listafilme = consulta
                    
                if consulta==[]:
                        
                       funcaoErro("ERRO", "Nenhum filme com este título foi encontrado...", "")
                else: 
                        lista=[]
                        janela["-LISTA-"].update(lista)
                        cabecalho=fun.espacosCabecalho()
                        lista.append(cabecalho)
                        for filme in consulta:
                            espacosextra=(13-2*len(str(filme['id']))) * " "
                            detalhesfilme="|"+str(filme['id'])+ espacosextra
                            
                            espacosextra=(47-2*len(str(filme['title']))) * " "
                            detalhesfilme=detalhesfilme+"|"+str(filme['title'])+ espacosextra
                            
                            espacosextra=(15-2*len(str(filme['year']))) * " "
                            detalhesfilme=detalhesfilme+"|"+str(filme['year'])+ espacosextra
                            
                            espacosextra=(80-2*len(str(filme['cast']))) * " "
                            detalhesfilme=detalhesfilme+"|"+ str(fun.lerLista(filme['cast'])) + espacosextra 
                            
                            
                            espacosextra=(40-2*len(str(filme['genres']))) * " "
                            detalhesfilme=detalhesfilme+"|"+str(fun.lerLista(filme['genres']))+ espacosextra
                            lista.append(detalhesfilme)
                            
                        janela["-LISTA-"].update(lista)
            else:
                funcaoErro("ERRO", "Escreva um título antes de consultar...", "")
                    
    
    elif event=='6-Listar todos os filmes por título': 
        if cinemateca==[]:
            funcaoErro("ERRO","Queira carregar uma base de dados antes de listar os filmes!", "")
            
        else:
            lista=[]
            janela["-LISTA-"].update(lista)
            
            
            cabecalho=fun.espacosCabecalho()
            lista.append(cabecalho)
            cinemateca.sort(key=fun.chaveOrd)
            
            for filme in cinemateca:
                
                if (len(str(filme['id']))==3):
                        espacosextra=(14-2*len(str(filme['id']))) * " "
                else:    
                        espacosextra=(13-2*len(str(filme['id']))) * " "

                detalhesfilme="|"+str(filme['id'])+ espacosextra
                
                espacosextra=(47-2*len(str(filme['title']))) * " "
                detalhesfilme=detalhesfilme+"|"+str(filme['title'])+ espacosextra
                    
                espacosextra=(15-2*len(str(filme['year']))) * " "
                detalhesfilme=detalhesfilme+"|"+str(filme['year'])+ espacosextra
                    
                espacosextra=(80-2*len(str(filme['cast']))) * " "
                detalhesfilme=detalhesfilme+"|"+ str(fun.lerLista(filme['cast'])) + espacosextra 
                    
                    
                espacosextra=(40-2*len(str(filme['genres']))) * " "
                detalhesfilme=detalhesfilme+"|"+str(fun.lerLista(filme['genres']))+ espacosextra
                lista.append(detalhesfilme)
                
            janela["-LISTA-"].update(lista)
              
            
    elif event=='7-Listar filmes de um ator':  
        
        janela["-IDALT-"].update("")
        janela["-ID-"].update("")
        janela["-TITULO-"].update("")
        janela["-GENERO-"].update("")
        janela["-GUARDAR-"].update("")
        
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de listar os filmes!", "")
        else:
            if values['-ATOR-']!="":
                valor, listafator=fun.listarPorAtor(cinemateca, values['-ATOR-'])
                lista=[]
                janela["-LISTA-"].update(lista)
                
                if valor==False:
                    
                    mensagem1="Não foram encontrados filmes com este ator"
                    mensagem2="Verifique se escreveu corretamente o nome do ator"
                    
                    
                    lista.append(mensagem1)
                    lista.append(mensagem2)
                    janela["-LISTA-"].update(lista)
                
                else:
                    cabecalho="Id | Título                               | Ano  |  ELenco                       | Géneros          "
                    lista.append(cabecalho)
                    
                    for filme in listafator:
                        
                        detalhesfilme=str(filme['id'])+ "|" + str(filme['title'])+"|"+ str(filme['year'])+"|"+ (fun.lerLista(filme['cast']))+ "|" +(fun.lerLista(filme['genres']))
                        lista.append(detalhesfilme)
                    janela["-LISTA-"].update(lista)
            else:
                funcaoErro("ERRO", "Escreva um nome antes de consultar...", "")
    
    elif event=='8-Listar filmes por ator':
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de procurar por id!", "")
            
        else:
            lista=[]
            janela["-LISTA-"].update(lista)
            listaatorfilme=fun.listaAtorFilme(cinemateca)
            for tuplo in listaatorfilme:
                ator, filmes=tuplo
                mensg="Filmes de " + ator
                lista.append(mensg)
                for filme in filmes:
                    id, titulo=filme
                    lista.append(id + "|" + titulo)
                lista.append("_______________________________")
                
            janela["-LISTA-"].update(lista)
            
            
         
    elif event=='9-Listar filmes de um género':  
        
        janela["-IDALT-"].update("")
        janela["-ID-"].update("")
        janela["-TITULO-"].update("")
        janela["-ATOR-"].update("")
        janela["-GUARDAR-"].update("")
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de listar os filmes!", "")
        else:
            if values['-GENERO-']!="":
                
                generos=["Comedy","Family","Drama","Science Fiction","Thriller","Documentary","Western","Crime","Action","Romance","Satire","Adventure","Biography","Horror","Musical","Historical","Animated","Fantasy","War","Mystery","Short","Superhero","Performance","Sports","Live Action","Disaster","Teen","Suspense","Noir", "Political","Silent","Spy","Dance", "Martial Arts","Supernatural","Legal","Independent", "Erotic","Slasher","Found Footage"]
                if values['-GENERO-'] in generos:
                    lista=[]
                    janela["-LISTA-"].update(lista)
                    cabecalho="Id | Título                               | Ano  |  ELenco                       | Géneros          "
                    lista.append(cabecalho)
                    listafilmgen=fun.listarPorGenero(cinemateca, values['-GENERO-'])
                    
                    for filme in listafilmgen:
                        detalhesfilme=str(filme['id'])+ "|" + str(filme['title'])+"|"+ str(filme['year'])+"|"+ (fun.lerLista(filme['cast']))+ "|" +(fun.lerLista(filme['genres']))
                        lista.append(detalhesfilme)
                    janela["-LISTA-"].update(lista)
             
                else:
                    generonovo=values['-GENERO-'][0].upper()+values['-GENERO-'][1:].lower()
                    if generonovo not in generos:
                        mensagem="Este género de filme não existe na lista de géneros, verifique as maiusculas no início e"
                        mensagem2="se está escrito em inglês"
                        funcaoErro("ERRO", mensagem, mensagem2)
                    else:
                        lista=[]
                        janela["-LISTA-"].update(lista)
                        cabecalho="Id | Título                               | Ano  |  ELenco                       | Géneros          "
                        lista.append(cabecalho)
                        
                        listafilmgen=fun.listarPorGenero(cinemateca, generonovo)
                        for filme in listafilmgen:
                            detalhesfilme=str(filme['id'])+ "|" + str(filme['title'])+"|"+ str(filme['year'])+"|"+ (fun.lerLista(filme['cast']))+ "|" +(fun.lerLista(filme['genres']))
                            lista.append(detalhesfilme)
                            
                        janela["-LISTA-"].update(lista)
            else:
                funcaoErro("ERRO", "Escreva um género antes de listar...", "")
         
         
    elif event=='10-Distribuição por género':  
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de calcular a distribuição", "")
        else:
            lista=[]
            janela["-LISTA-"].update(lista)
            cabecalho="Género        |Número de Filmes          "
            lista.append(cabecalho)
            distribgen=fun.distribGenero(cinemateca)
            
            chaves=fun.getList(distribgen)
            tamanho=len(chaves)
                    
            for i in range (tamanho):
                chave=str(chaves[i])
                valor=distribgen[chave]
                string=str(chave) + "|" + str(valor)
                lista.append(string)
                string=""

            
            janela["-LISTA-"].update(lista)
            funcaoImagem(distribgen)
              
    
    elif event=='11-Listar filmes por género':
        
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de procurar por id!", "")
            
        else:
            lista=[]
            janela["-LISTA-"].update(lista)
            listagenfilme=fun.listaGeneroFilme(cinemateca)
            for tuplo in listagenfilme:
                genero, filmes=tuplo
                mensg="Filmes de " + genero
                lista.append(mensg)
                for filme in filmes:
                    id, titulo=filme
                    lista.append(id + "|" + titulo)
                lista.append("____________________________________________")
                
            janela["-LISTA-"].update(lista)
            
           
    
    elif event=='12-Nº Total de Filmes': 
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes", "")
        else:
            lista=[]
            janela["-LISTA-"].update(lista)
            total=fun.numeroFilmes(cinemateca)
            mensagem="Existem " + str(total) + " filmes nesta cinemateca"
            lista.append(mensagem)
            janela["-LISTA-"].update(lista)
    
    
    elif event=='13-TOP 10 Atores': 
        if cinemateca==[]:
            funcaoErro("ERRO", "Queira carregar uma base de dados antes de procurar o TOP10", "")
            
        else:
            lista=[]
            janela["-LISTA-"].update(lista)
            top10=fun.top10(cinemateca)
            cabecalho="Ator                        |Número de Filmes          "
            lista.append(cabecalho)
            chaves2=fun.getList(top10)
            tamanho2=len(chaves2)
                    
            for i in range (tamanho2):
                chave=str(chaves2[i])
                valor=top10[chave]
                string=str(chave) + "|" + str(valor)
                lista.append(string)
                string=""
        
            janela["-LISTA-"].update(lista)
            
    
    
        
    elif event=='14-Guardar Cinemateca':
        janela["-IDALT-"].update("")
        janela["-ID-"].update("")
        janela["-TITULO-"].update("")
        janela["-ATOR-"].update("")
        janela["-GENERO-"].update("")
        if cinemateca==[]:
            funcaoErro("ERRO","Queira carregar uma base de dados antes de guardar!", "")
            
        else:
            if values['-GUARDAR-']!="":
                if values['-GUARDAR-'][-5:]!=".json":
                    funcaoErro("AVISO","O ficheiro foi guardado em formato json!", "") 
                    fun.guardarBD(cinemateca, (values['-GUARDAR-']+".json"))
                else:
                    fun.guardarBD(cinemateca, (values['-GUARDAR-']))
            else:
                funcaoErro("ERRO", "Escreva um nome para o ficheiro antes de guardar...", "")
      
     
    elif event=='Sair':
            stop=True
        
janela.close()   
