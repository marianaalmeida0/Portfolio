
import matplotlib.pyplot as plt
import json


#######################################################################################################
#Requisito 0 - Ler DataSet
#######################################################################################################

def lerDataset(fnome):
    f = open(fnome, encoding="utf-8")
    bd = []
 
    bd=json.load(f)
    i=1
    for filme in bd:
        filme['id']= "id" +str(i)
        i=i+1
    print ("Foram carregados " + str(len(bd)) + "filmes.")
    return bd



#######################################################################################################
#Requisito 1/2
#######################################################################################################

def guardarBD(bd, fnome):
    f=open(fnome, 'w', encoding='utf-8')
    json.dump(bd, f, ensure_ascii=False, indent=4)

    

def carregarBD(fnome):
    bd=[]
    f=open(fnome, encoding='utf-8')
    bd=json.load(f)
    return bd


#######################################################################################################
#Requisito 3 - Inserir novo filme
#######################################################################################################

def inserirNovoFilme(bd, titulo, ano, castt, generos):
    id="id" + str((len(bd))+1)
    dicNovoFilme={}
    dicNovoFilme['title']=titulo
    dicNovoFilme['year']=ano 
    dicNovoFilme['cast']=castt  
    dicNovoFilme['genres']=generos 
    dicNovoFilme['id']= id
    bd.append(dicNovoFilme)
    return bd


#######################################################################################################
#Requisito 4 - Consultar a partir do id
#######################################################################################################


def consultarID(bd, id):
    i=0
    valor=False
    while valor!=True and i<(len(bd)):
        if bd[i]['id']==id:
            valor =True
            i=i+1
        else:
            i=i+1
    return (valor, bd[i-1])



def consultarTitulo(bd, titulo):
    lista=[]
    for filme in bd:
        if filme['title'].lower()==titulo.lower():
            lista.append(filme)
        elif titulo.lower() in filme['title'].lower():
            lista.append(filme)
    return  lista



#######################################################################################################
#Requisito 5 - Listar por ordem alfabética de titulo  
#######################################################################################################

def chaveOrd(filme):
    return (filme["title"])
  
    
def listarTituloOrdenado(bd):
    bd.sort(key=chaveOrd)
    return bd            



#######################################################################################################
#Requisito 6 - Listar filmes de um genero
#######################################################################################################

def listarPorGenero(bd, genero):
    listafilmesgenero=[]
    for filme in bd:
        if genero in filme['genres']:
            listafilmesgenero.append(filme)
    return listafilmesgenero



#######################################################################################################
#Requisito 7 - Listar filmes de um ator
#######################################################################################################

def listarPorAtor(bd, ator):
    ator1=ator.lower()
    listafilmesator=[]
    valor=False
    for filme in bd:
        for nome in filme['cast']:
            if ator1 in nome.lower():
                listafilmesator.append(filme)
                valor=True
    return (valor, listafilmesator)





#######################################################################################################
#Requisito 8 - Indicadores Estatísticos - Numero de filmes
#######################################################################################################

def numeroFilmes(bd):
    numeroFilmes= len(bd)
    return numeroFilmes


#######################################################################################################
#Requisito 8 - Indicadores Estatísticos - Distribuição por Géneros
#######################################################################################################

def distribGenero(bd):
    distribuicaogenero={}
    for filme in bd:
        for genero in filme['genres']:
            if genero in distribuicaogenero.keys():
                distribuicaogenero[genero]=distribuicaogenero[genero]+1
            else:
                distribuicaogenero[genero]=1
        
    return distribuicaogenero




def plotDistribuicaoPorGenero(distrib):
    x=distrib.keys()
    y=[]
    for i in x:
        y.append(distrib[i])
    plt.figure(figsize=(12,8.5))
    plt.xticks(rotation=90)
    
    plt.bar(x, y)
    
    plt.savefig('DISTRIBUICAO.png')   
     

    


#########################################################################################################
# Requisito 8 - Distribuição por ator (só top10)
#########################################################################################################

def distribAtor(bd):
    distribuicaoAtor={}
    for filme in bd:
        for ator in filme['cast']:
            if ator!="and" and ator!="(voice)":
                if ator in distribuicaoAtor.keys():
                    distribuicaoAtor[ator]= distribuicaoAtor[ator] +1
                else:
                    distribuicaoAtor[ator]=1
    return distribuicaoAtor


def ordenaValores(v):
    return v[1]

def top10(bd):
    valores=list(distribAtor(bd).items()) 
    print (valores)

    valores.sort(key=ordenaValores, reverse=True)
    for ator in valores:
        novoDic = dict(valores[0:10])
    return novoDic
                



#########################################################################################################
# Funções Auxiliares
#########################################################################################################
    

def getList(dic):
    lista = []
    for key in dic.keys():
        lista.append(key)         
    return lista

def verificarId(id):
    if id[:2]=="id" and id[2:].isdigit():
        valor=True
        id="id"+str(int(id[2:]))
    elif id[:2]=="Id" and id[2:].isdigit():
        valor=True
        id="id"+str(int(id[2:]))
    elif id[:2]=="ID" and id[2:].isdigit():
        valor=True
        id="id"+str(int(id[2:]))
    else:
        valor=False
    return (valor, id)



def lerLista(lista):
    string=""
    i=0
    tamanho=len(lista)
    for i in range (len(lista)):
        if tamanho==1:
            string=lista[i]
        elif string=="":
            
            string= lista[i] 
        else:
            string=string + ", " + lista[i]
    return string 
 
def espacosCabecalho():
    cabecalho=""
    string1="|   Id       "
    string2= "|                 Título                   "
    string3="|    Ano     "
    string4="|                        Elenco                             "
    string5="|                Géneros                "
    cabecalho=string1+string2+string3+string4+string5
    return cabecalho
    

#########################################################################################################
# Requisitos Extra
#########################################################################################################


def listaAtorFilme(bd):
    distribuicaoAtor={}
    for filme in bd:
        for ator in filme['cast']:
            if ator!="and" and ator!="(voice)" and ator!="(" and ator!="(Narrator)":
                if ator in distribuicaoAtor.keys():
                    distribuicaoAtor[ator][1].append((filme['id'], filme['title']))
                else:
                    distribuicaoAtor[ator]= (ator, [(filme['id'], filme['title'])])
    
    lista=[]
    for ator in distribuicaoAtor:
        lista.append(distribuicaoAtor[ator])
    lista.sort(key=chaveord3)
    return lista

def listaGeneroFilme(bd):
    distribuicaoGen={}
    for filme in bd:
        for genero in filme['genres']:
                if genero in distribuicaoGen.keys():
                    distribuicaoGen[genero][1].append((filme['id'], filme['title']))
                else:
                    distribuicaoGen[genero]= (genero, [(filme['id'], filme['title'])])
    
    lista=[]
    for genero in distribuicaoGen:
        lista.append(distribuicaoGen[genero])
    lista.sort(key=chaveord3)
    return lista

def chaveord3(tuplo):
    return tuplo[0]


def alterarRegisto(bd, id, titulo, ano, castt, generos):
    dicFilme={}
    dicFilme['title']=titulo
    dicFilme['year']=ano 
    dicFilme['cast']=castt 
    dicFilme['genres']=generos 
    dicFilme['id']=id
    encontrado=False
   
    i=0
    while i<(len(bd)) and encontrado!=True:
        if bd[i]['id']==(str(id)):
            encontrado=True
            indice=i
        else:
            i=i+1
    bd[indice]=dicFilme
    return bd