
from django.contrib import admin
from .models import *




# DEntro da ficha medica
class DadosFInline(admin.TabularInline):
    model = DadosFisiologicos
    extra = 0

class ExamesInline(admin.TabularInline):
    model = Exame
    extra = 0

class PrescricaoInline(admin.TabularInline):
    model = Prescricao
    extra = 0

class ConsultaInline(admin.TabularInline):
    model = Consulta
    extra=0

class FichaMedicaAdmin(admin.ModelAdmin):
    model=FichaMedica
    inlines = [DadosFInline,ExamesInline,PrescricaoInline, ConsultaInline]

## necessario acrescentar umas coisas para no admin conseguirmos adicionar utilizadores

admin.site.register(Utilizador)
admin.site.register(Medico)
admin.site.register(Utente)
admin.site.register(Familiar)
admin.site.register(Rececionista)
admin.site.register(FichaMedica, FichaMedicaAdmin)
admin.site.register(Medicamento)
