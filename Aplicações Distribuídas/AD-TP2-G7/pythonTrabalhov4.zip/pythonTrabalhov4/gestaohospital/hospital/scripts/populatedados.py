from decimal import Decimal
from datetime import datetime

from django.utils import timezone
from django.utils.timezone import make_aware
from hospital.models import DadosFisiologicos, Utente, FichaMedica

import csv

def run():
    fdadosf = open(r'dadosf.csv', encoding="utf8")
    csvrdados = csv.reader(fdadosf, delimiter=';')

    for dados in csvrdados:
        try:
            utente = Utente.objects.get(num_utente=dados[0])
            print(utente)
            try:
                fichamedica = FichaMedica.objects.get(utente=utente)
                print(fichamedica)
            except FichaMedica.DoesNotExist:
                fichamedica = FichaMedica.objects.create(utente=utente)

            d = DadosFisiologicos(
                ficha_medica=fichamedica,
            data_leitura = dados[1],
            pressao_arterial = dados[2],
            temperatura = dados[3],
            saturacao02 = dados[4],
            colesterol = dados[6],
            freq_cardiaca = dados[5],
            peso = dados[7],
            altura =dados[8]
            )

            print(f"Utente: {dados[0]}, Pressão Arterial: {dados[2]}, Temperatura: {dados[3]}, Saturação O2: {dados[4]}, Colesterol: {dados[6]}, Freq Cardíaca: {dados[5]}, Peso: {dados[7]}, Altura: {dados[8]}")


            d.save()


        except Exception as e:
            print(f"Erro ao criar dadosfis {dados} {e}")
