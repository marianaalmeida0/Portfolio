from datetime import datetime

from django.utils import timezone
from django.utils.timezone import make_aware
from hospital.models import (Prescricao,Utente,Medico,FichaMedica,Medicamento)

import csv

#django.setup()

def run():
    f = open(r'prescricoes.csv', encoding="utf8")

    csvr= csv.reader(f, delimiter = ';')

    for pr in csvr:
        try:
            utente = Utente.objects.get(num_utente=pr[0])

            try:
                fichamedica = FichaMedica.objects.get(utente=utente)
            except FichaMedica.DoesNotExist:
                fichamedica = FichaMedica.objects.create(utente=utente)
            medicamento = None
            medico = None

            try:
                medico = Medico.objects.get(num_medico=pr[5])
                medicamento = Medicamento.objects.get(nome=pr[1])
                print(medicamento)
            except Medicamento.DoesNotExist:
                print(f"Medicamento não encontrado para o nome {pr[1]}")


            p = Prescricao(
                fichamedica=fichamedica,
                medicamento=medicamento,
                data_inicio=pr[2],
                duracao=pr[3],
                tomas=pr[4],
                medico=medico
            )
            p.save()

        except Utente.DoesNotExist:
            print(f"Utente não encontrado para o número {pr[0]}")

        except Exception as e:
            print(f"Erro ao criar prescricao {pr} {e}")

