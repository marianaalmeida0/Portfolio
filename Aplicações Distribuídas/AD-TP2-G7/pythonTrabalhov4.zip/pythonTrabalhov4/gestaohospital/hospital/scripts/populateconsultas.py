from datetime import datetime

from django.utils import timezone
from django.utils.timezone import make_aware
from hospital.models import (Consulta,Medico,Utente,FichaMedica)

import csv

#django.setup()

def run():
    fcons = open(r'consultas.csv', encoding="utf8")

    csvrcons = csv.reader(fcons, delimiter = ';')


    for cons in csvrcons:
        try:
            utente = Utente.objects.get(num_utente=cons[0])

            try:
                fichamedica = FichaMedica.objects.get(utente=utente)
            except FichaMedica.DoesNotExist:

                fichamedica = FichaMedica.objects.create(utente=utente)

            medico = Medico.objects.get(num_medico=cons[2])
            data_consulta = timezone.make_aware(datetime.strptime(cons[1], '%Y-%m-%d %H:%M:%S'))
            c = Consulta(observacoes=cons[3], fichamedica=fichamedica, data_consulta=data_consulta, medico=medico)
            c.save()

        except Utente.DoesNotExist:
            print(f"Utente não encontrado para o número {cons[0]}")
        except Medico.DoesNotExist:
            print(f"Medico não encontrado para o número {cons[2]}")
        except Exception as e:
            print(f"Erro ao criar consulta {cons} {e}")



