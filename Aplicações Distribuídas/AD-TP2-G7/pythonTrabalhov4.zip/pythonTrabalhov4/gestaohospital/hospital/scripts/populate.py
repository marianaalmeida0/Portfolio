from django.contrib.auth.models import Group
from django.template.backends import django

# Create a new group

from django.contrib.auth.models import Group
from hospital.models import (Utente,Familiar,Rececionista,Medico)
import django
from django.contrib.auth.models import User, Group
import csv

#django.setup()

def run():
    ffam = open(r'familiares.csv', encoding="utf8")
    fut = open(r'utentes.csv', encoding="utf8")
    frec=open(r'rececionistas.csv', encoding="utf8")
    fmed=open(r'medicos.csv', encoding="utf8")

    csvrut = csv.reader(fut, delimiter = ';')
    csvrfam = csv.reader(ffam, delimiter=';')
    csvrrec=csv.reader(frec, delimiter=';')
    csvrmed = csv.reader(fmed, delimiter=';')

    my_grouput = Group.objects.get(name='Utentes')
    my_groupfam = Group.objects.get(name='Familiares')
    my_grouprec = Group.objects.get(name='Rececionistas')
    my_groupmed=Group.objects.get(name='Medicos')

    for fam in csvrfam:
        try:
            psw = 'f' + fam[0]
            f = Familiar(first_name=fam[1], num_familiar=fam[0], cc=fam[7], last_name=fam[2], username=psw,
                       data_nascimento=fam[6],
                       contacto=fam[5], parentesco=fam[4], email=fam[3])

            f.set_password(psw)
            f.save()

           #my_groupfam.user_set.add(f)
        except Exception as e:
            print(f"erro a criar familiar {fam} {e}")
            pass

    for ut in csvrut:
        try:
            familiar_associado = Familiar.objects.get(num_familiar=ut[9])
            psw = 'u'+ut[0]
            u = Utente(first_name=ut[2],num_utente=ut[0],cc=ut[1],last_name=ut[3],username= psw,
                        data_nascimento= ut[5],
                       contacto=ut[7], niss=ut[4], genero=ut[6], familiar_associado= familiar_associado, email= ut[8])


            u.set_password(psw)
            u.save()

            my_grouput.user_set.add(u)
        except Exception as e:
            print(f"erro a criar utente {ut} {e}")
            pass

    for rec in csvrrec:
        try:
            psw = 'r' + rec[0]
            r = Rececionista(first_name=rec[1], num_rececionista=rec[0], cc=rec[6], last_name=rec[2], username=psw,
                       data_nascimento=rec[7],
                       contacto=rec[4],departamento=rec[3], email=rec[5])

            r.set_password(psw)
            r.save()

            my_grouprec.user_set.add(rec)
        except Exception as e:
            print(f"erro a criar rececionista {rec} {e}")
            pass


    for med in csvrmed:
        try:
            psw = 'm' + med[0]
            m = Medico(first_name=med[1], num_medico=med[0], cc=med[6], last_name=med[2], username=psw,
                       data_nascimento=med[7],
                       contacto=med[4],especialidade=med[3], email=med[5])

            m.set_password(psw)
            m.save()

            my_groupmed.user_set.add(med)
        except Exception as e:
            print(f"erro a criar medico {med} {e}")
            pass


