from datetime import datetime

from django.utils import timezone
from django.utils.timezone import make_aware
from hospital.models import (Medicamento)

import csv

#django.setup()

def run():
    f = open(r'medicamentos_europa.csv', encoding="utf8")

    csvr= csv.reader(f, delimiter = ';')


    for nome in csvr:

            medic = Medicamento(nome=nome[0])
            medic.save()

