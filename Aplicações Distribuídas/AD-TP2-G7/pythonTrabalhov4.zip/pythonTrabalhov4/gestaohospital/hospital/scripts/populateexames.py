from datetime import datetime

from django.utils import timezone
from django.utils.timezone import make_aware
from hospital.models import (Exame,Utente,FichaMedica)

import csv

#django.setup()

def run():
    f = open(r'exames.csv', encoding="utf8")

    csvr= csv.reader(f, delimiter = ';')


    for ex in csvr:
        try:
            utente = Utente.objects.get(num_utente=ex[0])

            try:
                fichamedica = FichaMedica.objects.get(utente=utente)
            except FichaMedica.DoesNotExist:

                fichamedica = FichaMedica.objects.create(utente=utente)


            data_exame = timezone.make_aware(datetime.strptime(ex[1], '%Y-%m-%d %H:%M:%S'))
            e = Exame(data_exame=data_exame, fichamedica=fichamedica, tipo_exame=ex[2], descricao=ex[3])
            e.save()

        except Utente.DoesNotExist:
            print(f"Utente não encontrado para o número {ex[0]}")

        except Exception as e:
            print(f"Erro ao criar consulta {ex} {e}")



