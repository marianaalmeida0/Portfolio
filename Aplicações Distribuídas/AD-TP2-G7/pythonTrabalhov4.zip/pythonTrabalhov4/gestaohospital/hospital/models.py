
import datetime
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import UserManager

#----------------------------------------------------------------#
#-----------------------UTILIZADOR-------------------------------------#
#----------------------------------------------------------------#
class Utilizador(User):
    cc = models.CharField(max_length=8, unique = True)
    data_nascimento = models.DateField(auto_now=False)
    contacto = models.CharField(max_length= 12)
    objects = UserManager()


#----------------------------------------------------------------#
#----------------------UTENTE------------------------------------#
#----------------------------------------------------------------#


class Utente(Utilizador):
    num_utente = models.CharField(unique=True, max_length=15)
    niss = models.CharField(max_length=11, unique=True, null=True)
    genero = models.CharField(max_length=2, null=True)
    familiar_associado = models.ForeignKey('Familiar', on_delete=models.DO_NOTHING, null=True, blank=True)

    class Meta:
        ordering = ('num_utente',)
    def __str__(self):
        return f"Nome : {self.first_name},Apelido: {self.last_name}, Número de Utente: {self.num_utente}"


#---------------------------------------------------------------#
#---------------------MEDICO------------------------------------#
#---------------------------------------------------------------#

class Medico(Utilizador):
    num_medico = models.CharField(unique=True, max_length=15)
    especialidade = models.CharField(max_length=200)

    class Meta:
        ordering = ('num_medico',)

    def __str__(self):
        return f"Nome : {self.first_name},Apelido: {self.last_name}, Número de Médico: {self.num_medico}, Especialidade : {self.especialidade}"

#------------------------------------------------------------------#
#-------------------RECECIONISTA-----------------------------------#
#------------------------------------------------------------------#

class Rececionista(Utilizador):
    num_rececionista = models.CharField(unique=True, max_length=7)
    departamento = models.CharField(max_length=100)
    class Meta:
        ordering = ('num_rececionista',)

    def __str__(self):
        return f"Nome : {self.first_name},Apelido: {self.last_name}, Número de Rececionista: {self.num_rececionista}"

#-------------------------------------------------------------------#
#------------------------FAMILIAR-----------------------------------#
#-------------------------------------------------------------------#

class Familiar(Utilizador):
    num_familiar = models.CharField(unique=True, max_length=7)
    parentesco = models.CharField(max_length=20)
    class Meta:
        ordering = ('num_familiar',)

    def __str__(self):
        return f"Nome : {self.first_name}, Apelido: {self.last_name}, Número de Familiar: {self.num_familiar}"


#----------------------------------------------------------------#
#-------------------FICHA MÉDICA---------------------------------#
#----------------------------------------------------------------#

class FichaMedica(models.Model):
    utente = models.OneToOneField(to=Utente,on_delete=models.DO_NOTHING)

    def __str__(self):
        return f"Número de Utente : {self.utente.num_utente}, Nome: {self.utente.first_name}"

#-----------------------------------------------------------------#
#------------------------DADOS FISIOLOGICOS-----------------------#
#-----------------------------------------------------------------#

class DadosFisiologicos(models.Model):
    ficha_medica = models.ForeignKey(FichaMedica,on_delete=models.DO_NOTHING,null=False, blank=False)
    data_leitura = models.DateField(auto_now=False)
    pressao_arterial = models.IntegerField( null=True, blank=True)
    temperatura = models.IntegerField( null=True, blank=True)
    saturacao02= models.IntegerField( null=True, blank=True)
    colesterol = models.IntegerField(null=True, blank=True)
    freq_cardiaca = models.IntegerField(null=True, blank=True)
    peso = models.IntegerField(null=True, blank=True)
    altura = models.IntegerField( null=True, blank=True)
    class Meta:
        ordering = ('data_leitura',)

    def __str__(self):
        return (str(self.data_leitura) + ', ' + str(self.peso) + ', ' + str(self.altura) + str(self.pressao_arterial) + ', ' +
                str(self.temperatura)
               + ', ' + str(self.colesterol) + ', ' +
                str(self.saturacao02) + ', ' + str(self.freq_cardiaca)
                + '.' )
#------------------------------------------------------------------#
#--------------------CONSULTA--------------------------------------#
#------------------------------------------------------------------#

class Consulta(models.Model):
    fichamedica = models.ForeignKey(FichaMedica, on_delete=models.DO_NOTHING,null=False, blank=False)
    data_consulta = models.DateTimeField(auto_now=False, null= False)
    observacoes = models.CharField(max_length=200,null=True, blank=True)
    medico = models.ForeignKey(Medico,on_delete=models.DO_NOTHING)

    class Meta:
        ordering = ('data_consulta',)

    def __str__(self):
        return f"Médico : {self.medico.first_name} {self.medico.last_name}, Utente: {self.fichamedica.utente.first_name} {self.fichamedica.utente.last_name}, Data/Hora: {self.data_consulta}"

#---------------------------------------------------------------------#
#---------------------- EXAMES----------------------------------------#
#---------------------------------------------------------------------#

class Exame(models.Model):
    fichamedica = models.ForeignKey(FichaMedica, on_delete=models.DO_NOTHING, null=False, blank=False)
    data_exame = models.DateTimeField(auto_now=False)
    tipo_exame = models.CharField(max_length=200)
    descricao = models.CharField(max_length=200, null=True, blank=True)

    class Meta:
        ordering = ('tipo_exame',)

    def __str__(self):
        return f"Tipo: {self.tipo_exame}, Data/Hora: {self.data_exame}, Descricao: {self.descricao}"

#----------------------------------------------------------------------#
#---------------MEDICAMENTO--------------------------------------------#
#----------------------------------------------------------------------#

class Medicamento(models.Model):

    nome = models.CharField(max_length=200)

    class Meta:
        ordering = ('nome',)

    def __str__(self):
        return f"Medicamento:{self.nome}"

#----------------------------------------------------------------------#
#-------------------PRESCRICOES----------------------------------------#
#----------------------------------------------------------------------#

class Prescricao(models.Model):
    fichamedica = models.ForeignKey(FichaMedica,on_delete=models.DO_NOTHING, null=False, blank=False)
    medicamento = models.ForeignKey(Medicamento, null=False,blank=False, on_delete=models.DO_NOTHING)
    data_inicio = models.DateField(auto_now=False)
    duracao= models.CharField(max_length=200)
    tomas = models.CharField(max_length=200)
    medico= models.ForeignKey(Medico,on_delete=models.DO_NOTHING)

    class Meta:
        ordering = ('data_inicio',)


    def __str__(self):
        return f" data_inicio: {self.data_inicio}, duracao: {self.duracao}, tomas: {self.tomas}"



