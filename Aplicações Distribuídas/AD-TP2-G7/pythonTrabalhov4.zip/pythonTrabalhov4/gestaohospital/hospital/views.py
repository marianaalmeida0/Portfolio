from datetime import timedelta

from django.contrib.auth import authenticate, login, logout
#from django.core.checks import messages
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import ValidationError
from django.shortcuts import render, get_object_or_404

from .forms import LoginForm, AdicionarPrescForm, AdicionarExameForm, AdicionarDadosFForm, Pesquisa_Dia, RegistaUtente, \
    FormNumFamiliar, FormNumMedico, FormPassword, AlterarInfoUt, AlterarInfoMed, AlterarCons, AlterarConsMed, \
    AlterarFamUt, RegistaMedico, RegistaFamiliar, AdicionarConsForm

from .forms import FormNumUtente

from .models import *

from django.shortcuts import render, redirect

from django.contrib.auth.models import Group
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required
#-------------------LOG_IN------------------------------------------#


def log_in(request):

    form = LoginForm(request.POST or None)
    if form.is_valid():
        password = form.cleaned_data.get('password')
        username = form.cleaned_data.get('username')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user in User.objects.filter(groups__name="Utentes"):
                login(request, user)
                return HttpResponseRedirect('menuutente')
            elif user in User.objects.filter(groups__name="Medicos"):
                login(request, user)
                return HttpResponseRedirect('menumedico')
            elif user in User.objects.filter(groups__name="Rececionistas"):
                login(request, user)
                return HttpResponseRedirect('menurececionista')
            elif user in User.objects.filter(groups__name="Familiares"):
                login(request, user)
                return HttpResponseRedirect('menufamiliar')
            elif user.is_superuser:
                login(request, user)
                return HttpResponseRedirect('/admin')
            else:
                raise ValidationError('Invalid user')

    return render(request, "login.html", {'form':form})


#---------------LOGOUT--------------------------------------------#
def log_out(request):
    logout(request)
    form = LoginForm(request.POST or None)
    mensagem="Logout bem-sucedido."
    return render(request, 'login.html', {'form':form, 'logout':mensagem})


# -------------------------------------------------------------------------------------------------------#
# ---------------------------------MENU UTENTE-----------------------------------------------------------#
# -------------------------------------------------------------------------------------------------------#
@login_required(login_url='/hospital')
def menu_utente(request):
    verif = request.user
    utente = Utente.objects.get(username=verif)
    c = {"utente": utente.num_utente}
    return render(request, "../templates/menuutente.html", c)

@login_required(login_url='/hospital')
def dadospessoaisut(request):
    if request.method == "GET":
        utilizador = request.user
        utente= Utente.objects.get(username=utilizador)
        infos=[{"Nome": utente.first_name, "Apelido": utente.last_name, "NISS": utente.niss,
                "CC": utente.cc, "Data de Nascimento": utente.data_nascimento,
                "Numero de Utente": utente.num_utente,
                "Contacto": utente.contacto, "Username": utente.username, "Genero": utente.genero}]
        context = {"informacoes": infos}

        return render(request, "../templates/dadospessoaisut.html", context)



@login_required(login_url='/hospital')
def todas_consultas_utente(request):
    if request.method == "GET":
        ut = request.user
        utente = Utente.objects.get(username=ut)
        fichamedica = FichaMedica.objects.get(utente=utente)
        a= Consulta.objects.all().filter(fichamedica=fichamedica).order_by('data_consulta')
        consultas=[]
        for cons in a:
            nome=cons.medico.first_name+cons.medico.last_name
            consultas.append({"Medico": nome,"Data/Hora":cons.data_consulta, "Observações":cons.observacoes})

        if consultas == []:
            c = {"consultas": consultas}
            messages.info(request, "Utente ainda não tem consultas")
            return render(request, "../templates/consultasut.html", c)


        c={"consultas": consultas}

        return render(request, "../templates/consultasut.html", c)

@login_required(login_url='/hospital')
def todas_prescricoes_utente(request):
    if request.method == "GET":
        ut = request.user
        utente = Utente.objects.get(username=ut)
        fichamedica = FichaMedica.objects.get(utente=utente)
        p= Prescricao.objects.all().filter(fichamedica=fichamedica).order_by('-data_inicio')
        presc = [{"Medicamento":prescricao.medicamento, "Data Inicio":prescricao.data_inicio, "Duracao":prescricao.duracao, "tomas": prescricao.tomas } for prescricao in p]

        if presc == []:
            dic = {"Prescricao":presc }
            messages.info(request, "Utente ainda não tem prescricões.")
            return render(request, "../templates/prescricoesut.html", dic)


        dic={"Prescricao": presc}

        return render(request, "../templates/prescricoesut.html", dic)


@login_required(login_url='/hospital')
def todos_exames_utente(request):
    if request.method == "GET":
        ut = request.user
        utente = Utente.objects.get(username=ut)
        fichamedica = FichaMedica.objects.get(utente=utente)
        e= Exame.objects.all().filter(fichamedica=fichamedica).order_by('-data_exame')
        exam = [{"Data Exame":exame.data_exame, "Tipo Exame":exame.tipo_exame, "Descricao":exame.descricao} for exame in e]

        if exam == []:
            dic = {"Exames":exam }
            messages.info(request, "Utente ainda não tem exames.")
            return render(request, "../templates/examesut.html", dic)


        dic={"Exames": exam}

        return render(request, "../templates/examesut.html", dic)


def todos_dadosf_utente(request):
    if request.method == "GET":
        ut = request.user
        utente = Utente.objects.get(username=ut)
        fichamedica = FichaMedica.objects.get(utente=utente)
        leituras=DadosFisiologicos.objects.all().filter(ficha_medica=fichamedica).order_by('-data_leitura')

        dados = [{"Data Leitura": df.data_leitura,
                 "Pressão Arterial": df.pressao_arterial,
                 "Temperatura": df.temperatura,
                 "Saturação O2": df.saturacao02,
                 "Colesterol": df.colesterol,
                 "Freq cardíaca": df.freq_cardiaca,
                 "Peso": df.peso,
                 "Altura": df.altura
                 } for df in leituras]

        if dados == []:
            dic = {"Leitura": dados}
            messages.info(request, "Utente ainda não tem leituras.")
            return render(request, "../templates/dadosfut.html", dic)


        dic={"Leitura": dados}

        return render(request, "../templates/dadosfut.html", dic)

@login_required(login_url='/hospital')
def todos_fassociados_utente(request):
    if request.method == "GET":
        ut = request.user
        utente = Utente.objects.get(username=ut)
        if utente.familiar_associado == None:
            fam=[]
            dic = {"Familiares":fam }
            messages.info(request, "Utente não tem familiares associados.")
            return render(request, "../templates/familiaresut.html", dic)
        else:
            fam = [{"Nome": utente.familiar_associado.first_name, "Apelido": utente.familiar_associado.last_name,
                    "Contacto": utente.familiar_associado.contacto, "Parentesco": utente.familiar_associado.parentesco}]
            dic = {"Familiares":fam }

        return render(request, "../templates/familiaresut.html", dic)


def alterarfamassociado(request):
    form = AlterarFamUt()
    if request.method == "POST":
        form = AlterarFamUt(request.POST)
        if form.is_valid():
            n_familiar = form.cleaned_data['num_familiar']
            par = form.cleaned_data['parentesco']
            utilizador = request.user
            utente = Utente.objects.get(username=utilizador)
            print(utente)
            fam = Familiar.objects.all().filter(num_familiar=n_familiar)
            if not fam:
                messages.error(request, "Familiar não encontrado.")
                return render(request, "../templates/alterarfam.html", {'form': form})
            else:
                if n_familiar == utente.familiar_associado.num_familiar:
                    messages.error(request, "Este familiar já se encontra associado.")
                    return render(request, "../templates/alterarfam.html", {})

                else:
                    utente.familiar_associado = fam[0]

                    if par:
                        utente.familiar_associado.parentesco = par

                    utente.familiar_associado.save()
                    utente.save()
                    messages.success(request, "Familiar associado ao Utente alterado com sucesso.")

    return render(request, "../templates/alterarfam.html", {'form': form})


# -------------------------------------------------------------------------------------------------------#
# ---------------------------------MENU FAMILIAR-----------------------------------------------------------#
# -------------------------------------------------------------------------------------------------------#
@login_required(login_url='/hospital')
def menu_familiar(request):
    verif = request.user
    familiar = Familiar.objects.get(username=verif)
    c = {"familiar": familiar.num_familiar}
    return render(request, "../templates/menufamiliar.html", c)

@login_required(login_url='/hospital')
def dadospessoaisfam(request): # Dados Pessoais do Familiar
    if request.method == "GET":
        utilizador = request.user
        familiar= Familiar.objects.get(username=utilizador)
        infos=[{"Nome": familiar.first_name, "Apelido": familiar.last_name,
                "CC": familiar.cc, "Data de Nascimento": familiar.data_nascimento,
                "Numero de Familiar": familiar.num_familiar,
                "Contacto": familiar.contacto, "Username": familiar.username}]

        context = {"informacoes": infos}

        return render(request, "../templates/dadospessoaisfam.html", context)

@login_required(login_url='/hospital')
def dadospessoaisutf(request): #dados do utente visto pelo familiar
    if request.method == "GET":
        us = request.user
        fam = Familiar.objects.get(username=us)
        utente = Utente.objects.all().filter(familiar_associado=fam)

        if not utente:
            infos=[]
            dic = {"Info":infos }
            messages.info(request, "Familiar não tem utentes associados.")
            return render(request, "../templates/dadospessoaisutf.html", dic)
        else:
            infos = [{"Nome": ut.first_name, "Apelido": ut.last_name, "NISS": ut.niss,
                      "CC": ut.cc, "Data de Nascimento": ut.data_nascimento,
                      "Numero de Utente": ut.num_utente,
                      "Contacto": ut.contacto, "Username": ut.username, "Genero": ut.genero} for ut in utente]
            dic = {"Info":infos }

        return render(request, "../templates/dadospessoaisutf.html", dic)

@login_required(login_url='/hospital')
def todas_consultas_utentefam(request):
    if request.method == "GET":
        us = request.user
        fam = Familiar.objects.get(username=us)

        utentes = Utente.objects.filter(familiar_associado=fam)

        consultas_por_utente = {}

        for utente in utentes:
            consultas = Consulta.objects.filter(fichamedica__utente=utente)
            consultas_por_utente[utente] = consultas

        if not utentes:
            mensagem = "Este familiar não está associado a nenhum utente."
        elif all(not consultas for consultas in consultas_por_utente.values()):
            mensagem = "Não há consultas para nenhum dos utentes associados a este familiar."
        else:
            mensagem = None

        return render(request, 'consultasutfam.html',
                      {'familiar': fam, 'consultas_por_utente': consultas_por_utente, 'mensagem': mensagem})


@login_required(login_url='/hospital')
def todas_prescricoes_utentefam(request):
    if request.method == "GET":
        us = request.user
        fam = Familiar.objects.get(username=us)

        utentes = Utente.objects.filter(familiar_associado=fam)

        prescricoes_por_utente = {}

        for utente in utentes:
            prescricoes = Prescricao.objects.filter(fichamedica__utente=utente)
            prescricoes_por_utente[utente] = prescricoes

        if not utentes:
            mensagem = "Este familiar não está associado a nenhum utente."
        elif all(not prescricoes for prescricoes in prescricoes_por_utente.values()):
            mensagem = "Não há prescricoes para nenhum dos utentes associados a este familiar."
        else:
            mensagem = None

        return render(request, 'prescricoesutfam.html',
                      {'familiar': fam, 'prescricoes_por_utente': prescricoes_por_utente, 'mensagem': mensagem})


@login_required(login_url='/hospital')
def todos_exames_utentefam(request):
    if request.method == "GET":
        us = request.user
        fam = Familiar.objects.get(username=us)

        utentes = Utente.objects.filter(familiar_associado=fam)
        exames_por_utente = {}

        for utente in utentes:
            exames = Exame.objects.filter(fichamedica__utente=utente)
            exames_por_utente[utente] = exames

        if not utentes:
            mensagem = "Este familiar não está associado a nenhum utente."
        elif all(not  exames for  exames in  exames_por_utente.values()):
            mensagem = "Não há exames para nenhum dos utentes associados a este familiar."
        else:
            mensagem = None

        return render(request, 'examesutfam.html',
                      {'familiar': fam, 'exames_por_utente': exames_por_utente, 'mensagem': mensagem})

@login_required(login_url='/hospital')
def todos_dadosf_utentefam(request):
    if request.method == "GET":
        us = request.user
        fam = Familiar.objects.get(username=us)

        utentes = Utente.objects.filter(familiar_associado=fam)

        dadosf_por_utente = {}

        for utente in utentes:
            dadosf = DadosFisiologicos.objects.filter(ficha_medica__utente=utente)
            dadosf_por_utente[utente] = dadosf

        if not utentes:
            mensagem = "Este familiar não está associado a nenhum utente."
        elif all(not dadosf for  dadosf in  dadosf_por_utente.values()):
            mensagem = "Não há leituras de dados fisiológicos para nenhum dos utentes associados a este familiar."
        else:
            mensagem = None

        return render(request, 'dadosffam.html',
                      {'familiar': fam, 'dadosf_por_utente': dadosf_por_utente, 'mensagem': mensagem})

# -------------------------------------------------------------------------------------------------------#
# ---------------------------------MENU MEDICO-----------------------------------------------------------#
# -------------------------------------------------------------------------------------------------------#
@login_required(login_url='/hospital')
def menu_medico(request):
    verif = request.user
    medico = Medico.objects.get(username=verif)
    c = {"medico": medico.num_medico}
    return render(request, "../templates/menumedico.html", c)

### VERIFICA QUE O UTENTE TEM FICHA MEDICA
@login_required(login_url='/hospital')
def adicionar_prescricoes(request):

    m = request.user
    medico = Medico.objects.get(username=m)

    form = AdicionarPrescForm(request.POST or None, medico=medico)
    if form.is_valid():
        data = form.cleaned_data
        num_utente = data['num_utente']
        try:
            utente = Utente.objects.get(num_utente=num_utente)
            try:
                fichamedica=FichaMedica.objects.get(utente=utente)
                n_medicamento = data['medicamento']
                data_inicio = data['data_inicio']
                duracao =data['duracao']
                tomas=data['tomas']
                medicamento=Medicamento.objects.get(nome=n_medicamento)
                pres = Prescricao(fichamedica=fichamedica, medicamento=medicamento, medico=medico,
                                  data_inicio=data_inicio, duracao=duracao, tomas=tomas)
                pres.save()
                messages.success(request, "Prescrição registada com sucesso.")
            except FichaMedica.DoesNotExist:
                fichamedica = FichaMedica(utente=utente)
                fichamedica.save()

                n_medicamento = data['medicamento']
                data_inicio = data['data_inicio']
                duracao = data['duracao']
                tomas = data['tomas']
                medicamento = Medicamento.objects.get(nome=n_medicamento)
                pres = Prescricao(fichamedica=fichamedica, medicamento=medicamento, medico=medico,
                                  data_inicio=data_inicio, duracao=duracao, tomas=tomas)
                pres.save()
                messages.success(request, "Prescrição registada com sucesso.")

        except Utente.DoesNotExist:
            messages.info(request, "Não existe Utente com esse número Utente")


    return render(request, "../templates/registarpresut.html", {"form":form})

@login_required(login_url='/hospital')
def adicionar_exames(request):
    m = request.user
    medico = Medico.objects.get(username=m)

    form = AdicionarExameForm(request.POST or None, medico=medico)
    if form.is_valid():
        data = form.cleaned_data
        num_utente = data['num_utente']
        try:
            utente = Utente.objects.get(num_utente=num_utente)
            try:
                fichamedica = FichaMedica.objects.get(utente=utente)
                data_exame = data['data_exame']
                tipo_exame = data['tipo_exame']
                descricao =data['descricao']


                exame = Exame(fichamedica=fichamedica, data_exame=data_exame, tipo_exame=tipo_exame,
                                  descricao=descricao)
                exame.save()
                messages.success(request, "Exame registado com sucesso.")
            except FichaMedica.DoesNotExist:
                fichamedica = FichaMedica(utente=utente)
                fichamedica.save()
                data_exame = data['data_exame']
                tipo_exame = data['tipo_exame']
                descricao = data['descricao']

                exame = Exame(fichamedica=fichamedica, data_exame=data_exame, tipo_exame=tipo_exame,
                              descricao=descricao)
                exame.save()
                messages.success(request, "Exame registado com sucesso.")


        except Utente.DoesNotExist:
            messages.info(request, "Não existe Utente com esse número Utente")

    return render(request, "../templates/registaex.html", {"form":form})



@login_required(login_url='/hospital')
def adicionar_dadosf(request):
    m = request.user
    medico = Medico.objects.get(username=m)

    form = AdicionarDadosFForm(request.POST or None, medico=medico)
    if form.is_valid():
        data = form.cleaned_data
        num_utente = data['num_utente']
        try:
            utente = Utente.objects.get(num_utente=num_utente)
            print("1  ",utente)

            try:
                print(FichaMedica.objects.get(utente=utente))
                fichamedica = FichaMedica.objects.get(utente=utente)



                data_leitura = data['data_leitura']
                pressao_arterial = data['pressao_arterial']
                temperatura = data['temperatura']
                saturacao02 = data['saturacao02']
                colesterol = data['colesterol']
                freq_cardiaca = data['freq_cardiaca']
                peso = data['peso']
                altura = data['altura']


                dadosf = DadosFisiologicos(ficha_medica=fichamedica, data_leitura=data_leitura,pressao_arterial=pressao_arterial ,
                                           temperatura=temperatura,saturacao02=saturacao02,
                                           colesterol=colesterol,freq_cardiaca=freq_cardiaca,
                                           peso=peso,altura=altura)

                dadosf.save()
                messages.success(request, "Dados Fisiologicos registados com sucesso.")

            except FichaMedica.DoesNotExist:

                fichamedica = FichaMedica(utente=utente)
                fichamedica.save()
                data_leitura = data['data_leitura']
                pressao_arterial = data['pressao_arterial']
                temperatura = data['temperatura']
                saturacao02 = data['saturacao02']
                colesterol = data['colesterol']
                freq_cardiaca = data['freq_cardiaca']
                peso = data['peso']
                altura = data['altura']

                dadosf = DadosFisiologicos(ficha_medica=fichamedica, data_leitura=data_leitura,
                                           pressao_arterial=pressao_arterial,
                                           temperatura=temperatura, saturacao02=saturacao02,
                                           colesterol=colesterol, freq_cardiaca=freq_cardiaca,
                                           peso=peso, altura=altura)

                dadosf.save()
                messages.success(request, "Dados Fisiologicos registados com sucesso.")

        except Utente.DoesNotExist:
            messages.info(request, "Não existe Utente com esse número Utente")

    return render(request, "../templates/registardadosf.html", {"form":form})

@login_required(login_url='/hospital')
def dadospessoaismed(request):
    if request.method == "GET":
        utilizador = request.user
        medico= Medico.objects.get(username=utilizador)
        infos=[{"Nome": medico.first_name, "Apelido": medico.last_name, "Contacto": medico.contacto,
                "CC": medico.cc, "Data de Nascimento": medico.data_nascimento,
                "Especialidade": medico.especialidade,
                "Num_medico": medico.num_medico, "Username": medico.username}]

        context = {"informacoes": infos}

        return render(request, "../templates/dadospessoaismed.html", context)


@login_required(login_url='/hospital')
def examesporutmed(request):
    form = FormNumUtente()
    exam = []
    if request.method == "POST":
        form = FormNumUtente(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['num_utente']

            try:
                utilizador = request.user
                utente = Utente.objects.get(num_utente=num_utente)
                fichamedica = FichaMedica.objects.get(utente=utente)

                e = Exame.objects.all().filter(fichamedica=fichamedica).order_by('-data_exame')
                exam = [{"Data Exame": exame.data_exame, "Tipo Exame": exame.tipo_exame, "Descricao": exame.descricao} for exame
                        in e]

                if not exam:
                    dic = {"Exames": exam}
                    messages.info(request, "Utente ainda não tem exames.")
                    return render(request, "../templates/consultaexamesutmed.html", dic)

                dic = {"Exames": exam}
                return render(request, "../templates/consultaexamesutmed.html", dic)

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/consultaexamesutmed.html", {})

    return render(request, "../templates/consultaexamesutmed.html", {'form': form, 'Exames': exam})


@login_required(login_url='/hospital')
def todasconsultasmed (request):
    utilizador = request.user
    medico = Medico.objects.get(username=utilizador)
    consultas= Consulta.objects.all().filter(medico=medico)
    cons=[{"Utente":c.fichamedica.utente.num_utente, "Observacoes": c.observacoes, "Data": c.data_consulta} for c
                        in consultas]
    if not cons:
        messages.info(request,"Ainda não tem consultas... Vá trabalhar!")
    context={"Consultas": cons}
    return render(request, "../templates/todasconsultasmed.html", context)

@login_required(login_url='/hospital')
def todasprescmed (request):
    utilizador = request.user
    medico = Medico.objects.get(username=utilizador)
    prescricoes= Prescricao.objects.all().filter(medico=medico)
    presc=[{"Utente":p.fichamedica.utente.num_utente,"Medicamento":p.medicamento.nome, "Duracao": p.duracao,"Tomas": p.tomas, "Data de Inicio": p.data_inicio} for p
                        in prescricoes]

    if not presc:
        messages.info(request,"Ainda não tem prescricoes... Vá trabalhar!")
    context={"Prescricoes": presc}
    return render(request, "../templates/todasprescmed.html", context)


def todosutentesmed (request):
    utilizador = request.user
    medico = Medico.objects.get(username=utilizador)
    consultas= Consulta.objects.all().filter(medico=medico)
    cons=[]
    nomes=[]
    if not consultas:
        messages.info(request,"Ainda não tem utentes... Vá trabalhar!")

    else:
        for c in consultas:
            nome = c.fichamedica.utente.first_name + " "+ c.fichamedica.utente.last_name
            if nome not in nomes:
                nomes.append(nome)
                cons.append({"Num utente": c.fichamedica.utente.num_utente, "Nome" : nome})

    context = {"Consultas": cons}
    return render(request, "../templates/todosutentesmed.html", context)

@login_required(login_url='/hospital') # consultar todas as prescricoes de um utente por num utente
def consultarmedicamentos(request):
    form = FormNumUtente()
    presc = []
    if request.method == "POST":
        form = FormNumUtente(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['num_utente']

            try:
                utilizador = request.user
                medico = Medico.objects.get(username=utilizador)
                utente = Utente.objects.get(num_utente=num_utente)
                fichamedica = FichaMedica.objects.get(utente=utente)

                p = Prescricao.objects.all().filter(fichamedica=fichamedica).order_by('-data_inicio')
                presc = [{"Data Inicio": pres.data_inicio, "Duração": pres.duracao, "Tomas": pres.tomas, "Medicamento": pres.medicamento.nome} for pres
                        in p]

                if not presc:
                    dic = {"Prescricoes": presc}
                    messages.info(request, "Utente ainda não tem prescricoes.")
                    return render(request, "../templates/consultarmedicamentos.html", dic)

                dic = {"Prescricoes": presc}
                return render(request, "../templates/consultarmedicamentos.html", dic)

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/consultarmedicamentos.html", {})

    return render(request, "../templates/consultarmedicamentos.html", {'form': form, 'Prescricoes': presc})

@login_required(login_url='/hospital') # consultar todas as consultas de um dado dia
def consultasDiamed(request):
    form = Pesquisa_Dia()
    cons = []
    if request.method == "POST":
        form = Pesquisa_Dia(request.POST)
        if form.is_valid():
            dataconsulta = form.cleaned_data['data']
            print(str(dataconsulta))


            utilizador = request.user
            medico = Medico.objects.get(username=utilizador)


            # Filtrar as consultas com base no intervalo de datas
            consultas = Consulta.objects.filter(medico=medico)
            for c in consultas:
                if str(dataconsulta) in str(c.data_consulta):
                    cons.append({"Utente": c.fichamedica.utente.num_utente, "Observações": c.observacoes, "Medico": c.medico.num_medico})



            if not cons:
                dic = {"Consultas": cons}
                messages.info(request, "Não foram dadas consultas neste dia.")
                return render(request, "../templates/consultasDiamed.html", dic)

            dic = {"Consultas": cons}
            return render(request, "../templates/consultasDiamed.html", dic)

    return render(request, "../templates/consultasDiamed.html", {'form': form, 'Consultas': cons})

@login_required(login_url='/hospital') # consultar todas os exames de um dado dia
def examesDiamed(request):
    form = Pesquisa_Dia()
    ex = []
    if request.method == "POST":
        form = Pesquisa_Dia(request.POST)
        if form.is_valid():
            dataexame = form.cleaned_data['data']
            exames = Exame.objects.all()
            for e in exames:
                if str(dataexame) in str(e.data_exame):
                    ex.append({"Utente": e.fichamedica.utente.num_utente, "Tipo de Exame": e.tipo_exame,"Descricao": e.descricao})



            if not ex:
                dic = {"Exames": ex}
                messages.info(request, "Não foram dados exames neste dia.")
                return render(request, "../templates/examesDiamed.html", dic)

            dic = {"Exames": ex}
            return render(request, "../templates/examesDiamed.html", dic)

    return render(request, "../templates/examesDiamed.html", {'form': form, 'Exames': ex})



@login_required(login_url='/hospital') # consultar todas os exames de um dado dia
def utenteimc(request): # o medico so pode saber o imc de utentes que tenham tido consulta com ele;  ir as consultas que estao na ficha medica, na ficha medica estao dados f, buscar altura e peso para fazer as contas
    utilizador = request.user
    medico = Medico.objects.get(username=utilizador)
    consultas = Consulta.objects.all().filter(medico=medico)
    utentesmed=[]
    dadosf=[]
    for c in consultas:
        ut=c.fichamedica.utente
        if ut not in utentesmed:
            utentesmed.append(ut)
            fm=FichaMedica.objects.get(utente=ut)
            print(fm)
            try:
                dados = DadosFisiologicos.objects.all().filter(ficha_medica=fm)
                print(dados)
                for leitura in dados:
                    peso = leitura.peso
                    altura = leitura.altura*0.01
                    imc = peso / (altura * altura)
                    if (imc > 25):
                        dadosf.append({"Utente": ut.num_utente, "Data Leitura": leitura.data_leitura,
                                       "Peso": leitura.peso,
                                       "Altura": leitura.altura, 'imc': f"{imc:.2f}"
                                       })
            except DadosFisiologicos.DoesNotExist:
                messages.info(request, "Utente nao tem leituras")

    if not dadosf:
        dic = {"Dados": dadosf}
        messages.info(request, "Não encontrados utentes acima de peso")
        return render(request, "../templates/utenteimc.html", dic)

    dic = {"Dados": dadosf}
    return render(request, "../templates/utenteimc.html", dic)

def editarconsulta(request):
    form = AlterarConsMed()
    if request.method == "POST":
        form = AlterarConsMed(request.POST)
        if form.is_valid():
            data_cons = form.cleaned_data['data_consulta']
            print(data_cons)
            observacoes = form.cleaned_data['observacoes']

            try:
                utilizador = request.user
                medico=utilizador
                consulta=Consulta.objects.all().filter(medico=medico)
                if consulta:
                    cons=[]
                    print(str(data_cons))
                    for c in consulta:
                        c.data_consulta = c.data_consulta.replace(second=0, microsecond=0)
                        if str(data_cons) in str(c.data_consulta):
                            cons.append(c)

                    if cons==[]:
                        messages.error(request, "Consulta não encontrada.")
                        return render(request, "../templates/editarconsulta.html", {})

                else:
                    messages.error(request, "Consulta não encontrada.")
                    return render(request, "../templates/editarconsulta.html", {})

                consulta_alt = cons[0]

                if consulta_alt:
                    if observacoes:
                        consulta_alt.observacoes=observacoes

                    print(consulta_alt)

                    consulta_alt.save()
                    messages.success(request, "Consulta atualizada com sucesso.")

            except Medico.DoesNotExist:
                messages.error(request, "Medico não encontrado.")
                return render(request, "../templates/editarconsulta.html", {})

    return render(request, "../templates/editarconsulta.html", {'form': form})



# -------------------------------------------------------------------------------------------------------#
# ---------------------------------MENU RECECIONISTA----------------------------------------------------------#
# -------------------------------------------------------------------------------------------------------#

@login_required(login_url='/hospital')
def menu_rececionista(request):
    verif = request.user
    rececionista = Rececionista.objects.get(username=verif)
    c = {"Rececionista": rececionista.num_rececionista}
    return render(request, "../templates/menurececionista.html", c)
@login_required(login_url='/hospital') # Regista Utente
def registarutente(request):
    form = RegistaUtente(request.POST or None)

    if form.is_valid():
        data = form.cleaned_data
        num_utente = data['num_utente']
        username  = data['username']
        password  = data['password']
        cc  = data['cc']
        data_nascimento  = data['data_nascimento']
        contacto  = data['contacto']
        niss  = data['niss']
        genero  = data['genero']
        num_familiar_associado  = data['num_familiar_associado']
        first_name = data['first_name']
        last_name = data['last_name']
        email = data['email']


        verf=Utente.objects.all().filter(num_utente=num_utente)

        verf2=Utente.objects.all().filter(username=username)

        verffam=Familiar.objects.all().filter(num_familiar=num_familiar_associado)



        if verf or verf2:
            messages.info(request, "Ja existe utilizador")
        elif not verffam:
            utente=Utente(first_name=first_name, last_name=last_name, num_utente= num_utente,cc=cc, username=username,password = password, data_nascimento= data_nascimento,
                          contacto=contacto, niss=niss, genero=genero, email=email)
            utente.set_password(password)
            utente.save()
            grupo = Group.objects.get(name='Utentes')
            grupo.user_set.add(utente)
            messages.info(request, "Não existe familiar com esse número, mas o Utente foi registado")
        else:
            utente = Utente(first_name=first_name, last_name=last_name, num_utente=num_utente, cc=cc, username=username, data_nascimento=data_nascimento,
                            contacto=contacto, niss=niss, genero=genero,email=email, familiar_associado=verffam[0])
            utente.set_password(password)
            utente.save()
            grupo = Group.objects.get(name='Utentes')
            grupo.user_set.add(utente)



            messages.success(request, "Utente registado.")


    return render(request, "../templates/registautente.html", {"form":form})

# Registar Médico
def registarmedico(request):

    form = RegistaMedico(request.POST or None)

    if form.is_valid():
        data = form.cleaned_data
        num_medico = data['num_medico']
        username = data['username']
        password = data['password']
        cc = data['cc']
        data_nascimento = data['data_nascimento']
        contacto = data['contacto']
        first_name = data['first_name']
        last_name = data['last_name']
        email = data['email']
        especialidade = data['especialidade']

        verf = Medico.objects.all().filter(num_medico=num_medico)

        verf2 = Medico.objects.all().filter(username=username)

        if verf or verf2:
            messages.info(request, "Ja existe utilizador")

        else:
            medico = Medico(first_name=first_name, last_name=last_name, num_medico=num_medico, cc=cc, username=username,
                            data_nascimento=data_nascimento,
                            contacto=contacto,especialidade=especialidade, email=email)
            medico.set_password(password)
            medico.save()
            grupo = Group.objects.get(name='Medicos')
            grupo.user_set.add(medico)

            messages.success(request, "Médico registado.")

    return render(request, "../templates/registarmedico.html", {"form": form})

# Registar Familiar
def registarfamiliar(request):

    form = RegistaFamiliar(request.POST or None)

    if form.is_valid():
        data = form.cleaned_data
        num_familiar = data['num_familiar']
        username = data['username']
        password = data['password']
        cc = data['cc']
        data_nascimento = data['data_nascimento']
        contacto = data['contacto']
        first_name = data['first_name']
        last_name = data['last_name']
        email = data['email']
        parentesco = data['parentesco']

        verf = Familiar.objects.all().filter(num_familiar=num_familiar)

        verf2 = Familiar.objects.all().filter(username=username)

        if verf or verf2:
            messages.info(request, "Ja existe utilizador")

        else:
            familiar = Familiar(first_name=first_name, last_name=last_name, num_familiar=num_familiar, cc=cc, username=username,
                            data_nascimento=data_nascimento,
                            contacto=contacto,parentesco=parentesco, email=email)
            familiar.set_password(password)
            familiar.save()
            grupo = Group.objects.get(name='Familiares')
            grupo.user_set.add(familiar)

            messages.success(request, "Familiar registado.")

    return render(request, "../templates/registarfamiliar.html", {"form": form})

 # Registar Consultas
@login_required(login_url='/hospital')
def adicionar_consultas(request):
    form = AdicionarConsForm(request.POST or None)

    if form.is_valid():
        data = form.cleaned_data
        num_utente = data['num_utente']
        num_medico = data['medico']

        # Verificar se o Utente existe
        utente = Utente.objects.filter(num_utente=num_utente).first()

        if not utente:
            messages.info(request, "Não existe Utente com esse número Utente")
        else:
            # Verificar se a FichaMedica existe para o Utente
            fichamedica, created = FichaMedica.objects.get_or_create(utente=utente)

            medicos_disponiveis = Medico.objects.all()
            data_consulta = data['data_consulta']
            observacoes = data['observacoes']


            medico_escolhido = medicos_disponiveis.get(num_medico=num_medico)
            consultasmed=Consulta.objects.all().filter(medico=medico_escolhido)
            ocupado=0
            for c in consultasmed:
                if data_consulta==c.data_consulta:
                    messages.info(request, "Medico já tem consulta nessa data")
                    ocupado=1


            if ocupado==1:
                messages.info(request, "Não existe disponibilidade nesse Medico")
            else:
                # Criar a consulta
                cons = Consulta(fichamedica=fichamedica, observacoes=observacoes, medico=medico_escolhido, data_consulta=data_consulta)
                cons.save()
                messages.success(request, "Consulta registada com sucesso.")

    return render(request, "../templates/adicionarconsulta.html", {"form": form})

#-------------------------------------------------------------------------------------------------#

@login_required(login_url='/hospital') # consultar informacoess pessoais de um dado utente por  num_utente
def rec_consulta_infos_ut(request): # melhorias futura seria verificar disponibilidade do medico
    form = FormNumUtente()
    infos = []
    if request.method == "POST":
        form = FormNumUtente(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['num_utente']

            try:
                utilizador = request.user
                utente = Utente.objects.get(num_utente=num_utente)

                infos = [{"Nome": utente.first_name, "Apelido": utente.last_name, "NISS": utente.niss,
                          "CC": utente.cc, "Data de Nascimento": utente.data_nascimento,
                          "Numero de Utente": utente.num_utente,
                          "Contacto": utente.contacto, "Username": utente.username, "Genero": utente.genero}]
                context = {"informacoes": infos}

                return render(request, "../templates/rec_consulta_infos_ut.html", context)

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/rec_consulta_infos_ut.html", {})

    return render(request, "../templates/rec_consulta_infos_ut.html", {'form': form, 'informacoes': infos})

@login_required(login_url='/hospital')
def rec_consulta_exames_ut(request):
    form = FormNumUtente()
    exam = []
    if request.method == "POST":
        form = FormNumUtente(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['num_utente']

            try:
                utente = Utente.objects.get(num_utente=num_utente)
                fichamedica = FichaMedica.objects.get(utente=utente)

                e = Exame.objects.all().filter(fichamedica=fichamedica).order_by('-data_exame')
                exam = [{"Data Exame": exame.data_exame, "Tipo Exame": exame.tipo_exame, "Descricao": exame.descricao} for exame
                        in e]

                if not exam:
                    dic = {"Exames": exam}
                    messages.info(request, "Utente ainda não tem exames.")
                    return render(request, "../templates/rec_consulta_exames_ut.html", dic)

                dic = {"Exames": exam}
                return render(request, "../templates/rec_consulta_exames_ut.html", dic)

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/rec_consulta_exames_ut.html", {})

    return render(request, "../templates/rec_consulta_exames_ut.html", {'form': form, 'Exames': exam})


@login_required(login_url='/hospital')
def rec_consultas_ut(request):
    form = FormNumUtente()
    cons = []
    if request.method == "POST":
        form = FormNumUtente(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['num_utente']

            try:
                utente = Utente.objects.get(num_utente=num_utente)
                fichamedica = FichaMedica.objects.get(utente=utente)

                c = Consulta.objects.all().filter(fichamedica=fichamedica).order_by('-data_consulta')
                for consulta in c:
                    nome = consulta.medico.first_name + ' '+ consulta.medico.last_name
                    cons.append ({"Data Consulta": consulta.data_consulta, "Observações": consulta.observacoes, "Medico":nome})

                if not cons:
                    dic = {"Consultas": cons}
                    messages.info(request, "Utente ainda não tem consultas.")
                    return render(request, "../templates/rec_consultas_ut.html", dic)

                dic = {"Consultas": cons}
                return render(request, "../templates/rec_consultas_ut.html", dic)

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/rec_consultas_ut.html", {})

    return render(request, "../templates/rec_consultas_ut.html", {'form': form, 'Consultas': cons})

@login_required(login_url='/hospital')
def rec_utentes_associ_fam(request):
    infos = []
    form = FormNumFamiliar()  # Create an instance of the form

    if request.method == "POST":
        form = FormNumFamiliar(request.POST)
        if form.is_valid():
            num_familiar = form.cleaned_data['num_familiar']
            try:
                familiar = Familiar.objects.get(num_familiar=num_familiar)
                utentes = Utente.objects.all().filter(familiar_associado=familiar)
                infos = [
                    {
                        "Nome": utente.first_name,
                        "Apelido": utente.last_name,
                        "Numero de Utente": utente.num_utente,
                    }
                    for utente in utentes
                ]
                return render(
                    request,
                    "../templates/rec_utentes_associ_fam.html",
                    {'Informacoes': infos, 'form': form},
                )
            except Familiar.DoesNotExist:
                mensagem = "Este familiar não está associado a nenhum utente."

    mensagem = "Erro na procura"
    return render(
        request,
        "../templates/rec_utentes_associ_fam.html",{'Informacoes': infos, 'mensagem': mensagem, 'form': form}, )


@login_required(login_url='/hospital')
def rec_consultas_por_med(request):
    form = FormNumMedico()
    cons= []
    if request.method == "POST":
        form = FormNumMedico(request.POST)
        if form.is_valid():
            num_medico = form.cleaned_data['num_medico']

            try:
                medico = Medico.objects.get(num_medico=num_medico)
                consultas=Consulta.objects.all().filter(medico=medico)
                for c in consultas:
                    nome= medico.first_name+' '+ medico.last_name
                    utente=c.fichamedica.utente.num_utente
                    cons.append({"Utente":utente,"Data Consulta": c.data_consulta, 'Observações':c.observacoes,'Médico':nome})



                if not cons:
                    dic = {"Consultas": cons}
                    messages.info(request, "Médico ainda não tem consultas.Não trabalhe!!")
                    return render(request, "../templates/rec_consultas_por_med.html", dic)

                dic = {"Consultas": cons}
                return render(request, "../templates/rec_consultas_por_med.html", dic)

            except Medico.DoesNotExist:
                messages.error(request, "Medico não encontrado.")
                return render(request, "../templates/rec_consultas_por_med.html", {})

    return render(request, "../templates/rec_consultas_por_med.html", {'form': form, 'Consultas': cons})

#---------CONSULTAS NUM DIA----------------#

@login_required(login_url='/hospital') # consultar todas as consultas de um dado dia
def rec_consultas_Dia(request):
    form = Pesquisa_Dia()
    cons = []
    if request.method == "POST":
        form = Pesquisa_Dia(request.POST)
        if form.is_valid():
            dataconsulta = form.cleaned_data['data']
            print(str(dataconsulta))

            # Filtrar as consultas com base no intervalo de datas
            consultas = Consulta.objects.all()
            for c in consultas:
                if str(dataconsulta) in str(c.data_consulta):
                    cons.append({"Utente": c.fichamedica.utente.num_utente, "Observações": c.observacoes, "Medico": c.medico.num_medico})

            if not cons:
                dic = {"Consultas": cons}
                messages.info(request, "Não foram dadas consultas neste dia.")
                return render(request, "../templates/rec_consultas_Dia.html", dic)

            dic = {"Consultas": cons}
            return render(request, "../templates/rec_consultas_Dia.html", dic)

    return render(request, "../templates/rec_consultas_Dia.html", {'form': form, 'Consultas': cons})


@login_required(login_url='/hospital') # consultar todas os exames de um dado dia
def rec_exames_Dia(request):
    form = Pesquisa_Dia()
    ex = []
    if request.method == "POST":
        form = Pesquisa_Dia(request.POST)
        if form.is_valid():
            dataexame = form.cleaned_data['data']
            exames = Exame.objects.all()
            for e in exames:
                if str(dataexame) in str(e.data_exame):
                    ex.append({"Utente": e.fichamedica.utente.num_utente, "Tipo de Exame": e.tipo_exame,"Descricao": e.descricao})

            if not ex:
                dic = {"Exames": ex}
                messages.info(request, "Não foram dados exames neste dia.")
                return render(request, "../templates/rec_exames_Dia.html", dic)

            dic = {"Exames": ex}
            return render(request, "../templates/rec_exames_Dia.html", dic)

    return render(request, "../templates/rec_exames_Dia.html", {'form': form, 'Exames': ex})


@login_required(login_url='/hospital') ## historico de consultas de todos os utentes
def rec_todasconsultas (request):
    consultas= Consulta.objects.all()
    cons=[{"Utente":c.fichamedica.utente.num_utente, "Observacoes": c.observacoes, "Data": c.data_consulta} for c
                        in consultas]
    if not cons:
        messages.info(request,"Clinica abriu ha pouco tempo. Nao ha nada!")
    context={"Consultas": cons}
    return render(request, "../templates/rec_todasconsultas.html", context)

@login_required(login_url='/hospital') ## historico de exames de todos os utentes
def rec_todosexames (request):
    exames= Exame.objects.all()
    exam = [{"Data Exame": exame.data_exame, "Tipo Exame": exame.tipo_exame, "Descricao": exame.descricao} for exame
            in exames]
    if not exam:
        messages.info(request,"Clinica abriu ha pouco tempo. Nao ha nada!")
    context={"Exames": exam}
    return render(request, "../templates/rec_todosexames.html", context)

def alterarinfoutente(request):
    form = AlterarInfoUt()
    if request.method == "POST":
        form = AlterarInfoUt(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['num_utente']
            nome = form.cleaned_data['first_name']
            apelido = form.cleaned_data['last_name']
            gen = form.cleaned_data['genero']
            cont = form.cleaned_data['contacto']
            mail = form.cleaned_data['email']

            try:
                utilizador = request.user
                utente = Utente.objects.get(num_utente=num_utente)
                if nome:
                    utente.first_name=nome
                if apelido:
                    utente.last_name=apelido
                if gen:
                    utente.genero=gen
                if cont:
                    utente.contacto=cont
                if mail:
                    utente.email=mail

                print(utente)

                utente.save()
                messages.success(request, "Informações do Utente alteradas com sucesso.")

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/alterarinfout.html", {})

    return render(request, "../templates/alterarinfout.html", {'form': form})

def alterar_consulta(request):
    form = AlterarCons()
    if request.method == "POST":
        form = AlterarCons(request.POST)
        if form.is_valid():
            num_utente = form.cleaned_data['utente']
            data = form.cleaned_data['data_consulta']
            nvdata= form.cleaned_data['nova_data']
            obs = form.cleaned_data['observacoes']
            med = form.cleaned_data['medico']

            try:
                utilizador = request.user
                utente = Utente.objects.get(num_utente=num_utente)
                fm=FichaMedica.objects.get(utente=utente)
                consulta=Consulta.objects.all().filter(fichamedica=fm)
                cons=[] #considerando que existe somente uma consulta por dia
                for c in consulta:
                    if str(data) in str(c.data_consulta):
                        cons.append(c)

                if cons==[]:
                    messages.error(request, "Consulta não encontrada.")
                    return render(request, "../templates/alterarconsulta.html", {})

                consulta_alt = cons[0]

                if med:
                    med_cons = Medico.objects.all().filter(num_medico=med)[0]
                    if not med_cons:
                        messages.error(request, "Médico não encontrado.")
                        return render(request, "../templates/alterarconsulta.html", {})

                if consulta_alt:
                    if nvdata:
                        consulta_alt.data_consulta=nvdata
                    if obs:
                        consulta_alt.observacoes=obs
                    if med:
                        consulta_alt.medico=med_cons

                    print(consulta_alt)

                    consulta_alt.save()
                    messages.success(request, "Consulta atualizada com sucesso.")

            except Utente.DoesNotExist:
                messages.error(request, "Utente não encontrado.")
                return render(request, "../templates/alterarconsulta.html", {})

    return render(request, "../templates/alterarconsulta.html", {'form': form})

def alterarinfmed(request):
    form = AlterarInfoMed()
    if request.method == "POST":
        form = AlterarInfoMed(request.POST)
        if form.is_valid():
            num_med = form.cleaned_data['num_med']
            nome = form.cleaned_data['first_name']
            apelido = form.cleaned_data['last_name']
            cont = form.cleaned_data['contacto']
            esp = form.cleaned_data['especialidade']

            try:
                utilizador = request.user
                medico = Medico.objects.get(num_medico=num_med)
                if nome:
                    medico.first_name=nome
                if apelido:
                    medico.last_name=apelido
                if cont:
                    medico.contacto=cont
                if esp:
                    medico.especialidade=esp

                print(medico)

                medico.save()
                messages.success(request, "Informações do Médico alteradas com sucesso.")

            except Medico.DoesNotExist:
                messages.error(request, "Médico não encontrado.")
                return render(request, "../templates/alterarinfmedico.html", {})

    return render(request, "../templates/alterarinfmedico.html", {'form': form})


@login_required(login_url='/hospital')
def estatisticas(request):
    consultas = Consulta.objects.all()
    utentes= Utente.objects.all()
    medicos=Medico.objects.all()
    exame=Exame.objects.all()
    #utente com mais consultas
    ut=Utente.objects.all()
    utmax=None
    nmax=0
    for u in ut:
        try:
            fichamedica = FichaMedica.objects.get(utente=u)
            cons= Consulta.objects.all().filter(fichamedica=fichamedica)
            n=len(cons)
            if n>nmax:
                nmax=n
                utmax=u.first_name+" "+u.last_name+":"+ " "+str(nmax)+" consultas"
        except FichaMedica.DoesNotExist:
            print("Utente não tem ficha medica.")

    medicamentos={}
    medicamento= Medicamento.objects.all()
    for m in medicamento:
        prescricoes=Prescricao.objects.all().filter(medicamento=m)
        medicamentos[m]=len(prescricoes)

    medicamentos_ordenados = dict(sorted(medicamentos.items(), key=lambda item: item[1], reverse=True))

    top_10= dict(list(medicamentos_ordenados.items())[:10])

    for medicamento, quantidade in top_10.items():
        print(f"{medicamento.nome}: {quantidade} prescrições")


    c=len(consultas)
    u=len(utentes)
    m=len(medicos)
    e=len(exame)
    medico = Medico.objects.all()
    medmax = None
    max = 0
    for med in medico:
            cons = Consulta.objects.all().filter(medico=med)
            n = len(cons)
            if n > max:
                max = n
                medmax = med.first_name + " " + med.last_name + ":" + " " + str(max) + " consultas"

    d={"Numero de consultas":c, "Número de Utentes":u, "Número de Médicos":m, "Número de Exames":e, "Utente com mais consultas":utmax, "Top 10 Medicamentos Prescritos": top_10,"Medico com mais consultas":medmax}

    return render(request,"../templates/estatisticas.html",{"Informacoes":d})





#----------------------------------------------------------------------------------------#
#-----------------REPOR PASSWORD---------------------------------------------------------#
#----------------------------------------------------------------------------------------#


# MEDICO#

@login_required(login_url='/hospital')
def repor_pwd_med(request):
    m = request.user
    med= Medico.objects.get(username=m)

    form = FormPassword(request.POST or None)

    if form.is_valid():

        data = form.cleaned_data
        insira_nova_password = data.get("insira_nova_password")
        insira_nova_password_novamente = data.get("insira_nova_password_novamente")

        if insira_nova_password==insira_nova_password_novamente:
            med.set_password(insira_nova_password)
            med.save()
            messages.success(request, "Alteração da password efetuada com sucesso.")
            return render(request, "../templates/repor_pwd_med.html", {"form": form})

        else:
            messages.success(request, "As passwords não coincidem.")
            return render(request, "../templates/repor_pwd_med.html", {"form": form})

    return render(request, "../templates/repor_pwd_med.html", {"form": form})

#UTENTE
@login_required(login_url='/hospital')
def repor_pwd_ut(request):
    u = request.user
    ut= Utente.objects.get(username=u)

    form = FormPassword(request.POST or None)

    if form.is_valid():

        data = form.cleaned_data
        insira_nova_password = data.get("insira_nova_password")
        insira_nova_password_novamente = data.get("insira_nova_password_novamente")

        if insira_nova_password==insira_nova_password_novamente:
            ut.set_password(insira_nova_password)
            ut.save()
            messages.success(request, "Alteração da password efetuada com sucesso.")
            return render(request, "../templates/repor_pwd_ut.html", {"form": form})

        else:
            messages.success(request, "As passwords não coincidem.")
            return render(request, "../templates/repor_pwd_ut.html", {"form": form})

    return render(request, "../templates/repor_pwd_ut.html", {"form": form})

#FAMILIAR
@login_required(login_url='/hospital')
def repor_pwd_fam(request):
    f = request.user
    fam= Familiar.objects.get(username=f)

    form = FormPassword(request.POST or None)

    if form.is_valid():

        data = form.cleaned_data
        insira_nova_password = data.get("insira_nova_password")
        insira_nova_password_novamente = data.get("insira_nova_password_novamente")

        if insira_nova_password==insira_nova_password_novamente:
            fam.set_password(insira_nova_password)
            fam.save()
            messages.success(request, "Alteração da password efetuada com sucesso.")
            return render(request, "../templates/repor_pwd_fam.html", {"form": form})

        else:
            messages.success(request, "As passwords não coincidem.")
            return render(request, "../templates/repor_pwd_fam.html", {"form": form})

    return render(request, "../templates/repor_pwd_fam.html", {"form": form})

#RECECIONISTA
@login_required(login_url='/hospital')
def repor_pwd_rec(request):
    r = request.user
    rec= Rececionista.objects.get(username=r)

    form = FormPassword(request.POST or None)

    if form.is_valid():

        data = form.cleaned_data
        insira_nova_password = data.get("insira_nova_password")
        insira_nova_password_novamente = data.get("insira_nova_password_novamente")

        if insira_nova_password==insira_nova_password_novamente:
            rec.set_password(insira_nova_password)
            rec.save()
            messages.success(request, "Alteração da password efetuada com sucesso.")
            return render(request, "../templates/repor_pwd_rec.html", {"form": form})

        else:
            messages.success(request, "As passwords não coincidem.")
            return render(request, "../templates/repor_pwd_rec.html", {"form": form})

    return render(request, "../templates/repor_pwd_rec.html", {"form": form})
