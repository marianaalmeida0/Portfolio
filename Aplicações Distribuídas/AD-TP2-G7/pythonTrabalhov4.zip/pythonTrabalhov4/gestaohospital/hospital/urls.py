
from django.urls import path, include


from . import views


app_name = 'hospital'


urlpatterns = [
       path('', views.log_in, name='login'),
       path('menuutente', views.menu_utente, name='menuutente'),
       path('logout', views.log_out, name='logout'),
       path('menuutente/dadospessoaisut', views.dadospessoaisut, name='dadospessoaisut'),
       path('menuutente/consultasut', views.todas_consultas_utente, name='consultasut'),
       path('menuutente/prescricoesut', views.todas_prescricoes_utente, name='prescricoesut'),
       path('menuutente/examesut', views.todos_exames_utente, name='examesut'),
       path('menuutente/dadosfut', views.todos_dadosf_utente, name='dadosfut'),
       path('menuutente/familiaresut', views.todos_fassociados_utente, name='familiaresut'),
       path('menuutente/repor_pwd_ut', views.repor_pwd_ut, name='repor_pwd_ut'),
       path('menuutente/alterarfam', views.alterarfamassociado, name='alterarfamassociado'),


       path('menufamiliar', views.menu_familiar, name='menufamiliar'),
       path('menufamiliar/dadospessoaisfam', views.dadospessoaisfam, name='dadospessoaisfam'),
       path('menufamiliar/dadospessoaisutf', views.dadospessoaisutf, name='dadospessoaisutf'),
       path('menufamiliar/consultasutfam', views.todas_consultas_utentefam, name='consultasutfam'),
       path('menufamiliar/examesutfam', views.todos_exames_utentefam, name='examesutfam'),
       path('menufamiliar/prescricoesutfam', views.todas_prescricoes_utentefam, name='prescricoesutfam'),
       path('menufamiliar/dadosffam', views.todos_dadosf_utentefam, name='dadosffam'),
       path('menufamiliar/repor_pwd_fam', views.repor_pwd_fam, name='repor_pwd_fam'),




       path('menumedico', views.menu_medico, name='menumedico'),
       path('menumedico/registarpresut', views.adicionar_prescricoes, name='registarpresut'),
       path('menumedico/registaex', views.adicionar_exames, name='registaex'),
       path('menumedico/registardadosf', views.adicionar_dadosf, name='registardadosf'),
       path('menumedico/dadospessoaismed', views.dadospessoaismed, name='dadospessoaismed'),
       path('menumedico/consultaexamesutmed', views.examesporutmed, name='consultaexamesutmed'),
       path('menumedico/todosutentesmed', views.todosutentesmed, name='todosutentesmed'),
       path('menumedico/todasconsultasmed', views.todasconsultasmed, name='todasconsultasmed'),
       path('menumedico/consultarmedicamentos', views.consultarmedicamentos, name='consultarmedicamentos'),
       path('menumedico/consultasDiamed', views.consultasDiamed, name='consultasDiamed'),
       path('menumedico/examesDiamed', views.examesDiamed, name='examesDiamed'),
       path('menumedico/todasprescmed', views.todasprescmed, name='todasprescmed'),
       path('menumedico/utenteimc', views.utenteimc, name='utenteimc'),
       path('menumedico/repor_pwd_med', views.repor_pwd_med, name='repor_pwd_med'),
       path('menumedico/editarconsulta', views.editarconsulta, name='editarconsulta'),




       path('menurececionista', views.menu_rececionista, name='menurececionista'),
       path('menurececionista/registautente', views.registarutente, name='registautente'),
       path('menurececionista/registarmedico', views.registarmedico, name='registarmedico'),
       path('menurececionista/adicionarconsulta', views.adicionar_consultas, name='adicionarconsulta'),
       path('menurececionista/registarfamiliar', views.registarfamiliar, name='registarfamiliar'),
       path('menurececionista/rec_consulta_infos_ut', views.rec_consulta_infos_ut, name='rec_consulta_infos_ut'),
       path('menurececionista/rec_consulta_exames_ut', views.rec_consulta_exames_ut, name='rec_consulta_exames_ut'),
       path('menurececionista/rec_consultas_ut', views.rec_consultas_ut, name='rec_consultas_ut'),
       path('menurececionista/rec_utentes_associ_fam', views.rec_utentes_associ_fam, name='rec_utentes_associ_fam'),
       path('menurececionista/rec_consultas_por_med', views.rec_consultas_por_med, name='rec_consultas_por_med'),
       path('menurececionista/rec_consultas_Dia', views.rec_consultas_Dia, name='rec_consultas_Dia'),
       path('menurececionista/rec_exames_Dia', views.rec_exames_Dia, name='rec_exames_Dia'),
       path('menurececionista/rec_todasconsultas', views.rec_todasconsultas, name='rec_todasconsultas'),
       path('menurececionista/rec_todosexames', views.rec_todosexames, name='rec_todosexames'),
       path('menurececionista/estatisticas', views.estatisticas, name='estatisticas'),
       path('menurececionista/repor_pwd_rec', views.repor_pwd_rec, name='repor_pwd_rec'),
       path('menurececionista/alterarinfout', views.alterarinfoutente, name='alterarinfoutente'),
       path('menurececionista/alterarconsulta', views.alterar_consulta, name='alterar_consulta'),
       path('menurececionista/alterarinfmedico', views.alterarinfmed, name='alterarinfmedico')




]

'''      
       
       
      
       
       
'''

'''
   



    path('logout', views.log_out, name='logout'),


    
    path('menuutente/agendamentosutente', views.todos_agendamentos_utente, name='agendamentosutente'),
    
    path('menuutente/informacoes', views.informacao_utenteu, name='informacoes'),
    path('menuutente/prescricoesutente', views.todas_prescricoes_utente, name='prescricoesutente'),



   
    path('menuutente/examesutente', views.exames_utenteu, name='examesutente'),
    path('menuutente/dadosfisiologicos', views.dadosf_utenteu, name='dads'),
    path('menuutente/reporpalavrapasseut', views.reporpalavrapasseu, name='reporpalavrapasseut'),
    path('menuutente/fichautente', views.ver_ficha_medica, name='fichamedica'),

    path('menumedico', views.menu_medico, name='menumedico'),
    path('menumedico/registarconsulta', views.registar_consulta, name='registarconsulta'),
    path('menumedico/adicionaprescricoes', views.adiciona_prescricoes, name='adicionaprescricoes'),
    path('menumedico/agendamentos', views.listar_agendamentos_medico, name='agendamentosmedico'),
    path('menumedico/listamedicamentos', views.listar_medicamentos, name='listamedicamentos'),
    path('menumedico/consultas', views.listar_consultas_medico, name='consultasmedico'),
    path('menumedico/prescricoes', views.listar_prescricoes_medico, name='prescricoesmedico'),
    path('menumedico/infoutente', views.informacao_utente, name='infoutente'),
    path('menumedico/prescricoesutente', views.prescricoes_utente, name='prescricoesutente'),
    path('menumedico/consultasutente', views.consultas_utente, name='consultasutente'),
    path('menumedico/procuramedicamento', views.procurar_medicamento, name='procuramedicamento'),
    path('menumedico/reporpalavrapasse', views.reporpalavrapassem, name='reporpalavrapasse'),


    path('menusecretaria', views.menu_secretaria, name='menusecretaria'),
    path('menusecretaria/listar', views.listar, name='listar'),
    path('menusecretaria/adicionautente', views.adiciona_utente, name='adicionautente'),
    path('menusecretaria/adicionasecretaria', views.adiciona_secretaria, name='adicionasecretaria'),
    path('menusecretaria/adicionamedico', views.adiciona_medico, name='adicionamedico'),
    path('menusecretaria/adicionaenfermeiro', views.adiciona_enfermeiro, name='adicionaenfermeiro'),
    path('menusecretaria/adicionafamiliar', views.adiciona_familiar, name='adicionafamiliar'),
    path('menusecretaria/novoagendamento', views.cria_agendamento, name='novoagendamento'),
    path('menusecretaria/cancelaragendamento', views.cancela_agendamento, name='cancelaragendamento'),
    path('menusecretaria/agendamentospordata', views.listar_agendamentos_data, name='agendamentosdata'),
    path('menusecretaria/dadosestatisticos', views.dados_estatisticos, name='dadosestatisticos'),
    path('menusecretaria/reporpalavrapasses', views.reporpalavrapasses, name='reporpalavrapasses'),
    '''

