from datetime import date

from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.auth.models import Group
from django import forms
from django.contrib import auth

from .models import *

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput()) #esconde a palavra passe do ecrã

    def clean(self, *args, **kwargs):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')

        if username and password:
            user = authenticate(username=username, password=password)
            if not user:
                raise forms.ValidationError('Incorrect username or password! Please, try again.')
            if not user.check_password(password):
                raise forms.ValidationError('Incorrect username or password! Please, try again.')
        return super(LoginForm, self).clean(*args, **kwargs)



#---------------------- PARA ADICIONAR PRESCRICOES_EXAMES_LEITURAS---medico----------------------------#

class AdicionarPrescForm(forms.Form):
    data_inicio = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    duracao = forms.CharField(max_length=200)
    tomas = forms.CharField(max_length=200)
    num_utente= forms.CharField(max_length=200)
    medicamento = forms.ChoiceField(choices=[], required=True)
    def __init__(self, *args, **kwargs):
        medico = kwargs.pop('medico')
        super(AdicionarPrescForm, self).__init__(*args, **kwargs)
        medicamentos = Medicamento.objects.all()
        choicesmed = [(m.nome, f"{m.nome}") for m in
                     medicamentos]
        self.fields['medicamento'].choices = choicesmed

        #self.fields['Agendamento']=  forms.ModelChoiceField(queryset=Agenda.objects.all().filter(medico=medico))


class AdicionarExameForm(forms.Form):
    num_utente = forms.CharField(max_length=200)
    data_exame = forms.DateTimeField(widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    tipo_exame = forms.CharField(max_length=200)
    descricao = forms.CharField(max_length=200)

    def __init__(self, *args, **kwargs):
        medico = kwargs.pop('medico')
        super(AdicionarExameForm, self).__init__(*args, **kwargs)


class AdicionarConsForm(forms.Form):
    num_utente = forms.CharField(max_length=200)
    data_consulta = forms.DateTimeField(widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    observacoes = forms.CharField(max_length=200)
    medico = forms.ChoiceField(choices=[], required=True)

    def __init__(self, *args, **kwargs):
        super(AdicionarConsForm, self).__init__(*args, **kwargs)



        medicos_disponiveis = Medico.objects.all()
        choices = [(medico.num_medico, f"{medico.first_name} {medico.last_name}") for medico in medicos_disponiveis]
        self.fields['medico'].choices = choices

class AdicionarDadosFForm(forms.Form):
    num_utente = forms.CharField(max_length=200)
    data_leitura =forms.DateField(widget=forms.DateInput(attrs={'type': 'date'})) ## depende se fizeremos o povoamento
    pressao_arterial = forms.IntegerField()
    temperatura = forms.IntegerField()
    saturacao02 = forms.IntegerField()
    colesterol = forms.IntegerField()
    freq_cardiaca = forms.IntegerField()
    peso = forms.IntegerField()
    altura = forms.IntegerField()
    def __init__(self, *args, **kwargs):
        medico = kwargs.pop('medico')
        super(AdicionarDadosFForm, self).__init__(*args, **kwargs)

class FormNumUtente(forms.Form):
    num_utente = forms.CharField(label='num_utente')

class FormNumFamiliar(forms.Form):
    num_familiar = forms.CharField(label='num_familiar')

class FormNumMedico(forms.Form):
    num_medico = forms.CharField(label='num_medico')
class Pesquisa_Dia(forms.Form):
    data=forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}),label='data')

class FormPassword(forms.Form):
    insira_nova_password = forms.CharField(widget=forms.PasswordInput())
    insira_nova_password_novamente= forms.CharField(widget=forms.PasswordInput())
class RegistaUtente(forms.Form):
    username=forms.CharField(max_length=10)
    password=forms.CharField(max_length=10, widget=forms.PasswordInput)
    cc = forms.CharField(max_length=8)
    data_nascimento = forms.DateField()
    contacto = forms.CharField(max_length=12)
    num_utente = forms.CharField(max_length=15)
    niss = forms.CharField(max_length=11)
    genero = forms.CharField(max_length=2)
    num_familiar_associado = forms.CharField(max_length=10, required=False)
    first_name = forms.CharField( max_length=150)
    last_name = forms.CharField(max_length=150)
    email=forms.CharField(max_length=150)

    def __init__(self, *args, **kwargs):
        super(RegistaUtente, self).__init__(*args, **kwargs)

class RegistaMedico(forms.Form):
    username=forms.CharField(max_length=10)
    password=forms.CharField(max_length=10, widget=forms.PasswordInput)
    cc = forms.CharField(max_length=8)
    data_nascimento = forms.DateField()
    contacto = forms.CharField(max_length=12)
    num_medico = forms.CharField(max_length=15)
    especialidade = forms.CharField(max_length=150)
    first_name = forms.CharField( max_length=150)
    last_name = forms.CharField(max_length=150)
    email=forms.CharField(max_length=150)

    def __init__(self, *args, **kwargs):
        super(RegistaMedico, self).__init__(*args, **kwargs)

class RegistaFamiliar(forms.Form):
    username=forms.CharField(max_length=10)
    password=forms.CharField(max_length=10, widget=forms.PasswordInput)
    cc = forms.CharField(max_length=8)
    data_nascimento = forms.DateField()
    contacto = forms.CharField(max_length=12)
    num_familiar = forms.CharField(max_length=15)
    parentesco = forms.CharField(max_length=30)
    first_name = forms.CharField( max_length=150)
    last_name = forms.CharField(max_length=150)
    email=forms.CharField(max_length=150)

    def __init__(self, *args, **kwargs):
        super(RegistaFamiliar, self).__init__(*args, **kwargs)



class AlterarInfoUt(forms.Form):
    num_utente = forms.CharField(max_length=15)
    first_name = forms.CharField(max_length=150, required=False)
    last_name = forms.CharField(max_length=150, required=False)
    genero = forms.CharField(max_length=2, required=False)
    contacto = forms.CharField(max_length=12, required=False)
    email=forms.CharField(max_length=150, required=False)

class AlterarCons(forms.Form):
    #num_utente = forms.CharField(max_length=15)
    utente = forms.ChoiceField(choices=[], required=True)
    data_consulta= forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    nova_data= forms.DateTimeField(widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),required=False)
    observacoes= forms.CharField(max_length=200, required=False)
    #num_medico=forms.CharField(max_length=15, required=False)
    medico = forms.ChoiceField(choices=[], required=True)
    def __init__(self, *args, **kwargs):
        super(AlterarCons, self).__init__(*args, **kwargs)
        utentes= Utente.objects.all()
        choicesut = [(ut.num_utente, f"{ut.first_name} {ut.last_name} {'num_utente: '+ut.num_utente}") for ut in utentes]
        self.fields['utente'].choices = choicesut

        # lista de médicos disponíveis e preencher as escolhas do campo 'medico'
        medicos_disponiveis = Medico.objects.all()
        choices = [(medico.num_medico, f"{medico.first_name} {medico.last_name}") for medico in medicos_disponiveis]
        self.fields['medico'].choices = choices


class AlterarInfoMed(forms.Form):
    num_med = forms.CharField(max_length=15)
    first_name = forms.CharField(max_length=150, required=False)
    last_name = forms.CharField(max_length=150, required=False)
    contacto = forms.CharField(max_length=12, required=False)
    especialidade= forms.CharField(max_length=150, required=False)

class AlterarConsMed(forms.Form):
    data_consulta= forms.DateTimeField(widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    observacoes= forms.CharField(max_length=200, required=False)

class AlterarFamUt(forms.Form):
    num_familiar= forms.CharField(max_length=15, required=False)
    parentesco= forms.CharField(max_length=15, required=False)

