package App;

import Gestor.GestorClinico;
import Inter.*;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

public class AplicacaoFamiliar {


    public static void main(String[] args)
            throws RemoteException {

        FamiliarInterface fi = null;
        try {
            fi = (FamiliarInterface) Naming.lookup("rmi://localhost:50001/gc1");
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }

        Scanner scanner = new Scanner(System.in);

        int opcao;
        int idFamiliar, idUtente;

        do {
            // Menu
            System.out.println("==== Menu de Funcionalidades ====");
            System.out.println("1. Consultar Informações Pessoais do Utente Associado");
            System.out.println("2. Consultar Informações Médicas do Utente Associado");
            System.out.println("3. Consultar Consultas do Utente Associado");
            System.out.println("4. Sair");
            System.out.print("Escolha uma opção: ");

            // Opcao do utilizador
            opcao = scanner.nextInt();

            // Executar a ação correspondente à escolha
            switch (opcao) {
                case 1:
                    System.out.print("Digite o seu ID de Utilizador: ");
                    idFamiliar = scanner.nextInt();
                    System.out.print("Digite o ID do Utente Associado: ");
                    idUtente = scanner.nextInt();
                    System.out.println(fi.familiarConsultaUt(idFamiliar, idUtente));
                    break;
                case 2:
                    System.out.print("Digite o seu ID de Utilizador: ");
                    idFamiliar = scanner.nextInt();
                    System.out.print("Digite o ID do Utente Associado: ");
                    idUtente = scanner.nextInt();
                    System.out.println(fi.familiarConsultaFMed(idFamiliar, idUtente));
                    break;
                case 3:
                    System.out.print("Digite o seu ID de Utilizador: ");
                    idFamiliar = scanner.nextInt();
                    System.out.print("Digite o ID do Utente Associado: ");
                    idUtente = scanner.nextInt();
                    System.out.println(fi.familiarConsultaConsultas(idFamiliar, idUtente));
                    break;
                case 4:
                    System.out.println(" Saiu do Sistema");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }


            System.out.println();

        } while (opcao != 4);


        scanner.close();
    }
}


