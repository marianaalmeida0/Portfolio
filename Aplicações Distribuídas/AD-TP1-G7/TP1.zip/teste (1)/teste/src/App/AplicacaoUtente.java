package App;


import Inter.*;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

public class AplicacaoUtente {
    public static void main(String[] args)
            throws RemoteException {
        UtenteInterface ui = null;
        try {
            ui = (UtenteInterface) Naming.lookup("rmi://localhost:50001/gc3");
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }

        Scanner scanner = new Scanner(System.in);

        int opcao;
        int idUtente;

        do {
            // Exibir o menu
            System.out.println("==== Menu de Funcionalidades ====");
            System.out.println("1. Consultar Utente");
            System.out.println("2. Consultar Consulta do Utente");
            System.out.println("3. Consultar Prescrições do Utente");
            System.out.println("4. Consultar Exames do Utente");
            System.out.println("5. Consultar Dados Fisiológicos do Utente");
            System.out.println("6. Consultar Ficha Médica do Utente");
            System.out.println("7. Consultar todos os Familiares associados a um Utente");
            System.out.println("8. Sair");
            System.out.print("Escolha uma opção: ");


            opcao = scanner.nextInt();

            // Executar a ação correspondente à escolha
            switch (opcao) {
                case 1:
                    System.out.print("Digite o seu ID de Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.consultarUtente(idUtente));
                    break;
                case 2:
                    System.out.print("Digite o seu ID de Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.consultarConsultaUtente(idUtente));
                    break;
                case 3:
                    System.out.print("Digite o seu ID de Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.consultarPrescricoesUtente(idUtente));
                    break;
                case 4:
                    System.out.print("Digite o seu ID de Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.consultarExamesUtente(idUtente));
                    break;
                case 5:
                    System.out.print("Digite o seu ID de Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.consultarDadosFisiologicosUtente(idUtente));
                    break;
                case 6:
                    System.out.print("Digite o seu ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.consultarFMedicaUtente(idUtente));
                    break;

                case 7:
                    System.out.print("Digite o seu ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ui.listarFamPUt(idUtente));
                    break;

                case 8:
                    System.out.println("Saiu do Sistema");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }


            System.out.println();

        } while (opcao!= 8);


        scanner.close();

    }
        /*System.out.println(ui.consultarUtente(10));
        System.out.println(ui.consultarConsultaUtente(10));
        System.out.println(ui.consultarPrescricoesUtente(10));
        System.out.println(ui.consultarExamesUtente(10));
        System.out.println(ui.consultarDadosFisiologicosUtente(10));
        System.out.println(ui.consultarFMedicaUtente(10));

         */
}
