package App;
import Gestor.*;
import Inter.*;
import Inter.RececionistaInterface;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;

public class ServerRMI {
    public static void main(String[] args) {
        try {
            //GestaoMedicamentosInterface server = new GestaoMedicamentos();
            GestorClinico server = new GestorClinico();
            System.out.println(server.loadDados("C:/Users/maryy/Downloads/teste (1)/teste/DatasetUtentes.csv",
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetFamiliares.csv" ,
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetMedicos.csv",
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetRececionistas.csv",
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetDadosFisiologicos.csv",
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetExames.csv",
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetConsultas.csv",
                    "C:/Users/maryy/Downloads/teste (1)/teste/DatasetPrescricoes.csv"));

            RececionistaInterface server4= (RececionistaInterface) server;
            MedicoInterface server2= (MedicoInterface) server;
            FamiliarInterface server1 = (FamiliarInterface) server;
            UtenteInterface server3 = (UtenteInterface) server;
            Naming.rebind("rmi://localhost:50001/gc3", server3);
            Naming.rebind("rmi://localhost:50001/gc1", server1);
            Naming.rebind("rmi://localhost:50001/gc2", server2);
            Naming.rebind("rmi://localhost:50001/gc4", server4);

            System.out.println("Running");

        } catch (RemoteException | MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

}