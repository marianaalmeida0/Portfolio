package App;
/*
import Inter.RececionistaInterface;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class AplicacaoRececionista {

    public static void main(String[] args)
            throws RemoteException {

        RececionistaInterface ri= null;
        try {
            ri = (RececionistaInterface) Naming.lookup("rmi://localhost:50001/gc4");
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }



        System.out.println(ri.listarUtentes());


        //System.out.println(ri.listarUtentes());
        ri.registaUtente(300,"71878263", "LAAAAAAAAAAAAAAAAAA", "8172623322",
                "15-04-2002", "F", "UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU", "IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII") ;
        ri.saveUtentes("C:/Users/Mariana Ribeiro/Desktop/App Dist/Trab1/teste/DatasetUtentes.csv");
        System.out.println(ri.listarUtentes());



    }
}

 */
import Inter.RececionistaInterface;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class AplicacaoRececionista {

    public static void main(String[] args)
            throws RemoteException {

        RececionistaInterface ri= null;
        try {
            ri = (RececionistaInterface) Naming.lookup("rmi://localhost:50001/gc4");
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        Scanner scanner = new Scanner(System.in);
        int opcao;
        int idUtente;

        do {
            System.out.println("==== Menu de Funcionalidades ====\n" +
                    "1-  Registar Utente\n" +
                    "2-  Registar Médico\n" +
                    "3-  Registar Familiar\n" +
                    "4-  Registar Rececionista\n" +
                    "5-  Agendar Consulta\n" +
                    "6-  Consultar Utente\n" +
                    "7-  Consultar Consultas do Utente\n" +
                    "8-  Consultar Prescrições do Utente\n" +
                    "9-  Consultar Exames do Utente\n" +
                    "10- Consultar Dados Fisiológicos do Utente\n" +
                    "11- Consultar Ficha Médica do Utente\n" +
                    "12- Editar Informação do Utente\n" +
                    "13- Editar Consultas\n" +
                    "14- Listar Utentes\n" +
                    "15- Listar Familiares\n" +
                    "16- Listar Médicos\n" +
                    "17- Listar Fichas Medicas\n" +
                    "18- Listar Dados Fisiológicos\n" +
                    "19- Listar Exames\n" +
                    "20- Listar Prescrições\n" +
                    "21- Listar Consultas\n" +
                    "22- Listar Rececionista\n" +
                    "23- Número Total de Consultas\n" +
                    "24- Número de Consultas do Dia\n" +
                    "25- Exames por Dia\n" +
                    "26- Utentes Obesos\n" +
                    "27- Listar todos os Familares de um Utente\n"+
                    "28 - Sair\n" + "\n"+
                    "Insira a sua opção:"
            );
            opcao = scanner.nextInt();
            switch (opcao) {
                case 1:
                    registoUtente(scanner,ri);
                    break;
                case 2:
                    registoMedico(scanner, ri);
                    break;
                case 3:
                    registoFamiliar(scanner, ri);
                    break;
                case 4:
                    registoRececionista(scanner, ri);
                    break;
                case 5:
                    agendarConsulta(scanner, ri);
                    break;
                case 6:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.consultarUtente(idUtente));
                    break;
                case 7:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.consultarConsultaUtente(idUtente));
                    break;
                case 8:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.consultarPrescricoesUtente(idUtente));
                    break;
                case 9:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.consultarExamesUtente(idUtente));
                    break;
                case 10:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.consultarDadosFisiologicosUtente(idUtente));
                    break;
                case 11:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.consultarFMedicaUtente(idUtente));
                    break;

                case 12:
                    editarUtente(scanner,ri);
                    break;


                case 13:
                    editarConsulta(scanner,ri);
                    break;

                case 14:
                    System.out.println(ri.listarUtentes());
                    break;
                case 15:
                    System.out.println(ri.listarFamiliares());
                    break;
                case 16:
                    System.out.println(ri.listarMedicos());
                    break;
                case 17:
                    System.out.println(ri.listarFichasMedicas());
                    break;

                case 18:
                    System.out.println(ri.listarDadosFisiologicos());
                    break;
                case 19:
                    System.out.println(ri.listarExames());
                    break;
                case 20:
                    System.out.println(ri.listarPrescricoes());
                    break;
                case 21:
                    System.out.println(ri.listarConsultas());
                    break;
                case 22:
                    System.out.println(ri.listarRececionista());
                    break;
                case 23:
                    System.out.println(ri.numeroTotalConsultas());
                    break;
                case 24:
                    System.out.println("Numero de Consultas no dia X. Digite um dia no formato yyyy-MM-ddTHH:mm ( não importa as horas e minutos que inserir)");
                    String data = scanner.next();
                    LocalDateTime dataC = LocalDateTime.parse(data);
                    System.out.println(ri.numeroConsultasDia(dataC));
                    break;
                case 25:
                    System.out.println("Numero de Exames no dia X. Digite um dia no formato yyyy-MM-ddTHH:mm ( não importa as horas e minutos que inserir)");
                    String data1 = scanner.next();
                    LocalDateTime dataE = LocalDateTime.parse(data1);
                    System.out.println(ri.examesDia(dataE));
                    break;
                case 26:
                    System.out.println(ri.utentesObesos());
                    break;
                case 27:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(ri.listarFamPUt(idUtente));
                    break;

                case 28:
                    System.out.println();
                    System.out.print("Deseja guardar as alterações? (S/N): ");
                    String resposta = scanner.next().toUpperCase();

                    if ("S".equals(resposta)) {
                        ri.save("C:/Users/maryy/Downloads/teste (1)/teste/DatasetUtentes.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetRececionistas.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetMedicos.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetFamiliares.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetDadosFisiologicos.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetConsultas.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetExames.csv",
                                "C:/Users/maryy/Downloads/teste (1)/teste/DatasetPrescricoes.csv");
                        System.out.println("Alterações guardadas com sucesso!");
                    } else {
                        System.out.println("Alterações não guardadas.");
                    }
                    System.out.println("Saiu do Sistema!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 28);
        scanner.close();
    }
    private static void registoUtente(Scanner scanner, RececionistaInterface ri) throws RemoteException {

        System.out.print("ID do Utente: ");
        int idUtente = scanner.nextInt();
        System.out.print("CC: ");
        String cc = scanner.next();
        System.out.print("Nome: ");
        String nome = scanner.next();
        System.out.print("NISS: ");
        String niss = scanner.next();
        System.out.print("Data de Nascimento: ");
        String dataNascimento = scanner.next();
        System.out.print("Género: ");
        String genero = scanner.next();
        System.out.print("Contacto: ");
        String contacto = scanner.next();
        System.out.print("Email: ");
        String email = scanner.next();
        ri.registaUtente(idUtente, cc, nome, niss, dataNascimento, genero, contacto, email);
        System.out.println("Utente registado com sucesso!");

    }
    private static void registoMedico(Scanner scanner, RececionistaInterface ri) throws RemoteException {
        System.out.print("ID do Médico: ");
        int idMedico = scanner.nextInt();
        System.out.print("CC: ");
        String cc = scanner.next();
        System.out.print("Nome: ");
        String nome = scanner.next();
        System.out.print("Morada: ");
        String morada = scanner.next();
        System.out.print("Contacto: ");
        String contacto = scanner.next();
        System.out.print("Email: ");
        String email = scanner.next();
        System.out.print("Especialidade: ");
        String especialidade = scanner.next();

        ri.registarMedico(idMedico, cc, nome, morada, contacto, email, especialidade);
        System.out.println("Médico registado com sucesso!");
    }
    private static void registoFamiliar(Scanner scanner, RececionistaInterface ri) throws RemoteException {

        System.out.print("ID do Utilizador: ");
        int idUtilizador = scanner.nextInt();
        System.out.print("Nome: ");
        String nome = scanner.next();
        System.out.print("Parentesco: ");
        String parentesco = scanner.next();
        System.out.print("ID do Utente Associado: ");
        int idUtenteAssociado = scanner.nextInt();

        ri.registarFamiliar(idUtilizador, nome, parentesco, idUtenteAssociado);
        System.out.println("Familiar registado com sucesso!");

    }

    private static void registoRececionista(Scanner scanner, RececionistaInterface ri) throws RemoteException {

        System.out.print("ID do Rececionista: ");
        int idRececionista = scanner.nextInt();
        System.out.print("CC: ");
        String cc = scanner.next();
        System.out.print("Nome: ");
        String nome = scanner.next();
        System.out.print("Morada: ");
        String morada = scanner.next();
        System.out.print("Contacto: ");
        String contacto = scanner.next();
        System.out.print("Email: ");
        String email = scanner.next();
        System.out.print("Departamento: ");
        String departamento = scanner.next();

        ri.registarRececionista(idRececionista, cc, nome, morada, contacto, email, departamento);
        System.out.println("Rececionista registado com sucesso!");

    }
    private static void agendarConsulta(Scanner scanner, RececionistaInterface ri) throws RemoteException {

        System.out.print("ID da Consulta: ");
        int idConsulta = scanner.nextInt();
        System.out.print("ID do Utente: ");
        int idUtente = scanner.nextInt();
        System.out.print("Data da Consulta (YYYY-MM-DDTHH:MM): ");
        String dataConsultaStr = scanner.next();
        LocalDateTime dataConsulta = LocalDateTime.parse(dataConsultaStr);
        System.out.print("Tipo de Consulta: ");
        String tipoConsulta = scanner.next();
        System.out.print("ID do Médico: ");
        int idMedico = scanner.nextInt();
        System.out.print("Observações: ");
        String observacoes = scanner.next();

        ri.adicionarConsultaUt(idConsulta, idUtente, dataConsulta, tipoConsulta, idMedico, observacoes);
        System.out.println("Consulta adicionada com sucesso!");
    }
    private static void editarUtente(Scanner scanner, RececionistaInterface ri) throws RemoteException {


        System.out.print("ID do Utente: ");
        int idUtente = scanner.nextInt();
        System.out.print("Novo contacto. Coloque * para manter o mesmo): ");
        String novoContacto = scanner.next();
        System.out.print("Novo email. Coloque * para manter o mesmo): ");
        String novoEmail = scanner.next();
        ri.editaUtente(idUtente, novoContacto, novoEmail);

    }
    private static void editarConsulta (Scanner scanner, RececionistaInterface ri) throws RemoteException {

        System.out.print("Digite o ID da Consulta a ser editada: ");
        int idConsulta = scanner.nextInt();
        System.out.print("Digite o ID do Utente associado a esta consulta: ");
        int idUtente = scanner.nextInt();

        System.out.print("Digite a nova data da consulta (formato: yyyy-MM-ddTHH:mm).Se pretender manter coloque *");
        String dataNova = scanner.next();

        System.out.print("Digite o novo ID do médico. Se pretender manter o Médico coloque * ");
        String idMedico = scanner.next();

        System.out.print("Digite as novas observações. Se pretender manter as observacoes coloque *");
        String observacoes = scanner.next();
        ri.editaConsulta(idConsulta, idUtente, dataNova, idMedico, observacoes);

    }


}

