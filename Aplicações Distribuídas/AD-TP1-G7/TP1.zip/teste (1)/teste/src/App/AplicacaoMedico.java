package App;

/*import Inter.MedicoInterface;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class AplicacaoMedico {
    public static void main(String[] args)
            throws RemoteException {

        MedicoInterface mi = null;
        try {
            mi = (MedicoInterface) Naming.lookup("rmi://localhost:50001/gc2");
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }

        System.out.println(mi.listarUtentes());
        System.out.println(mi.consultarConsultaUtente(1));


    }


}

 */
import Inter.MedicoInterface;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class AplicacaoMedico {
    public static void main(String[] args)
            throws RemoteException {

        MedicoInterface mi = null;
        try {
            mi = (MedicoInterface) Naming.lookup("rmi://localhost:50001/gc2");
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        Scanner scanner = new Scanner(System.in);

        int opcao;
        int idUtente;

        do {
            //Menu
            System.out.println("==== Menu de Funcionalidades ====");
            System.out.println("1. Adicionar Dados Fisiológicos a um Utente");
            System.out.println("2. Adicionar Exame a um Utente");
            System.out.println("3. Adicionar Prescrição a um Utente");
            System.out.println("4. Adicionar Consulta a um Utente");
            System.out.println("5. Editar Consulta de um Utente");
            System.out.println("6. Editar Exame um Utente");
            System.out.println("7. Editar Prescricao um Utente");
            System.out.println("8. Consultar Utente");
            System.out.println("9. Consultar Consulta do Utente");
            System.out.println("10. Consultar Prescrições do Utente");
            System.out.println("11. Consultar Exames do Utente");
            System.out.println("12. Consultar Dados Fisiológicos do Utente");
            System.out.println("13. Consultar Ficha Médica do Utente");
            System.out.println("14. Consultar todos os Familiares de um Utente");
            System.out.println("15. Consultar todos os Medicamentos prescritos");
            System.out.println("16. Histórico de todos os Utentes da Clínica"); //TA
            System.out.println("17. Histórico de todos os Familiares Registados da Clínica"); //TA
            System.out.println("18. Histórico de todas as Fichas Médicas dos utentes da Clínica"); //TA
            System.out.println("19. Histórico de todas as leituras de Dados Fisiológicos realizadas"); //TA
            System.out.println("20. Histórico de todos os Exames realizados"); //TA
            System.out.println("21. Histórico de todas as Consultas realizadas");
            System.out.println("22. Histórico de todos as Prescricoes realizadas"); //TA//TA
            System.out.println("23. Número total de consultas efetuadas na Clínica"); //TA
            System.out.println("24. Numero total de consultas efetuadas num determinado dia"); //TA
            System.out.println("25. Histórico de exames realizados num determinado dia"); //TA
            System.out.println("26. Utentes com leituras fisiológicas que indiquem obesidade");//ta
            System.out.println("27. Histórico de todas as Prescricoes por procura do nome do medicamento e data de início da toma");
            System.out.println("28. Histórico de  Consultas por idMédico");
            System.out.println("29. Sair"); // pretende salvar alteracoes??
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();
            switch (opcao) {
                case 1:
                    adicionarDadosFisiologicos(scanner, mi);
                    break;
                case 2:
                    adicionarExame(scanner, mi);
                    break;
                case 3:
                    adicionarPrescricao(scanner, mi);
                    break;
                case 4:
                    adicionarConsulta(scanner, mi);
                    break;
                case 5:
                    editarConsulta(scanner,mi);
                    break;
                case 6:
                    editarExame(scanner,mi);
                    break;
                case 7:
                    editarPrescricao(scanner,mi);
                    break;
                case 8:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.consultarUtente(idUtente));
                    break;
                case 9:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.consultarConsultaUtente(idUtente));
                    break;
                case 10:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.consultarPrescricoesUtente(idUtente));
                    break;
                case 11:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.consultarExamesUtente(idUtente));
                    break;
                case 12:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.consultarDadosFisiologicosUtente(idUtente));
                    break;

                case 13:
                    System.out.println(mi.medicamentos());
                    break;
                case 14:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.consultarFMedicaUtente(idUtente));
                    break;
                case 15:
                    System.out.print("Digite o ID do Utente: ");
                    idUtente = scanner.nextInt();
                    System.out.println(mi.listarFamPUt(idUtente));
                    break;


                case 16:
                    System.out.println(mi.listarUtentes());
                    break;
                case 17:
                    System.out.println(mi.listarFamiliares());
                    break;
                case 18:
                    System.out.println(mi.listarFichasMedicas());
                    break;

                case 19:
                    System.out.println(mi.listarDadosFisiologicos());
                    break;
                case 20:
                    System.out.println(mi.listarExames());
                    break;
                case 21:
                    System.out.println(mi.listarConsultas());
                    break;
                case 22:
                    System.out.println(mi.listarPrescricoes());
                    break;
                case 23:
                    System.out.println(mi.numeroTotalConsultas());
                    break;
                case 24:
                    System.out.println("Numero de Consultas no dia X. Digite um dia no formato yyyy-MM-ddTHH:mm ( não importa as horas e minutos que inserir)");
                    String data = scanner.next();
                    LocalDateTime dataC = LocalDateTime.parse(data);
                    System.out.println(mi.numeroConsultasDia(dataC));
                    break;
                case 25:
                    System.out.println("Numero de Exames no dia X. Digite um dia no formato yyyy-MM-ddTHH:mm ( não importa as horas e minutos que inserir)");
                    String data1 = scanner.next();
                    LocalDateTime dataE = LocalDateTime.parse(data1);
                    System.out.println(mi.examesDia(dataE));
                    break;
                case 26:
                    System.out.println(mi.utentesObesos());
                    break;

                case 27:
                    System.out.print("Digite o nome do medicamento: ");
                    String medicamento = scanner.next();

                    System.out.print("Digite a data da prescrição (formato: yyyy-MM-dd): ");
                    String dataPrescricaoStr = scanner.next();
                    LocalDate dataPrescricao = LocalDate.parse(dataPrescricaoStr);
                    System.out.println(mi.prescricaoMed(medicamento,dataPrescricao ));
                    break;
                case 28:
                    System.out.print("Digite o id Médico para o qual pretende ver as Consultas: ");
                    int idMedico = scanner.nextInt();
                    System.out.println(mi.consultasPMed(idMedico));
                    break;
                case 29:
                    System.out.println();
                    System.out.print("Deseja guardar as alterações? (S/N): ");
                    String resposta = scanner.next().toUpperCase();

                    if ("S".equals(resposta)) {
                        mi.save("dadosUtente.csv", "dadosFamiliar.csv", "dadosMedicos.csv", "dadosRececionista.csv",
                                "dadosFisiologicos.csv", "dadosExames.csv", "dadosConsultas.csv", "dadosPrescricoes.csv");
                        System.out.println("Alterações guardadas com sucesso!");
                    } else {
                        System.out.println("Alterações não guardadas.");
                    }
                    System.out.println("Saiu do Sistema!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (opcao != 29);
        //Thread.sleep(5000);
        scanner.close();
    }


    private static void adicionarDadosFisiologicos(Scanner scanner, MedicoInterface mi) throws RemoteException {
        System.out.print("Digite o ID do Utente: ");
        int idUtente = scanner.nextInt();
        System.out.print("Digite a data da leitura (formato: yyyy-MM-dd): ");
        String dataLeituraStr = scanner.next();
        LocalDate dataLeitura = LocalDate.parse(dataLeituraStr);

        System.out.print("Digite a pressão arterial: ");
        double pressaoArterial = scanner.nextDouble();

        System.out.print("Digite a temperatura corporal: ");
        double temperaturaCorporal = scanner.nextDouble();

        System.out.print("Digite a saturação de O2: ");
        double saturacaoO2 = scanner.nextDouble();

        System.out.print("Digite a frequência cardíaca: ");
        double frequenciaCardiaca = scanner.nextDouble();

        System.out.print("Digite os níveis de colesterol: ");
        double niveisColesterol = scanner.nextDouble();

        System.out.print("Digite o peso: ");
        double peso = scanner.nextDouble();

        System.out.print("Digite a altura: ");
        double altura = scanner.nextDouble();

        mi.adicionarDadosFisiologicosUt(idUtente, dataLeitura, pressaoArterial, temperaturaCorporal,
                saturacaoO2, frequenciaCardiaca, niveisColesterol, peso, altura);


    }

    private static void adicionarExame(Scanner scanner, MedicoInterface mi) throws RemoteException {
        System.out.print("Digite o ID do Utente: ");
        int idUtente = scanner.nextInt();

        System.out.print("Digite a data do exame (formato: yyyy-MM-ddTHH:mm): ");
        String dataExameStr = scanner.next();
        LocalDateTime dataExame = LocalDateTime.parse(dataExameStr);

        System.out.print("Digite o tipo de exame: ");
        String tipoExame = scanner.next();

        System.out.print("Digite a descrição do exame: ");
        String descricaoExame = scanner.next();

        mi.adicionarExameUt(idUtente, dataExame, tipoExame, descricaoExame);
        System.out.println("Exame adicionado com sucesso ao utente "+ " "+idUtente);
    }

    private static void adicionarPrescricao(Scanner scanner, MedicoInterface mi) throws RemoteException {
        System.out.print("Digite o ID do Utente: ");
        int idUtente = scanner.nextInt();

        System.out.print("Digite o nome do medicamento: ");
        String medicamento = scanner.next();

        System.out.print("Digite a data de início da toma (formato: yyyy-MM-dd): ");
        String dataInicioTomaStr = scanner.next();
        LocalDate dataInicioToma = LocalDate.parse(dataInicioTomaStr);

        System.out.print("Digite a duração do tratamento: ");
        String duracao = scanner.next();

        System.out.print("Digite as tomas diárias: ");
        String tomas = scanner.next();

        System.out.print("Digite o ID do médico: ");
        int idMedico = scanner.nextInt();


        mi.adicionarPrescricaoUt(idUtente, medicamento, dataInicioToma, duracao, tomas, idMedico);


    }

    private static void adicionarConsulta(Scanner scanner, MedicoInterface mi) throws RemoteException {
        System.out.print("Crie um ID da Consulta: ");
        int idConsulta = scanner.nextInt();

        System.out.print("Digite o ID do Utente: ");
        int idUtente = scanner.nextInt();
        System.out.print("Digite a data da consulta (formato: yyyy-MM-ddTHH:mm): ");
        String dataConsultaStr = scanner.next();
        LocalDateTime dataConsulta = LocalDateTime.parse(dataConsultaStr);

        System.out.print("Digite o tipo de consulta: ");
        String tipoConsulta = scanner.next();

        System.out.print("Digite o ID do médico que irá realizar a consulta: ");
        int idMedico = scanner.nextInt();

        System.out.print("Digite as observações: ");
        String observacoes = scanner.next();

        mi.adicionarConsultaUt(idConsulta, idUtente, dataConsulta, tipoConsulta, idMedico, observacoes);


    }
    private static void editarConsulta(Scanner scanner, MedicoInterface mi) throws RemoteException {
        System.out.print("Digite o ID da Consulta a ser editada: ");
        int idConsulta = scanner.nextInt();
        System.out.print("Digite o ID do Utente associado a esta consulta: ");
        int idUtente = scanner.nextInt();

        System.out.print("Digite a nova data da consulta (formato: yyyy-MM-ddTHH:mm).Se pretender manter coloque *");
        String dataNova = scanner.next();

        System.out.print("Digite o novo ID do médico. Se pretender manter o Médico coloque *: ");
        String idMedico = scanner.next();

        System.out.print("Digite as novas observações. Se pretender manter as observacoes coloque *");
        String observacoes = scanner.next();

        mi.editaConsulta(idConsulta, idUtente, dataNova, idMedico, observacoes);

    }
    private static void editarExame(Scanner scanner, MedicoInterface mi) throws RemoteException {
        System.out.print("Digite o ID do Utente para editar o exame: ");
        int idUtente = scanner.nextInt();

        System.out.print("Digite a data antiga do exame (formato: yyyy-MM-ddTHH:mm): ");
        String dataAntigaStr = scanner.next();
        LocalDateTime dataAntiga = LocalDateTime.parse(dataAntigaStr);

        System.out.print("Digite a nova data do exame.Se pretender manter coloque * :");
        String dataNova = scanner.next();

        System.out.print("Digite o tipo do exame.Se pretender manter coloque * :");
        String tipoExame = scanner.next();

        System.out.print("Digite a descrição do exame.Se pretender manter coloque * :");
        String descricao = scanner.next();


        mi.editaExame(idUtente, dataAntiga, dataNova, tipoExame, descricao);

    }

    public static void editarPrescricao(Scanner scanner, MedicoInterface mi) throws RemoteException {

        System.out.print("Digite o ID do Utente para editar a prescricao: ");
        int idUtente = scanner.nextInt();

        System.out.print("Digite o Medicamento Antigo: ");
        String medicamentoAnt = scanner.next();

        System.out.print("Digite a  Data de Início da Toma (yyyy-MM-dd):");
        String dataAntigaStr = scanner.next();
        LocalDate dataAntiga1 = LocalDate.parse(dataAntigaStr);

        System.out.print("Novo Medicamento.Se pretender manter coloque * : ");
        String medicamentoNovo = scanner.next();

        System.out.print("Duração.Se pretender manter coloque * : ");
        String duracao = scanner.next();

        System.out.print("Tomas.Se pretender manter coloque * : ");
        String tomas = scanner.next();

        System.out.print("Digite o novo ID do médico. Se pretender manter o Médico coloque *: ");
        String idMedico = scanner.next();

        mi.editaPrescricao(idUtente, medicamentoAnt, dataAntiga1, medicamentoNovo, duracao, tomas, idMedico);

    }

}


