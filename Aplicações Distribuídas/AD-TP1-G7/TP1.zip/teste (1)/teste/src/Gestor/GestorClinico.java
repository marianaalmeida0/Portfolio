package Gestor;

import Inter.*;
import Inter.RececionistaInterface;
import Model.*;

import java.io.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class GestorClinico extends UnicastRemoteObject implements RececionistaInterface, MedicoInterface, UtenteInterface, FamiliarInterface, Serializable{
    public Map<Integer, Utente> dicTUtentes;
    private Map<Integer, Medico> dicTMedicos;
    private Map<Integer, Familiar> dicTFamiliares;
    private Map<LocalDateTime, List<Exame>> dicTExames;
    private Map<LocalDate, DadosFisiologicos> dicTDadosF;
    private Map<String, List<Prescricao>> dicTPrescricoes;
    private Map<LocalDateTime, List<Consulta>> dicTConsultas;
    private Map<Integer, FichaMedica> dicTFichasMedicas;
    private Map<Integer, RececionistaHospitalar> dicTRececionista;


    public GestorClinico() throws RemoteException {
        super();
        dicTUtentes = new HashMap<>();
        dicTFamiliares = new HashMap<>();
        dicTMedicos = new HashMap<>();
        dicTExames = new HashMap<>();
        dicTFichasMedicas = new HashMap<>();
        dicTConsultas = new HashMap<>();
        dicTPrescricoes = new HashMap<>();
        dicTDadosF = new HashMap<>();
        dicTRececionista = new HashMap<>();
    }

/*
     REGISTAR UTILIZADORES
     */

    public synchronized void registaUtente(int idUtente, String cc, String nome, String niss,
                                           String dataNascimento, String genero, String contacto,
                                           String email) throws RemoteException {
        if (this.dicTUtentes.containsKey(idUtente)) {
            throw new RemoteException();
        } else {
            Utente u = new Utente(idUtente, cc, nome, niss, dataNascimento, genero, contacto, email);
            dicTUtentes.put(idUtente, u);
            criaFichaMedicaUtente(u);
        }
    }


    //Registo de Medico
    public synchronized void registarMedico(int idMedico, String cc, String nome, String morada, String contacto, String email,
                                            String especialidade) throws RemoteException {
        if (!this.dicTMedicos.containsKey(idMedico)) {
            Medico m = new Medico(idMedico, cc, nome, morada, contacto, email,
                    especialidade);
            this.dicTMedicos.put(idMedico, m);
        }
    }

    //Registo de Familiar
    public synchronized void registarFamiliar(int idUtilizador, String nome, String parentesco, int idUtenteAssociado)
            throws RemoteException {
        if (this.dicTUtentes.containsKey(idUtenteAssociado)) {
            Utente utenteAssociado = dicTUtentes.get(idUtenteAssociado);
            if (!this.dicTFamiliares.containsKey(idUtilizador)) {
                Familiar f = new Familiar(idUtilizador, nome, parentesco, utenteAssociado);
                this.dicTFamiliares.put(idUtilizador, f);
            } else throw new RemoteException();
        } else throw new RemoteException();
    }

    //Registo de Rececionista

    public synchronized void registarRececionista(int idRececionista, String cc, String nome, String
            morada, String contacto, String email, String departamento) throws RemoteException {
        if (!this.dicTRececionista.containsKey(idRececionista)) {
            RececionistaHospitalar r = new RececionistaHospitalar(idRececionista, cc, nome,
                    morada, contacto, email, departamento);
            this.dicTRececionista.put(idRececionista, r);
        }
    }


    /*
             CONSTRUTOR FICHA MEDICA
         */
    public synchronized void criaFichaMedicaUtente(Utente u) throws RemoteException {
        if (!dicTFichasMedicas.containsKey(u.getIdUtente())) {
            FichaMedica fm = new FichaMedica(u);
            fm.setUtente(u);
            this.dicTFichasMedicas.put(u.getIdUtente(), fm);
        } else {
            throw new RemoteException();
        }

    }


    public String listarUtentes() throws RemoteException {

            String st = "";
            for (Map.Entry<Integer, Utente> utente : dicTUtentes.entrySet()) {
                Utente infoUtente = utente.getValue();
                String string = infoUtente.toString();
                st = st + string + " \n";
            }
            return st;

    }
     /*
     ADICIONAR DADOS CLINICOS
     */

    // Adicionar Dados Fisiologicos

    public synchronized void adicionarDadosFisiologicosUt(int idUtente, LocalDate dataLeitura, double pressaoArterial, double temperaturaCorporal,
                                                          double saturacaoO2, double frequenciaCardiaca, double niveisColesterol,
                                                          double peso, double altura) throws RemoteException {

        var fichaMedica = this.dicTFichasMedicas.get(idUtente);
        fichaMedica.adicionarDadosFisiologicos(dataLeitura, pressaoArterial,
                temperaturaCorporal, saturacaoO2, frequenciaCardiaca, niveisColesterol,
                peso, altura);
        dicTDadosF.put(dataLeitura, (new DadosFisiologicos(dataLeitura, pressaoArterial,
                temperaturaCorporal, saturacaoO2, frequenciaCardiaca, niveisColesterol,
                peso, altura)));
    }

    // Adicionar Exames

    public synchronized void adicionarExameUt(int idUtente, LocalDateTime dataExame, String tipoExame, String descricao)
            throws RemoteException {
        FichaMedica fichaMedica = this.dicTFichasMedicas.get(idUtente);
        fichaMedica.adicionarExame(dataExame, tipoExame, descricao);

        LocalDateTime datapDic = dataExame.withMinute(0).withSecond(0).withNano(0);

        if (!this.dicTExames.containsKey(datapDic)) {
            List<Exame> ListE = new ArrayList<Exame>();
            ListE.add(new Exame(dataExame, tipoExame, descricao));
            dicTExames.put(datapDic, ListE);
        } else {
            dicTExames.get(datapDic).add(new Exame(dataExame, tipoExame, descricao));
        }
    }


    // Adicionar Prescrição
    public synchronized void adicionarPrescricaoUt(int idUtente, String medicamento, LocalDate dataInicioToma,
                                                   String duracao, String tomas, int idmedico)
            throws RemoteException {
        var fichaMedica = this.dicTFichasMedicas.get(idUtente);
        if (!dicTMedicos.containsKey(idmedico)) {
            throw new RemoteException();
        } else {
            Medico medico = dicTMedicos.get(idmedico);
            fichaMedica.adicionarPrescricao(medicamento, dataInicioToma, duracao, tomas, medico);

            if (!this.dicTPrescricoes.containsKey(medicamento)) {
                List<Prescricao> ListP = new ArrayList<Prescricao>();
                ListP.add(new Prescricao(medicamento, dataInicioToma, duracao, tomas, medico));
                dicTPrescricoes.put(medicamento, ListP);
            } else {
                dicTPrescricoes.get(medicamento).add(new Prescricao(medicamento, dataInicioToma, duracao, tomas, medico));
            }
        }


    }


    // Adicionar Consulta

    public synchronized void adicionarConsultaUt(int idConulta, int idUtente, LocalDateTime dataConsulta, String tipoConsulta, int idMedico, String observacoes)
            throws RemoteException {

        var fichaMedica = this.dicTFichasMedicas.get(idUtente);
        if (!dicTMedicos.containsKey(idMedico)) {
            throw new RemoteException();
        } else {
            Medico medico = dicTMedicos.get(idMedico);

            fichaMedica.adicionarConsulta(idConulta, dataConsulta, tipoConsulta, medico, observacoes);

            LocalDateTime datapDic = dataConsulta.withMinute(0).withSecond(0).withNano(0);

            if (!this.dicTConsultas.containsKey(datapDic)) {
                List<Consulta> ListC = new ArrayList<Consulta>();
                ListC.add(new Consulta(idConulta, dataConsulta, tipoConsulta, medico, observacoes));
                dicTConsultas.put(datapDic, ListC);
            } else {
                dicTConsultas.get(datapDic).add(new Consulta(idConulta, dataConsulta, tipoConsulta, medico, observacoes));
            }
        }

    }


    /*
    CONSULTAR DADOS
     */

    //Consultar Utente
    public synchronized String consultarUtente(int idUtente) throws RemoteException {
        if (!this.dicTUtentes.containsKey(idUtente)) {
            throw new RemoteException();
        } else {
            return this.dicTUtentes.get(idUtente).toString();
        }
    }

    //Consultar Consultas Utente

    public synchronized String consultarConsultaUtente(int idUtente) throws RemoteException {
        if (dicTUtentes.containsKey(idUtente)){
            var fichaMedica = this.dicTFichasMedicas.get(idUtente);
            return fichaMedica.historicoConsultas();
        }else{
            throw new RemoteException();
        }

    }


    //Consultar Prescricoes Utente
    public synchronized String consultarPrescricoesUtente(int idUtente) throws RemoteException {
        var fichaMedica = this.dicTFichasMedicas.get(idUtente);
        return fichaMedica.historicoPrescricoes();
    }


    //Consultar Exames Utente
    public synchronized String consultarExamesUtente(int idUtente) throws RemoteException {
        var fichaMedica = this.dicTFichasMedicas.get(idUtente);
        return fichaMedica.historicoExames();
    }

    //Consultar DadosFisiologicos Utente

    public synchronized String consultarDadosFisiologicosUtente(int idUtente) throws RemoteException {
        var fichaMedica = this.dicTFichasMedicas.get(idUtente);
        return fichaMedica.historicoDadosF();
    }


    //Consultar Ficha médica do Utente
    public synchronized String consultarFMedicaUtente(int idUtente) throws RemoteException{
        if(dicTUtentes.containsKey(idUtente)){
            var fichaMedica = this.dicTFichasMedicas.get(idUtente);
            return fichaMedica.toString();
        }else{
            throw new RemoteException();
        }

    }

    // Familiar consultar Utente

    public String familiarConsultaUt(int idFamiliar, int idUtente) throws RemoteException {
        Boolean var = null;
        try {
            var = verificaPermissao(idFamiliar, idUtente);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        if (var) {
            Familiar f = dicTFamiliares.get(idFamiliar);
            return f.getUtenteAssociado().toString();
        } else {
            throw new RemoteException();
        }

    }

    // Familiar consultar Ficha Medica Utente

    public synchronized String familiarConsultaFMed(int idFamiliar, int idUtente) throws RemoteException {
        Boolean var = null;
        try {
            var = verificaPermissao(idFamiliar, idUtente);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        if (var) {
            Familiar f = dicTFamiliares.get(idFamiliar);
            FichaMedica fm = dicTFichasMedicas.get(idUtente);
            return fm.toString();
        } else {
            throw new RemoteException();
        }

    }


    // Verifica permissão do Familiar
    public synchronized Boolean verificaPermissao(int idFamiliar, int idUtente) throws RemoteException {
        if (!dicTFamiliares.containsKey(idFamiliar)) {
            throw new RemoteException();
        } else {
            Familiar f = dicTFamiliares.get(idFamiliar);
            if (f.getUtenteAssociado().getIdUtente() == (idUtente)) {
                return true;
            } else {
                return false;
            }
        }
    }
    // Familiar consultar Consultas
    public synchronized String familiarConsultaConsultas(int idFamiliar, int idUtente) throws RemoteException {
        Boolean var = verificaPermissao(idFamiliar, idUtente);
        if (var) {
            Familiar f = dicTFamiliares.get(idFamiliar);
            FichaMedica fm = dicTFichasMedicas.get(idUtente);
            Map<LocalDateTime, Consulta> consultas=fm.getConsultas();
            return consultas.toString();
        } else {
            throw new RemoteException();
        }

    }


    /*
    LISTAR TODOS OS DADOS
     */

    // Listar Familiares
    public synchronized String listarFamiliares() throws RemoteException{
        String st = "";
        for (Map.Entry<Integer, Familiar> familiar : dicTFamiliares.entrySet()) {
            Familiar infoFam = familiar.getValue();
            String string = infoFam.toString();
            st = st + string + " \n";
        }
        return st;
    }

    // Listar Profissionais
    public synchronized String listarMedicos() throws RemoteException {
        String st = "";
        for (Map.Entry<Integer, Medico> medico : dicTMedicos.entrySet()) {
            Medico infomed = medico.getValue();
            String string = infomed.toString();
            st = st + string + " \n";
        }
        return st;
    }

    // Listar Todas as Fichas Médicas
    public synchronized String listarFichasMedicas() throws RemoteException {
        String st = "";
        for (Map.Entry<Integer, FichaMedica> fm : dicTFichasMedicas.entrySet()) {
            FichaMedica infofm = fm.getValue();
            String string = infofm.toString();
            st = st + string + " \n";
        }
        return st;
    }

    //Listar Todos os DadosFisiologicos
    public synchronized String listarDadosFisiologicos() throws RemoteException {
        String st = "";
        for (Map.Entry<LocalDate, DadosFisiologicos> dados : dicTDadosF.entrySet()) {
            DadosFisiologicos infoDados = dados.getValue();
            String string = infoDados.toString();
            st = st + string + " \n";
        }
        return st;
    }

    //Listar Exames
    public synchronized String listarExames() throws RemoteException {
        String st = "";
        for (Map.Entry<LocalDateTime, List<Exame>> exames : dicTExames.entrySet()) {
            List<Exame> infoExames = exames.getValue();
            String string = infoExames.toString();
            st = st + string + " \n";
        }
        return st;
    }

    //Listar Prescrições
    public synchronized String listarPrescricoes() throws RemoteException {
        String st = "";
        for (Map.Entry<String, List<Prescricao>> prescricoes : dicTPrescricoes.entrySet()) {
            List<Prescricao> infoPrescricoes = prescricoes.getValue();
            String string = infoPrescricoes.toString();
            st = st + string + " \n";
        }
        return st;
    }

    //Listar consultas
    public synchronized String listarConsultas() throws RemoteException {
        String st = "";
        for (Map.Entry<LocalDateTime, List<Consulta>> consultas : dicTConsultas.entrySet()) {
            List<Consulta> infoConsultas = consultas.getValue();
            String string = infoConsultas.toString();
            st = st + string + " \n";
        }
        return st;
    }

    //Listar Rececionista
    public synchronized String listarRececionista() throws RemoteException {

        String st = "";
        for (Map.Entry<Integer, RececionistaHospitalar> rececionista : dicTRececionista.entrySet()) {
            RececionistaHospitalar inforec = rececionista.getValue();
            String string = inforec.toString();
            st = st + string + " \n";
        }
        return st;
    }

    //Listar medicação
    public synchronized String medicamentos () throws RemoteException {
        String medic= "Medicamentos prescritos: ";
        Set<String> chaves= dicTPrescricoes.keySet();
        medic=medic + String.join(", ", chaves);
        return medic;
    }

    /*
    ESTATISTICAS
     */

    //Número total de consultas
    public synchronized int numeroTotalConsultas() throws RemoteException {
        int totalConsultas = 0;

        for (List<Consulta> consultas : dicTConsultas.values()) {
            totalConsultas += consultas.size();
        }

        return totalConsultas;
    }

    //Número de consultas num dia
    public synchronized int numeroConsultasDia(LocalDateTime data) throws RemoteException {

        int totalConsultas = 0;
        for (LocalDateTime key : dicTConsultas.keySet()) {
            LocalDateTime tratada = key.withHour(0).withMinute(0).withSecond(0);
            if (tratada.toString().equals(data.withHour(0).withMinute(0).withSecond(0).toString())) {

                List<Consulta> lista = dicTConsultas.get(key);
                totalConsultas += lista.size();
                System.out.println("total" + totalConsultas);
            }
        }
        return totalConsultas;
    }


    //Listar exames num dia x
    public synchronized List<Exame> examesDia(LocalDateTime data) throws RemoteException{
        List<Exame> listaDia = new ArrayList<>();

        for (LocalDateTime key : dicTExames.keySet()) {
            LocalDateTime tratada = key.withHour(0).withMinute(0).withSecond(0);
            if (tratada.toString().equals(data.withHour(0).withMinute(0).withSecond(0).toString())) {
                List<Exame> lista = dicTExames.get(key);
                listaDia.addAll(lista);
            }
        }

        return listaDia;
    }

    //Listar utentes obesos
    public String utentesObesos() throws RemoteException {
        List<Utente> utentesComIMCSup25 = new ArrayList<>();
        String s="";
        for (Utente utente : dicTUtentes.values()) {
            FichaMedica fichaMedica = dicTFichasMedicas.get(utente.getIdUtente());
            for (DadosFisiologicos dados : fichaMedica.getDadosFisiologicos().values()) {
                double peso = dados.getPeso();
                double altura = dados.getAltura();
                double imc = peso / ((altura / 100) * (altura / 100));
                if (imc > 25.0) {
                    utentesComIMCSup25.add(utente);
                    s=s+utente.toString()+"\n";
                    //break;
                }
            }
        }

        return s;
    }



    // Listar Todos os Familiares associados a um Utente

    public String listarFamPUt (int idUtente) throws RemoteException {

        if (!dicTUtentes.containsKey(idUtente)){
            throw new RemoteException();
        }
        else {
            String listaFam = "Familiares associado ao utente " + Integer.toString(idUtente) + ":";

            for (Map.Entry<Integer, Familiar> familiar : dicTFamiliares.entrySet()) {
                if ((familiar.getValue().getUtenteAssociado().getIdUtente())==(idUtente)) {
                    Familiar fam = familiar.getValue();
                    listaFam = listaFam + fam.toString();
                }
            }
            return listaFam;
        }
    }

    //Listar prescrições de um dado medicamento

    public synchronized String prescricaoMed (String medicamento, LocalDate dataP)
            throws RemoteException {

        List<Prescricao> medicacaoPDia = new ArrayList<>();

        if (!dicTPrescricoes.containsKey(medicamento)) {
            throw new RemoteException();
        } else {

            List<Prescricao> presc = dicTPrescricoes.get(medicamento);
            String s="";
            for (Prescricao p : presc) {
                if ((p.getDataInicioToma().toString()).equals(dataP.toString())) {
                    s=s+p.toString()+"\n";
                }
            }

            return s;
        }
    }

    //Listar consultas de um médico
    public synchronized String consultasPMed (int idMedicoP) throws RemoteException {
        System.out.println(dicTConsultas.values());
        String st="";
        List<Consulta> consultasEnc= new ArrayList<>();
        if (!dicTMedicos.containsKey(idMedicoP)){
            throw new RemoteException();
        }else {
            for (List<Consulta> consultas : dicTConsultas.values()) {
                for (Consulta consulta : consultas) {
                    if (consulta.getMedico().getIdMedico() == idMedicoP) {
                        consultasEnc.add(consulta);
                    }
                }
            }
            for (Consulta consulta : consultasEnc) {
                st += consulta + " \n";
            }

            return st;
        }
    }

    /*
            CARREGAR DADOS DE FICHEIROS

             */
    public String loadDados(String u,String f,String m,String r, String df, String e,
                            String c, String p) throws RemoteException{
        loadUtentesFromCSV(u);
        loadFamiliaresFromCSV(f);
        loadMedicosFromCSV(m);
        loadRececionistaFromCSV(r);
        loadDadosFisiologicosFromCSV(df);
        loadExamesFromCSV(e);
        loadConsultasFromCSV(c);
        loadPrescricaoFromCSV(p);

        return "Carregamento dos dados feito com sucesso"   ;

    }

    // Carregar dados dos Utentes
    public String loadUtentesFromCSV(String utentesCsvFilePath) throws RemoteException {

        try (BufferedReader reader = new BufferedReader(new FileReader(utentesCsvFilePath))) {
            String line;
            reader.readLine();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 8) {
                    continue;
                }

                int idUtente = Integer.parseInt(parts[0]);
                String cc = parts[1];
                String nome = parts[2];
                String niss = parts[3];
                String dataNascimento = parts[4];
                String genero = parts[5];
                String contacto = parts[6];
                String email = parts[7];

                registaUtente(idUtente, cc, nome, niss, dataNascimento, genero, contacto, email);
            }

        } catch (IOException e) {
            throw new RemoteException();
        }

        return "Dataset Utentes carregado com sucesso";


    }

    // Carregar dados dos Familiares
    public String loadFamiliaresFromCSV(String familiaresCsvFilePath) throws RemoteException{

        try (BufferedReader reader = new BufferedReader(new FileReader(familiaresCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 4) {
                    continue;
                }

                int idUtilizador = Integer.parseInt(parts[0]);
                String nome = parts[1];
                String parentesco = parts[2];
                int idUtenteAssociado = Integer.parseInt((parts[3]));
                registarFamiliar(idUtilizador, nome, parentesco, idUtenteAssociado);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Dataset Familiar carregado com sucesso";

    }

    // Carregar dados dos Medicos
    public String loadMedicosFromCSV(String profsCsvFilePath) throws RemoteException{
        try (BufferedReader reader = new BufferedReader(new FileReader(profsCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 7) {
                    continue;
                }
                int idMedico = Integer.parseInt(parts[0]);
                String cc = parts[1];
                String nome = parts[2];
                String morada = parts[3];
                String contacto = parts[4];
                String email = parts[5];
                String especialidade = parts[6];
                registarMedico(idMedico, cc, nome, morada, contacto, email,
                        especialidade);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Dataset Medicos carregado com sucesso";
    }

    // Carregar dados das Consultas
    public String loadConsultasFromCSV(String consultasCsvFilePath) throws RemoteException{
        try (BufferedReader reader = new BufferedReader(new FileReader(consultasCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 6) {
                    continue;
                }
                int idConsulta = Integer.parseInt(parts[0]);
                int idUtente = Integer.parseInt(parts[1]);
                LocalDateTime dataConsulta = LocalDateTime.parse(parts[2]);
                String tipoConsulta = parts[3];
                int idmedico = Integer.parseInt(parts[4]);
                String observacoes = parts[5];
                adicionarConsultaUt(idConsulta, idUtente, dataConsulta, tipoConsulta, idmedico, observacoes);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Dataset Consultas carregado com sucesso";

    }

    // Carregar dados dos Dados Fisiologicos
    public String loadDadosFisiologicosFromCSV(String dadosCsvFilePath) throws RemoteException{
        try (BufferedReader reader = new BufferedReader(new FileReader(dadosCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 9) {
                    continue;
                }
                int idUtente = Integer.parseInt(parts[0]);
                LocalDate dataLeitura = LocalDate.parse(parts[1]);
                double pressaoArterial = Double.parseDouble(parts[2]);
                double temperaturaCorporal = Double.parseDouble(parts[3]);
                double saturacaoO2 = Double.parseDouble(parts[4]);
                double frequenciaCardiaca = Double.parseDouble(parts[5]);
                double niveisColesterol = Double.parseDouble(parts[6]);
                double peso = Double.parseDouble(parts[7]);
                double altura = Double.parseDouble(parts[8]);
                adicionarDadosFisiologicosUt(idUtente, dataLeitura, pressaoArterial, temperaturaCorporal,
                        saturacaoO2, frequenciaCardiaca, niveisColesterol, peso, altura);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Dataset DadosFisiologicos carregado com sucesso";
    }

    // Carregar dados dos Exames
    public String loadExamesFromCSV(String examesCsvFilePath) throws RemoteException{
        try (BufferedReader reader = new BufferedReader(new FileReader(examesCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 4) {

                    continue;
                }
                int idUtente = Integer.parseInt(parts[0]);
                LocalDateTime dataExame = LocalDateTime.parse(parts[1]);
                String tipoExame = parts[2];
                String descricao = parts[3];
                adicionarExameUt(idUtente, dataExame, tipoExame, descricao);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Dataset Exames carregado com sucesso";
    }

    // Carregar dados dos Prescricoes
    public String loadPrescricaoFromCSV(String precricaoCsvFilePath) throws RemoteException{

        try (BufferedReader reader = new BufferedReader(new FileReader(precricaoCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 6) {
                    continue;
                }
                int idUtente = Integer.parseInt(parts[0]);
                String medicamento = parts[1];
                LocalDate dataInicioToma = LocalDate.parse(parts[2]);
                String duracao = parts[3];
                String tomas = parts[4];
                int idMedico = Integer.parseInt(parts[5]);
                adicionarPrescricaoUt(idUtente, medicamento, dataInicioToma, duracao, tomas, idMedico);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Dataset Prescrições carregado com sucesso";

    }

    // Carregar dados dos Rececionista
    public String loadRececionistaFromCSV(String rececionistaCsvFilePath) throws RemoteException{
        try (BufferedReader reader = new BufferedReader(new FileReader(rececionistaCsvFilePath))) {
            String line;
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 7) {
                    continue;
                }
                int idRececionista = Integer.parseInt(parts[0]);
                String cc = parts[1];
                String nome = parts[2];
                String morada = parts[3];
                String contacto = parts[4];
                String email = parts[5];
                String departamento = parts[6];
                registarRececionista(idRececionista, cc, nome, morada, contacto, email, departamento);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Dataset Rececionista carregado com sucesso";
    }

    /*
    EDITAR DADOS
     */

    //Editar Utente (editar nome, contacto, morada, email)

    public String editaUtente(int idUtente, String contacto, String email)
            throws RemoteException {
        if (!dicTUtentes.containsKey(idUtente)) {
            throw new RemoteException();
        } else {
            Utente u = dicTUtentes.get(idUtente);
            if (!contacto.equals("*")) {
                u.setContacto(contacto);
            }
            if (!email.equals("*")) {
                u.setEmail(email);
            }
            return u.toString();
        }
    }

    //Editar Consulta (edita data, medico, observações)
    public String editaConsulta(int idConsulta, int idUtente, String dataNova, String idMedico, String observacoes)
            throws RemoteException {
        //EDITAR CONSULTAS DO UTENTE
        if (!dicTUtentes.containsKey(idUtente)) {
            throw new RemoteException();
        } else {
            FichaMedica fm = dicTFichasMedicas.get(idUtente);
            Map<LocalDateTime, Consulta> consultasUt = fm.getConsultas();
            for (LocalDateTime d : consultasUt.keySet()) {
                Consulta c = consultasUt.get(d);
                if (idConsulta == c.getIdConsulta()) {
                    if (!(dataNova).equals("*")) {
                        c.setDataConsulta(LocalDateTime.parse(dataNova));
                    }
                    if (!(idMedico).equals("*")) {
                        if (dicTMedicos.containsKey(Integer.parseInt(idMedico))) {
                            Medico m = dicTMedicos.get(Integer.parseInt(idMedico));
                            c.setMedico(m);
                        } else {
                            throw new RemoteException();
                        }
                    }
                    if (!(observacoes).equals("*")) {
                        c.setObservacoes(observacoes);
                    }
                }

            }
        }


        for (LocalDateTime d : dicTConsultas.keySet()) {
            List<Consulta> ListCons = dicTConsultas.get(d);
            for (Consulta c : ListCons) {
                if (idConsulta == c.getIdConsulta()) {
                    if (!(dataNova).equals("*")) {
                        c.setDataConsulta(LocalDateTime.parse(dataNova));
                    }
                    if (!(idMedico).equals("*")) {
                        if (dicTMedicos.containsKey(Integer.parseInt(idMedico))) {
                            Medico m = dicTMedicos.get(Integer.parseInt(idMedico));
                            c.setMedico(m);
                        } else {
                            throw new RemoteException();
                        }
                    }
                    if (!(observacoes).equals("*")) {
                        c.setObservacoes(observacoes);
                    }
                }
            }


        }
        //String s = "Alterado com sucesso";
        return listarConsultas();
    }

    public String editaExame(int idUtente, LocalDateTime dataEAntiga, String dataENova,
                             String tipoExame, String descricao) throws RemoteException{


        if (!dicTUtentes.containsKey(idUtente)) {
            throw new RemoteException();
        } else {
            FichaMedica fm = dicTFichasMedicas.get(idUtente);
            Exame exameAlt = fm.getExames().get(dataEAntiga);
            System.out.println(exameAlt);
            if(!dataENova.equals("*")){
                exameAlt.setDataExame(LocalDateTime.parse(dataENova));
            }
            if (!tipoExame.equals("*")) {
                exameAlt.setTipoExame(tipoExame);
            }
            if (!descricao.equals("*")) {
                exameAlt.setDescricao(descricao);
            }

            //No dicionário dos Exames
            for (Map.Entry<LocalDateTime,List<Exame>> entry: dicTExames.entrySet()){
                List<Exame> examesAltDt= entry.getValue();
                for (Exame e:examesAltDt) {
                    if (e.getDataExame().equals(dataEAntiga)) {

                        if (!dataENova.equals("*")) {
                            e.setDataExame(LocalDateTime.parse(dataENova));
                        }
                        if (!tipoExame.equals("*")) {
                            e.setTipoExame(tipoExame);
                        }
                        if (!descricao.equals("*")) {
                            e.setDescricao(descricao);
                        }
                    }
                }
            }
        }

        return listarExames();
    }
    public String editaPrescricao (int idUtente, String medicamentoAnt, LocalDate dataInicioToma, String medicamentoNovo,
                                   String duracao,String tomas, String idmedico) throws RemoteException {

        if (!dicTUtentes.containsKey(idUtente)) {
            throw new RemoteException();
        } else {
            FichaMedica fm = dicTFichasMedicas.get(idUtente);
            List<Prescricao> psc = fm.getPrescricoes().get(medicamentoAnt);
            for (Prescricao p:psc){
                if (p.getDataInicioToma().equals(dataInicioToma)){
                    if(!medicamentoNovo.equals("*")){
                        p.setMedicamento(medicamentoNovo);
                    }
                    if (!duracao.equals("*")){
                        p.setDuracao(duracao);
                    }
                    if(!tomas.equals("*")){
                        p.setTomas((tomas));
                    }
                    if(!idmedico.equals("*")){
                        if (dicTMedicos.containsKey(Integer.parseInt(idmedico))) {
                            Medico m = dicTMedicos.get(Integer.parseInt(idmedico));
                            p.setIdMedico(m);
                        } else {
                            throw new RemoteException();
                        }
                    }

                }
            }
            for (Map.Entry<String,List<Prescricao>> entry: dicTPrescricoes.entrySet()){
                List<Prescricao> prescAlt= entry.getValue();
                for (Prescricao p:prescAlt) {
                    if (p.getDataInicioToma().equals(dataInicioToma)) {
                        if (!medicamentoNovo.equals("*")) {
                            p.setMedicamento(medicamentoNovo);
                        }
                        if (!duracao.equals("*")) {
                            p.setDuracao(duracao);
                        }
                        if (!tomas.equals("*")){
                            p.setTomas(tomas);
                        }
                        if (!idmedico.equals("*")) {
                            if (dicTMedicos.containsKey(Integer.parseInt(idmedico))) {
                                Medico m = dicTMedicos.get(Integer.parseInt(idmedico));
                                p.setIdMedico(m);
                            } else {
                                throw new RemoteException();
                            }
                        }
                    }
                }
            }

        }
        return listarPrescricoes();
    }

    /*
    SAVE DOS DADOS
     */

    public void saveUtentes(String utentesCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(utentesCSVPath)) {

            String s="IdUtente, Cc, Nome, Niss, DataNascimento, Genero, Contacto, Email \n";
            for (Integer idUtente : dicTUtentes.keySet()) {
                Utente u = dicTUtentes.get(idUtente);
                s=s+u.getIdUtente()+","+u.getCc()+","+u.getNome()+","+u.getNiss()+","+u.getDataNascimento()+","+u.getGenero()+","+u.getContacto()+","+u.getEmail()+"\n";
            }

            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + utentesCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void saveMedicos(String medicosCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(medicosCSVPath)) {
            String s="idMedico,cc,nome,morada,contacto,email,especialidade \n";
            for (Integer idMedico : dicTMedicos.keySet()) {
                Medico m = dicTMedicos.get(idMedico);
                s=s+m.getIdMedico()+","+m.getCc()+","+m.getNome()+","+m.getMorada()+","+m.getContacto()+","+m.getEmail()+","+m.getEspecialidade()+"\n";
            }

            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + medicosCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveFamiliares(String familiaresCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(familiaresCSVPath)) {
            String s="idUtilizador,nome,parentesco,idUtenteAssociado \n";
            for (Integer idUtilizador : dicTFamiliares.keySet()) {
                Familiar f = dicTFamiliares.get(idUtilizador);
                s=s+f.getIdUtilizador()+","+f.getNome()+","+f.getParentesco()+","+f.getUtenteAssociado().getIdUtente()+"\n";
            }
            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + familiaresCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveRececionista(String rececionistaCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(rececionistaCSVPath)) {
            String s="idRececionista,cc,nome,morada,contacto,email,departamento \n";
            for (Integer idUtilizador : dicTRececionista.keySet()) {
                RececionistaHospitalar r = dicTRececionista.get(idUtilizador);
                s=s+r.getIdRececionista()+","+r.getCc()+","+r.getNome()+","+r.getMorada()+","+r.getContacto()+","+r.getEmail()+","+r.getDepartamento()+"\n";
            }
            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + rececionistaCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void savePrescricoes(String prescricoesFCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(prescricoesFCSVPath)) {
            String s="idUtente,medicamento,dataInicioToma,duracao,tomas,idMedico \n";

            for (Integer idUt : dicTFichasMedicas.keySet()) {
                FichaMedica fm= dicTFichasMedicas.get(idUt);
                Map<String, List<Prescricao>> dicPrescricoes= fm.getPrescricoes();
                for (String med :  dicPrescricoes.keySet()){
                    List<Prescricao> listP = dicPrescricoes.get(med);
                    for (Prescricao p : listP ){
                        s=s+idUt+","+p.getMedicamento()+","+p.getDataInicioToma()+","+p.getDuracao()+","+p.getTomas() +","+p.getMedico().getIdMedico()+"\n";
                    }
                }
            }
            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + prescricoesFCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveDadosF(String dadosFCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(dadosFCSVPath)) {
            String s="idUtente,dataLeitura,pressaoArterial,temperaturaCorporal,saturacaoO2,frequenciaCardiaca,niveisColesterol,peso,altura \n";

            for (Integer idUt : dicTFichasMedicas.keySet()) {
                FichaMedica fm= dicTFichasMedicas.get(idUt);
                Map<LocalDate, DadosFisiologicos> dadosFisiologicos= fm.getDadosFisiologicos();
                for (LocalDate d :  dadosFisiologicos.keySet()){
                    DadosFisiologicos df = dadosFisiologicos.get(d);
                    s=s+idUt+","+df.getDataLeitura()+","+df.getPressaoArterial()+","+df.getTemperaturaCorporal()+","+df.getSaturacaoO2()
                            +","+df.getFrequenciaCardiaca()+ "," + df.getNiveisColesterol()+ ","+ df.getPeso()+","+df.getAltura()+"\n";
                }
            }
            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + dadosFCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void saveConsultas(String consultaCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(consultaCSVPath)) {
            String s="idConsulta,idUtente,dataConsulta,tipoConsulta,idMedico,observacoes \n";

            for (Integer idUt : dicTFichasMedicas.keySet()) {
                FichaMedica fm= dicTFichasMedicas.get(idUt);
                Map<LocalDateTime, Consulta> consultas= fm.getConsultas();

                for (LocalDateTime d :  consultas.keySet()){
                    Consulta c = consultas.get(d);
                    s=s+c.getIdConsulta()+","+idUt+","+c.getDataConsulta()+","+c.getTipoConsulta()
                            +","+c.getMedico().getIdMedico()+ "," + c.getObservacoes()+"\n";
                }
            }
            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + consultaCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void saveExames(String examesCSVPath) throws RemoteException {
        try (FileWriter csvWriter = new FileWriter(examesCSVPath)) {
            String s="ID_Utente,DataExame,TipoExame,Descricao \n";

            for (Integer idUt : dicTFichasMedicas.keySet()) {
                FichaMedica fm= dicTFichasMedicas.get(idUt);
                Map<LocalDateTime, Exame> exames= fm.getExames();

                for (LocalDateTime d :  exames.keySet()){
                    Exame e = exames.get(d);
                    s=s+idUt+","+e.getDataExame()+","+e.getTipoExame()+","+e.getDescricao() +"\n";
                }
            }
            csvWriter.append(s);
            System.out.println("Selected HashMap saved to " + examesCSVPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public  void save(String u, String r, String m, String f, String df, String c, String e, String p) throws RemoteException {
        saveUtentes(u);
        saveRececionista(r);
        saveMedicos(m);
        saveFamiliares(f);
        saveDadosF(df);
        saveConsultas(c);
        saveExames(e);
        savePrescricoes(p);

    }



}

