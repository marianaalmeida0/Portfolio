package Inter;

import Model.Exame;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface MedicoInterface extends Remote {



    public void save(String u, String r, String m, String f, String df, String c, String e, String p) throws RemoteException;

    public void adicionarDadosFisiologicosUt(int idUtente, LocalDate dataLeitura, double pressaoArterial, double temperaturaCorporal,
                                             double saturacaoO2, double frequenciaCardiaca, double niveisColesterol,
                                             double peso, double altura) throws RemoteException;
    public void adicionarExameUt(int idUtente, LocalDateTime dataExame, String tipoExame, String descricao) throws RemoteException;
    public void adicionarPrescricaoUt(int idUtente, String medicamento, LocalDate dataInicioToma,
                                      String duracao, String tomas, int idmedico) throws RemoteException;
    public  void adicionarConsultaUt(int idConulta, int idUtente, LocalDateTime dataConsulta, String tipoConsulta, int idMedico, String observacoes) throws RemoteException;

    public String consultarUtente(int idUtente) throws RemoteException;
    public String consultarConsultaUtente(int idUtente) throws RemoteException;
    public String consultarExamesUtente(int idUtente) throws RemoteException;
    public String consultarPrescricoesUtente(int idUtente) throws RemoteException;
    public String consultarDadosFisiologicosUtente(int idUtente) throws RemoteException;
    public String consultarFMedicaUtente(int idUtente) throws RemoteException;



    public String editaConsulta(int idConsulta, int idUtente, String dataNova, String idMedico, String observacoes)
            throws RemoteException;
    public String editaPrescricao (int idUtente, String medicamentoAnt, LocalDate dataInicioToma, String medicamentoNovo,
                                   String duracao,String tomas, String idmedico) throws RemoteException;
    public String editaExame(int idUtente, LocalDateTime dataEAntiga, String dataENova,
                             String tipoExame, String descricao) throws RemoteException;

    public String listarUtentes() throws RemoteException;
    public String listarFamiliares() throws RemoteException;
    public String listarFichasMedicas() throws RemoteException;
    public String listarDadosFisiologicos() throws RemoteException;
    public String listarExames() throws RemoteException;
    public String listarPrescricoes() throws RemoteException;
    public String listarConsultas() throws RemoteException;
    public String medicamentos () throws RemoteException;
    public String listarFamPUt (int idUtente) throws RemoteException;
    public int numeroTotalConsultas() throws RemoteException;
    public int numeroConsultasDia(LocalDateTime data) throws RemoteException;
    public List<Exame> examesDia(LocalDateTime data) throws RemoteException;
    public String utentesObesos() throws RemoteException;
    public String prescricaoMed (String medicamento, LocalDate dataP) throws RemoteException;
    public String consultasPMed (int idMedicoP) throws RemoteException;


}
