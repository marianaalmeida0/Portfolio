package Inter;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface UtenteInterface extends Remote {


    public String consultarUtente(int idUtente) throws RemoteException;
    public String consultarConsultaUtente(int idUtente) throws RemoteException;
    public String consultarPrescricoesUtente(int idUtente) throws RemoteException;
    public String consultarExamesUtente(int idUtente) throws RemoteException;
    public String consultarDadosFisiologicosUtente(int idUtente) throws RemoteException;
    public String consultarFMedicaUtente(int idUtente) throws RemoteException;
    public String listarFamPUt (int idUtente) throws RemoteException;

}
