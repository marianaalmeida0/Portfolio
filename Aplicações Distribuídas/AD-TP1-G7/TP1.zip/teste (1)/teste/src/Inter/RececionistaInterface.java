package Inter;

import Model.Exame;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.time.LocalDateTime;
import java.util.List;

public interface RececionistaInterface extends Remote {

    public void save(String u, String r, String m, String f, String df, String c, String e, String p) throws RemoteException;


    public void registaUtente(int idUtente, String cc, String nome, String niss,
                              String dataNascimento, String genero, String contacto,
                              String email) throws RemoteException;

    public void registarMedico(int idMedico, String cc, String nome, String morada, String contacto, String email,
                               String especialidade) throws  RemoteException;
    public void registarFamiliar(int idUtilizador, String nome, String parentesco, int idUtenteAssociado) throws RemoteException;

    public  void registarRececionista(int idRececionista, String cc, String nome, String
            morada, String contacto, String email, String departamento) throws RemoteException;
    public void adicionarConsultaUt(int idConulta, int idUtente, LocalDateTime dataConsulta, String tipoConsulta, int idMedico, String observacoes) throws RemoteException;

    public String consultarUtente(int idUtente) throws RemoteException;
    public String consultarConsultaUtente(int idUtente) throws RemoteException;
    public String consultarPrescricoesUtente(int idUtente) throws RemoteException;
    public String consultarExamesUtente(int idUtente) throws RemoteException;
    public String consultarDadosFisiologicosUtente(int idUtente) throws RemoteException;
    public String consultarFMedicaUtente(int idUtente) throws RemoteException;
    public String editaUtente(int idUtente, String contacto, String email)
            throws RemoteException;
    public String editaConsulta(int idConsulta, int idUtente, String dataNova, String idMedico, String observacoes)
            throws RemoteException;
    public String listarUtentes() throws RemoteException;
    public String listarFamiliares() throws RemoteException;
    public String listarMedicos() throws RemoteException;
    public String listarFichasMedicas() throws RemoteException;
    public String listarDadosFisiologicos() throws RemoteException;
    public String listarExames() throws RemoteException;
    public String listarPrescricoes() throws RemoteException;
    public String listarConsultas() throws RemoteException;
    public String listarRececionista() throws RemoteException;
    public int numeroTotalConsultas() throws RemoteException;
    public int numeroConsultasDia(LocalDateTime data) throws RemoteException;
    public List<Exame> examesDia(LocalDateTime data) throws RemoteException;
    public String utentesObesos() throws RemoteException;
    public String listarFamPUt (int idUtente) throws RemoteException;


}

