package Inter;


import java.rmi.Remote;
import java.rmi.RemoteException;

public interface FamiliarInterface extends Remote {

    public String familiarConsultaUt(int idFamiliar, int idUtente) throws RemoteException;
    public String familiarConsultaFMed(int idFamiliar, int idUtente) throws RemoteException;
    public String familiarConsultaConsultas(int idFamiliar, int idUtente) throws RemoteException;

}








