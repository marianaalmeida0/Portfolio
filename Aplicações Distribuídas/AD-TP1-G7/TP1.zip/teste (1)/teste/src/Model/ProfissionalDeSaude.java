package Model;

public class ProfissionalDeSaude {
    private static final long serialVersionUID = 2097579571969948664L;
    private String cc;
    private String nome;
    private String morada;
    private String contacto;
    private String email;

    public ProfissionalDeSaude() {
    }

    public ProfissionalDeSaude(String cc, String nome, String morada, String contacto, String email) {
        this.nome = nome;
        this.contacto = contacto;
        this.cc = cc;
        this.morada= morada;
        this.email = email;
    }
    // Gets e Sets
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }



    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }
    public String getContacto() {

        return contacto;
    }
    public void setContacto(String contacto) {

        this.contacto = contacto;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getCc() {
        return cc;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public String getMorada() {
        return morada;
    }

    @Override
    public String toString() {
        return "Model.ProfissionalDeSaude{" +
                "cc='" + cc + '\'' +
                ", nome='" + nome + '\'' +
                ", morada='" + morada + '\'' +
                ", contacto='" + contacto + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
