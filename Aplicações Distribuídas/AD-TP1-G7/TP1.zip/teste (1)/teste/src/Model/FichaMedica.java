package Model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FichaMedica {
    private static final long serialVersionUID = 6525243436738261L;
    private Utente utente;
    private Map<LocalDate, DadosFisiologicos> dadosFisiologicos;
    private Map<LocalDateTime, Exame> exames;
    private Map<String, List<Prescricao>> prescricoes;
    private Map<LocalDateTime, Consulta> consultas;


    public FichaMedica(Utente u) {
        this.utente = utente;
        this.dadosFisiologicos = new HashMap<>();
        this.exames = new HashMap<>();
        this.prescricoes = new HashMap<>();
        this.consultas = new HashMap<>();
    }


    public void adicionarExame(LocalDateTime dataExame, String tipoExame, String descricao) {
        Exame e= new Exame(dataExame,  tipoExame,  descricao);
        exames.put(dataExame, e);
    }
    public Map<LocalDateTime, Exame> getExames() {

        return exames;
    }

    public void adicionarDadosFisiologicos(LocalDate dataLeitura, double pressaoArterial, double temperaturaCorporal,
                                           double saturacaoO2, double frequenciaCardiaca, double niveisColesterol,
                                           double peso, double altura){
        DadosFisiologicos df=new DadosFisiologicos(dataLeitura,  pressaoArterial,  temperaturaCorporal,
         saturacaoO2,  frequenciaCardiaca,  niveisColesterol,
         peso,  altura);
        dadosFisiologicos.put(dataLeitura, df);
    }

    public Map<LocalDate, DadosFisiologicos> getDadosFisiologicos() {

        return dadosFisiologicos;
    }

    public void adicionarPrescricao(String medicamento, LocalDate dataInicioToma, String duracao, String tomas, Medico medico) {
       Prescricao p= new Prescricao(medicamento, dataInicioToma, duracao, tomas, medico);
       if (!prescricoes.containsKey(medicamento)){
           List<Prescricao> ListP=new ArrayList<Prescricao>();
           ListP.add(p);
           prescricoes.put(medicamento, ListP);
       }else{
           prescricoes.get(medicamento).add(p);
       }
    }

    public Map<String, List<Prescricao>> getPrescricoes() {

        return prescricoes;
    }

    public Utente getUtente() {

        return utente;
    }

    public void setUtente(Utente utente) {
        this.utente = utente;
    }


    public void adicionarConsulta(int idConsulta, LocalDateTime dataConsulta, String tipoConsulta, Medico medico, String observacoes) {
        Consulta c= new Consulta(idConsulta, dataConsulta,  tipoConsulta,  medico, observacoes);
        consultas.put(dataConsulta, c);
    }
    public Map<LocalDateTime, Consulta> getConsultas() {

        return consultas;
    }

    public String historicoConsultas(){
        String s= "CONSULTAS DO UTENTE " + utente.getIdUtente();
        s=s+"\n";
        for ( LocalDateTime data : consultas.keySet()){
            s=s+ " "+ data.toString()+"     :      "+ consultas.get(data) + "\n";
        }
        return s;
    }
    public String historicoPrescricoes(){
        String s= "PRESCRICOES DO UTENTE "+ utente.getIdUtente();
        s=s+"\n";
        for ( String medicamento : prescricoes.keySet()){
            s=s+" "+ medicamento +"     :      "+ prescricoes.get(medicamento) + "\n";
        }
        return s;
    }

    public String historicoExames(){
        String s= "EXAMES DO UTENTE "+ utente.getIdUtente();
        s=s+"\n";
        for ( LocalDateTime data : exames.keySet()){
            s=s+ " "+ data +"     :      "+ exames.get(data) + "\n";
        }
        return s;
    }

    public String historicoDadosF(){
        String s= "LEITURAS DE DADOS FISIOLOGICOS DO UTENTE "+ utente.getIdUtente();
        s=s+"\n";
        for ( LocalDate data : dadosFisiologicos.keySet()){
            s=s+ " "+ data +"     :      "+ dadosFisiologicos.get(data) + "\n";
        }
        return s;
    }


    @Override
    public String toString() {
        return "FichaMedica: \n" +
                "\n utente=" + utente +
                "\n dadosFisiologicos=" + dadosFisiologicos +
                "\n exames=" + exames +
                "\n prescricoes=" + prescricoes +
                "\n consultas=" + consultas +
                '.';
    }
}
