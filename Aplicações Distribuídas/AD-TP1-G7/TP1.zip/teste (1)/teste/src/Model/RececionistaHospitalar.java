package Model;

public class RececionistaHospitalar extends ProfissionalDeSaude {
    private static final long serialVersionUID = 234746079825310576L;

    private int idRececionista;
    private String departamento;

    public RececionistaHospitalar(int idRececionista, String cc, String nome, String
            morada, String contacto, String email,
                                  String departamento) {
        super(cc, nome,morada,contacto, email);
        this.idRececionista = idRececionista;
        this.departamento = departamento;
    }

    public RececionistaHospitalar() {
        super();
        this.idRececionista = Integer.parseInt("");
        this.departamento = "";
    }

    public RececionistaHospitalar(int idRececionista, String departamento) {
        super();
        this.idRececionista = idRececionista;
        this.departamento = departamento;

    }

    public int getIdRececionista() {
        return idRececionista;
    }

    public void setIdRececionista(int idRececionista) {
        this.idRececionista = idRececionista;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "RececionistaHospitalar{" +
                "idRececionista=" + idRececionista +
                super.toString()+
                ", departamento='" + departamento + '\'' +
                '}';
    }
}


