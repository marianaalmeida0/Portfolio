package Model;

import java.io.Serializable;
import java.time.LocalDate;

public class Prescricao implements Serializable {
    private static final long serialVersionUID = 509757957344943977L;
    private LocalDate dataInicioToma;
    private String duracao;
    private String tomas;
    private String medicamento;
    private Medico medico;
    public Prescricao() {

    }

    public Prescricao(String medicamento, LocalDate dataInicioToma, String duracao, String tomas, Medico medico) {

        this.dataInicioToma = dataInicioToma;
        this.duracao = duracao;
        this.tomas = tomas;
        this.medicamento=medicamento;
        this.medico=medico;
    }


    public String getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(String medicamento) {
        this.medicamento = medicamento;
    }

    public LocalDate getDataInicioToma() {
        return dataInicioToma;
    }

    public void setDataInicioToma(LocalDate dataInicioToma) {
        this.dataInicioToma = dataInicioToma;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getTomas() {
        return tomas;
    }

    public void setTomas(String tomas) {
        this.tomas = tomas;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setIdMedico(Medico medico) {
        this.medico = medico;
    }

    @Override
    public String toString() {
        return "Prescricao: " +
                "dataInicioToma=" + dataInicioToma +
                ", duracao='" + duracao + '\'' +
                ", tomas='" + tomas + '\'' +
                ", medicamento='" + medicamento + '\'' +
                ", Medico=" + medico +
                '.';
    }
}
