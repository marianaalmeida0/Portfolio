package Model;

public class Medico extends ProfissionalDeSaude {
    private static final long serialVersionUID = 544703607825310576L;
    private int idMedico;
    private String especialidade;

    public Medico(int idMedico, String cc, String nome, String morada, String contacto, String email,
                  String especialidade) {
        super(cc, nome, morada, contacto, email);
        this.especialidade = especialidade;
        this.idMedico=idMedico;
    }

    public Medico() {
        super();
        this.idMedico = Integer.parseInt("");
        this.especialidade = "";
    }

    public Medico(int idMedico, String especialidade) {
        super();
        this.idMedico = idMedico;
        this.especialidade = especialidade;

    }

    public int getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    @Override
    public String toString() {
        return "Medico{" +
                "idMedico=" + idMedico +
                super.toString()+
                ", especialidade='" + especialidade + '\'' +
                '}';
    }
}