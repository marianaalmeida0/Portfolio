package Model;


import java.io.Serializable;
import java.time.LocalDateTime;

public class Consulta implements Serializable {
    private static final long serialVersionUID = 209757957344943977L;
    private int idConsulta;
    private LocalDateTime dataConsulta;
    private String tipoConsulta;
    private Medico medico;
    private String observacoes;



    public Consulta(){
    }

    public Consulta(int idConsulta, LocalDateTime dataConsulta, String tipoConsulta, Medico medico , String observacoes) {
        this.idConsulta=idConsulta;
        this.dataConsulta = dataConsulta;
        this.tipoConsulta = tipoConsulta;
        this.medico=medico;
        this.observacoes=observacoes;
    }
    public void setIdConsulta(int idConsulta){
        this.idConsulta=idConsulta;
    }
    public int getIdConsulta(){
        return idConsulta;
    }
    public LocalDateTime getDataConsulta() {
        return dataConsulta;
    }

    public void setDataConsulta(LocalDateTime dataConsulta) {
        this.dataConsulta = dataConsulta;
    }

    public String getTipoConsulta() {
        return tipoConsulta;
    }

    public void setTipoConsulta(String tipoConsulta) {
        this.tipoConsulta = tipoConsulta;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    @Override
    public String toString() {
        return "Consulta:" + "id="+idConsulta+
                ", dataConsulta=" + dataConsulta +
                ", tipoConsulta='" + tipoConsulta + '\'' +
                ", Medico=" + medico +
                ", observacoes='" + observacoes + '\'' +
                '}';
    }
}

