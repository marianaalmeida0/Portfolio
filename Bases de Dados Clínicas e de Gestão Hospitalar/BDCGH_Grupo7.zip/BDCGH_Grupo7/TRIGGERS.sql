SET SQL_SAFE_UPDATES = 0;
SET @@global.log_bin_trust_function_creators = 1;

-- ---------------- TRIGGERS 1 ------------------------
-- TRIGGER QUE ATUALIZA O NUMERO_UNIDADES_SAUDE NA TABELA TIPO_UNIDADE_SAUDE

-- ALTERAR A TABELA PARA ADICIONAR UMA COLUNA NA TABELA TIPO_UNIDADE_SAUDE
alter table tipo_unidade_saude
add column numero_unidades_saude INT after nome_tipo_unid ;
update tipo_unidade_saude t set numero_unidades_saude = ( select count(*) from unidade_saude us where t.id_tipo_unidade_saude = us.id_tipo_unidade);


-- TRIGGER QUE ATUALIZA O NUMERO_UNIDADES_SAUDE NA TABELA TIPO_UNIDADE_SAUDE QUANDO SE INSERE UMA NOVA UNIDADE DE SAUDE

delimiter $$ 
 CREATE TRIGGER atualizar_numero_unidades after insert on  unidade_saude
 for each row
 begin 
 update tipo_unidade_saude t set numero_unidades_saude = (select count(*) from unidade_saude us where t.id_tipo_unidade_saude = us.id_tipo_unidade) where
 id_tipo_unidade_saude = new.id_tipo_unidade;
 end $$ delimiter ;
 
 DROP TRIGGER atualizar_numero_unidades;
 
 
 -- TRIGGER QUE ATUALIZA O NUMERO_UNIDADES_SAUDE NA TABELA TIPO_UNIDADE_SAUDE QUANDO SE REMOVE UMA NOVA UNIDADE DE SAUDE

 delimiter $$ 
 CREATE TRIGGER atualizar_numero_unidades_delete after delete on  unidade_saude
 for each row
 begin 
 update tipo_unidade_saude t set numero_unidades_saude = (select count(*) from unidade_saude us where t.id_tipo_unidade_saude = us.id_tipo_unidade) where
 id_tipo_unidade_saude = old.id_tipo_unidade;
 end $$ delimiter ;
 
-- TRIGGER QUE ATUALIZA O NUMERO_UNIDADES_SAUDE NA TABELA TIPO_UNIDADE_SAUDE QUANDO SE ALTERA UMA NOVA UNIDADE DE SAUDE

 delimiter $$ 
 CREATE TRIGGER atualizar_numero_unidades_update after update on  unidade_saude
 for each row
 begin 
 update tipo_unidade_saude t set numero_unidades_saude = (select count(*) from unidade_saude us where t.id_tipo_unidade_saude = us.id_tipo_unidade);
 end $$ delimiter ;
 
 
 -- ---------------- TRIGGERS 2 ------------------------
 -- TRIGGER QUE ATUALIZA O NUMERO_PACIENTES NA TABELA UNIDADE_SAUDE

-- ALTERAR A TABELA PARA ADICIONAR UMA COLUNA NA TABELA UNIDADE_SAUDE
alter table  unidade_saude
add numero_pacientes INT after longitude;
update unidade_saude us set numero_pacientes = ( select count(*) from paciente p where us.id_unidade_saude = p.unidade_saude);

-- TRIGGER QUE ATUALIZA O NUMERO_PACIENTES NA TABELA UNIDADE_SAUDE QUANDO SE INSERE UMA NOVA PACIENTE

delimiter $$
CREATE TRIGGER atualizar_numero_pacientes1 after insert on paciente
for each row
begin
update unidade_saude us set numero_pacientes = (select count(*) from paciente p where p.unidade_saude= us.id_unidade_saude) 
where id_unidade_saude = new.unidade_saude;
end;
$$ delimiter ;

-- TRIGGER QUE ATUALIZA O NUMERO_PACIENTES NA TABELA UNIDADE_SAUDE QUANDO SE REMOVE UMA NOVA PACIENTE

delimiter $$
CREATE TRIGGER atualizar_numero_pacientes_delete after delete on paciente
for each row
begin
update unidade_saude us set numero_pacientes = (select count(*) from paciente p where p.unidade_saude= us.id_unidade_saude) 
where id_unidade_saude = old.unidade_saude;
end;
$$ delimiter ;

-- TRIGGER QUE ATUALIZA O NUMERO_PACIENTES NA TABELA UNIDADE_SAUDE QUANDO SE ALTERA UMA NOVA PACIENTE

delimiter $$
CREATE TRIGGER atualizar_numero_pacientes_update after update on paciente
for each row
begin
update unidade_saude us set numero_pacientes = (select count(*) from paciente p where p.unidade_saude= us.id_unidade_saude);
end;
$$ delimiter ;
