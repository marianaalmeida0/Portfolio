

-- --------------------------- QUERYS---------------------------------------

-- AVG IDADE POR CIDADE
select avg(idade(P.data_nascimento)) as Média_Idade, C.designacao  from PACIENTE P
inner join CIDADE C on C.id_cidade=P.cidade
group by C.designacao;

-- IDADE DOS PACIENTES QUE NASCERAM EM X CIDADE
select avg(idade(P.data_nascimento)) as Média_Idade, C.designacao  from PACIENTE P
inner join CIDADE C on C.id_cidade=P.cidade
where C.designacao='Nima'
group by C.designacao;

-- QUE CIDADES TEM UNIDADES PUBLICAS
select C.designacao as Cidade from CIDADE C
inner join unidade_saude US on C.id_cidade=US.id_cidade
inner join propriedadede PD on PD.id_unidade_saude=US.id_unidade_saude
inner join proprietario P on P.id_proprietario=PD.id_proprietario
where P.designacao='Government';


-- ANO EM QUE HOUVE MAIS CONTRATOS
select count(*) as Numero_Contratos, year(Data_aquisicao) as Data_Aquisição from PropriedadeDe PD
group by year(Data_aquisicao)
order by Numero_Contratos desc
limit 1;

-- UNIDADES DE SAUDE POR DISTRITO 
select count(*) as Numero_Unidades, D.designacao as Distrito from Unidade_saude US 
inner join cidade C on C.id_cidade=US.id_cidade
inner join distrito D on D.id_distrito=C.id_distrito
group by D.designacao;

-- PROPRIETARIO QUE NAO TEM UNIDADE DE SAUDE EM TODAS AS CIDADES
select P.designacao as Proprietário from PROPRIETARIO P
where (select count(*) from CIDADE C) !=
(select count(distinct id_cidade) from Unidade_Saude US 
inner join propriedadede PD on US.id_unidade_saude=PD.id_unidade_saude
where P.id_proprietario=PD.id_proprietario);

-- TIPO DE UNIDADE DE SAUDE EM CADA CIDADE
select c.designacao Cidade, tps.nome_tipo_unid tipo_unidade_saude from cidade c, tipo_unidade_saude tps, unidade_saude us
where us.id_cidade = c.id_cidade and us.id_tipo_unidade = tps.id_tipo_unidade_saude;


