
-- ---------- FUNCOES ----------------------------

-- FUNCAO QUE DEVOLVE A IDADE A PARTIR DE UMA DATA DE NASCIMENTO
delimiter $$
CREATE FUNCTION idade(dta date)
returns int
deterministic
begin 
return TIMESTAMPDIFF(YEAR, dta, CURDATE());
end $$
delimiter ;


-- FUNCAO QUE DEVOLVE O NUMERO DE PACIENTES POR UNIDADE DE SAUDE
delimiter $$
CREATE FUNCTION numero_pacientes_por_unidade(id_unidade_saude INT)
RETURNS INT
BEGIN
    DECLARE total_pacientes INT;
    SELECT COUNT(*) INTO total_pacientes FROM Paciente WHERE unidade_saude = id_unidade_saude;
    RETURN total_pacientes;
END 
$$ delimiter ;

select numero_pacientes_por_unidade(2);

-- FUNCAO VERIFICA SE UM TIPO DE UNIDADE EXISTE NA BASE DE DADOS
-- Existe alguma unidade de saude que tenha X tipo de unidade.
DELIMITER // 
CREATE FUNCTION TemTipoUnidade(tipo_unidade VARCHAR(20)) returns BOOLEAN
DETERMINISTIC
begin
declare numero_tipo_unidade INT DEFAULT 0;
select count(*) into numero_tipo_unidade from tipo_unidade_saude where tipo_unidade = nome_tipo_unid;
if numero_tipo_unidade = 0 then return false;
else return true ;
end if ;
end
// DELIMITER ;

select TemTipoUnidade('Clinic');
select TemTipoUnidade('M');

