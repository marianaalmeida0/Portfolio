
-- ----------------------- PROCEDIMENTOS ---------------------------

-- PROCEDIMENTO QUE MOSTRA UNIDADES PROXIMAS DE UMA UNIDADE DE REFERENCIA
-- ( no ARGUMENTO METER O ID DA UNIDADE DE SAUDE) num raio de 10 km
DELIMITER $$
CREATE PROCEDURE verificar_unidades_proximas(
    IN unidade_referencia_id INT
)
BEGIN
    DECLARE unidade_referencia_lat DECIMAL(9,6);
    DECLARE unidade_referencia_lon DECIMAL(9,6);
    
    -- Obter as coordenadas de latitude e longitude da unidade de referência
    SELECT latitude, longitude INTO unidade_referencia_lat, unidade_referencia_lon
    FROM unidade_saude
    WHERE id_unidade_saude = unidade_referencia_id;
    
    -- Verificar as unidades de saúde próximas dentro de 10 km
    SELECT *
    FROM unidade_saude
    WHERE id_unidade_saude <> unidade_referencia_id
    HAVING (
        6371 * 2 * ASIN(
            SQRT(
                POWER(SIN((RADIANS(latitude) - RADIANS(unidade_referencia_lat)) / 2), 2) +
                COS(RADIANS(unidade_referencia_lat)) * COS(RADIANS(latitude)) *
                POWER(SIN((RADIANS(longitude) - RADIANS(unidade_referencia_lon)) / 2), 2)
            )
        )
    ) <= 10;
END $$
DELIMITER ;

call verificar_unidades_proximas (1);



 
-- PROCEDIMENTO PARA INSERIR PACIENTE 

delimiter $$
CREATE PROCEDURE inserir_paciente (id_paciente INT, nome VARCHAR(45) , cidade INT, unidade_saude
INT, data_nascimento DATE)
BEGIN 
ALTER TABLE paciente;
INSERT INTO paciente(id_paciente, nome, cidade, unidade_saude, data_nascimento) 
VALUES (id_paciente, nome, cidade, unidade_saude, data_nascimento);
select 'Paciente Registado com Sucesso', id_paciente, nome, cidade, unidade_saude, data_nascimento
from paciente;
END $$ delimiter ;

call inserir_paciente (2, 'Joana Kweri', 2, 5, '2002-03-01');

-- PROCEDIMENTO PARA CONSULTAR UM DETERMINADO PACIENTE
delimiter //
CREATE PROCEDURE ver_paciente (idPaciente int)
BEGIN
SELECT * from paciente p where p.id_paciente=idPaciente;
END // delimiter ;

call ver_paciente (2);

-- PROCEDIMENTO QUE RETORNA A PERCENTAGEM DE UNIDADES DE SAUDE ADQUIRIDAS ANTES DE 2004

DELIMITER //
CREATE PROCEDURE percentagem_u_s_adquiridas_antes_2004 ( )
BEGIN
DECLARE total_unidades INT;
DECLARE unidades_adquiridas_antes2004 INT;
DECLARE percentagem DECIMAL(5,3);
select count(*) into total_unidades from unidade_saude;
select count(*) into unidades_adquiridas_antes2004 from unidade_saude us, propriedadede pd
where pd.id_unidade_saude= us.id_unidade_saude and year(Data_aquisicao) < 2004;

set percentagem = (unidades_adquiridas_antes2004 / total_unidades) * 100;
select percentagem ;
END // DELIMITER ;


call gana.percentagem_u_s_adquiridas_antes_2004();

